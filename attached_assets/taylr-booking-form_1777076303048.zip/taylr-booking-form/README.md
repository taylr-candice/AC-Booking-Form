# Taylr Customer Booking Form

Standalone customer-facing booking-form prototype for Taylr.
React 19 + TypeScript + Vite + Tailwind 4. Runs as a mockup sandbox
where every component under `src/components/mockups/` is auto-discovered
and served at its own preview URL.

## Stack

- React 19, TypeScript, Vite 7, Tailwind 4
- Custom dependency-free booking-session store
  (`src/state/bookingSession.ts`) backed by `sessionStorage` with
  cross-iframe sync via `storage` events and `useSyncExternalStore`
- shadcn/ui components in `src/components/ui/`
- `wouter` is **not** used here — the dynamic step navigation is driven
  by the `BookingFlow*` wrappers in `src/components/mockups/booking-flow/`

## Running locally

```bash
npm install
npm run dev
```

Visit `http://localhost:5000/` for the canvas/index of all mockups,
or jump directly to a specific component:

- `/preview/booking-flow/BookingFlowMobile` — full mobile flow
- `/preview/booking-flow/BookingFlowDesktop` — full desktop flow
- `/preview/booking-pages/PayMobile` — Step 7 (mobile) in isolation
- `/preview/booking-pages/PayDesktop` — Step 7 (desktop) in isolation

Each preview reads its session from `sessionStorage` under the key
`taylr.bookingSession.v1`, so progress on one page carries over to
others within the same browser tab.

## Project structure

```
src/
├── components/
│   ├── mockups/
│   │   ├── booking-flow/    # End-to-end wrappers (mobile + desktop)
│   │   ├── booking-form/    # Original combined form (legacy)
│   │   ├── booking-pages/   # Per-step pages: Unit, Role, Booker, AC, Access, Pay
│   │   └── booking-slots/   # Step 6 slot picker
│   └── ui/                  # shadcn primitives
├── state/
│   ├── bookingSession.ts        # sessionStorage-backed store
│   ├── bookingDerived.ts        # derived selectors (visible steps, totals, etc.)
│   ├── bookingHelpers.ts        # display labels, totals, gating predicates
│   └── accessMethodCatalog.ts   # 10-branch Step 5 matrix
├── hooks/
└── lib/
docs/
└── replit_logic_v2_*.md     # spec for skip logic, cancellation, signatures
```

## Specs

The full booking-form spec lives in `docs/replit_logic_v2_*.md`.
Key sections:
- §6 — Step 5 access-method matrix (10 branches)
- §8 — Step 7 review & pay
- §12 — "Book another" carryover
- §13.3 — Cascade clearing rules
- §14 — Cancellation policy

## Build constants

- AU 10% GST baked into all prices
- `SYSTEM_PRICE_AUD = 179`, `ADDON_PRICE_AUD = 39`
- Demo password (where applicable): `taylr2024`
- Brand pink `#ED017F`, selection green `#5FBB97`
- Font: Inter
- Mobile viewport: 390 × 844, desktop: 1280 × 900 with 340 px summary rail

## Adding a new mockup

Drop a `.tsx` file anywhere under `src/components/mockups/`. The
`mockupPreviewPlugin` (Vite plugin) discovers it automatically and a
preview URL becomes available at
`/preview/<folder>/<ComponentName>`.

Files or folders prefixed with `_` are ignored (use `_shared/` for
helpers that shouldn't get their own preview URL).
