import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import Home from "@/pages/Home";
import { BuildingsModule } from "@/pages/modules/BuildingsModule";
import { BuildingDetail } from "@/pages/modules/BuildingDetail";
import { LeadsModule } from "@/pages/modules/LeadsModule";
import { LeadDetail } from "@/pages/modules/LeadDetail";
import { UnitsModule } from "@/pages/modules/UnitsModule";
import { UnitDetail } from "@/pages/modules/UnitDetail";
import { MembersModule } from "@/pages/modules/MembersModule";
import { MemberDetail } from "@/pages/modules/MemberDetail";
import { MxUDetail } from "@/pages/modules/MxUDetail";
import { StrataModule } from "@/pages/modules/StrataModule";
import { OwnershipCardsModule } from "@/pages/modules/OwnershipCardsModule";
import { OCInboxModule } from "@/pages/modules/OCInboxModule";
import { AddOCPage } from "@/pages/modules/AddOCPage";
import { OCImportPage } from "@/pages/modules/OCImportPage";
import { ServicesModule } from "@/pages/modules/ServicesModule";
import { ServiceDetail } from "@/pages/modules/ServiceDetail";
import { VendorsModule } from "@/pages/modules/VendorsModule";
import { VendorDetail } from "@/pages/modules/VendorDetail";
import { CommunicationsModule } from "@/pages/modules/CommunicationsModule";
import { AgentsModule } from "@/pages/modules/AgentsModule";
import { AgentDetail } from "@/pages/modules/AgentDetail";
import { FinanceModule } from "@/pages/modules/FinanceModule";
import { SalesOrdersModule } from "@/pages/modules/SalesOrdersModule";
import { SalesOrderDetail } from "@/pages/modules/SalesOrderDetail";
import { CertificatesModule } from "@/pages/modules/CertificatesModule";
import { PaymentDetail } from "@/pages/modules/PaymentDetail";
import { RemittanceDetail } from "@/pages/modules/RemittanceDetail";
import { ModuleTabBar, StrataViewBanner } from "@/components/ModuleTabBar";
import { PortalViewProvider } from "@/contexts/PortalViewContext";
import { StrataBrandingProvider } from "@/contexts/StrataBrandingContext";


function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <StrataBrandingProvider>
        <PortalViewProvider>
        <Toaster />
        <div className="flex min-h-screen bg-gray-50">
          <ModuleTabBar />
          <div className="flex-1 min-w-0 flex flex-col">
            <StrataViewBanner />
            <div className="flex-1 min-w-0">
              <Switch>
          <Route path="/" component={BuildingsModule} />
          <Route path="/oc/:id" component={Home} />
          <Route path="/modules/buildings/:slug" component={BuildingDetail} />
          <Route path="/modules/buildings" component={BuildingsModule} />
          <Route path="/modules/leads/:slug" component={LeadDetail} />
          <Route path="/modules/leads" component={LeadsModule} />
          <Route path="/modules/units/:id" component={UnitDetail} />
          <Route path="/modules/units" component={UnitsModule} />
          <Route path="/modules/members/:memberId/mxu/:unitId" component={MxUDetail} />
          <Route path="/modules/members/:id" component={MemberDetail} />
          <Route path="/modules/members" component={MembersModule} />
          <Route path="/modules/strata/:slug" component={StrataModule} />
          <Route path="/modules/strata" component={StrataModule} />
          <Route path="/modules/services/:slug" component={ServiceDetail} />
          <Route path="/modules/services" component={ServicesModule} />
          <Route path="/modules/vendors/:slug" component={VendorDetail} />
          <Route path="/modules/vendors" component={VendorsModule} />
          <Route path="/modules/agents/:company" component={AgentDetail} />
          <Route path="/modules/agents" component={AgentsModule} />
          <Route path="/modules/communications" component={CommunicationsModule} />
          <Route path="/modules/sales-orders/:orderId" component={SalesOrderDetail} />
          <Route path="/modules/sales-orders" component={SalesOrdersModule} />
          <Route path="/modules/finance/payment/:ref" component={PaymentDetail} />
          <Route path="/modules/finance/remittance/:id" component={RemittanceDetail} />
          <Route path="/modules/finance" component={FinanceModule} />
          <Route path="/modules/ownership-cards/inbox" component={OCInboxModule} />
          <Route path="/modules/ownership-cards/new" component={AddOCPage} />
          <Route path="/modules/ownership-cards/import" component={OCImportPage} />
          <Route path="/modules/ownership-cards" component={OwnershipCardsModule} />
          <Route path="/modules/certificates" component={CertificatesModule} />
              </Switch>
            </div>
          </div>
        </div>
        </PortalViewProvider>
        </StrataBrandingProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
