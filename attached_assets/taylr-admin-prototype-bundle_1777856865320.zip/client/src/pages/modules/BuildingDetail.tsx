import { useState, useMemo, useEffect } from 'react';
import { useLocation, useRoute } from 'wouter';
import {
  ArrowLeft, Building2, ChevronRight, ChevronDown, Upload, CheckCircle2, AlertTriangle, FileText,
  Zap, Droplets, Wifi, X, Pencil, Trash2, Plus, ToggleLeft, ToggleRight,
  Flame, Globe, ExternalLink, ImageIcon, Calendar, Shield, Power, Lock, Handshake, Check, Eye, EyeOff, MoreHorizontal, Compass, ChevronUp, Bot
} from 'lucide-react';

function getAuthorInitials(name: string): string {
  const cleaned = name.replace(/\([^)]*\)/g, '').trim();
  if (!cleaned) return '?';
  const parts = cleaned.split(/\s+/).filter(Boolean);
  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
import { ModuleLayout } from '../../components/ModuleLayout';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { getBuildingAssignableServices, CATEGORY_COLORS } from '@/lib/serviceCatalogue';
import { buildings, getBuildingBySlug, getUnitsByBuildingId, getStrataById, getStageBadgeClasses, getRelationshipBadgeClasses, getStrataPillClasses, strataCompanies, isAgreementExpired, parseAgreementDate, hasActiveTaylrAgreement, getStrataAgreementState, getOriginSourceClasses, getOpportunitySize, getStrataUserById, formatAud, type Building, type BuildingStage, type BuildingAgreement, type OnSitePersonnel, type AppointmentType, type Developer, type DeveloperContact, type RevenueSharing, type RelationshipStatus, type ServiceCategory } from '@shared/portfolioSeed';
import { activityIcon, activityChipClasses, parseEntryDate } from './LeadsModule';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { RenewalActivityDelta, RenewalActivityType } from '@shared/schema';
import { ocListData } from '@shared/ocListSeed';
import { getOCSeedOrDefault } from '@shared/ocSeeds';
import { getStrataServices, isS119RentalAvailableForBuilding, s119UnavailableReason, isS119RentalServiceName } from '@shared/strataServices';
import { isS119Required } from '@shared/logic/contacts';
import { hasConfirmedOwnerOccupier } from '@shared/logic/health';
import { useToast } from '@/hooks/use-toast';
import { usePortalView } from '../../contexts/PortalViewContext';
import { paymentOrders } from '@/lib/paymentsSeed';

type TabId = 'overview' | 'services' | 'utilities' | 's119terms' | 'files' | 'settings';

type InsulationMode = 'not-configured' | 'all-exempt' | 'none-exempt' | 'per-lot';
type LotInsulation = { unitId: string; unitName: string; lot: string; floor: number; hasInsulation: boolean };

type S119TermsState = {
  ocRulesDoc: string | null;
  ocRulesVersion: string;
  insulationMode: InsulationMode;
  insulationDoc: string | null;
  lotInsulation: LotInsulation[];
  hasPool: boolean;
  poolDoc: string | null;
  poolRegNumber: string;
  embeddedElectricity: boolean;
  electricityProvider: string;
  electricityDoc: string | null;
  embeddedHotWater: boolean;
  hotWaterProvider: string;
  hotWaterDoc: string | null;
  embeddedInternet: boolean;
  internetProvider: string;
  internetDoc: string | null;
};

const DEFAULT_TERMS: Record<string, S119TermsState> = {
  'building-001': {
    ocRulesDoc: 'OC-Rules-UP15853-v2.pdf', ocRulesVersion: 'Adopted 15 March 2023',
    insulationMode: 'per-lot', insulationDoc: 'Insulation-UP15853-2023.pdf',
    lotInsulation: [
      { unitId: 'unit-001', unitName: 'Lot 1 — 1 / 2 LNP', lot: '1', floor: 1, hasInsulation: true },
      { unitId: 'unit-002', unitName: 'Lot 2 — 2 / 2 LNP', lot: '2', floor: 1, hasInsulation: true },
      { unitId: 'unit-003', unitName: 'Lot 3 — 3 / 2 LNP', lot: '3', floor: 1, hasInsulation: true },
      { unitId: 'unit-004', unitName: 'Lot 4 — 4 / 2 LNP', lot: '4', floor: 1, hasInsulation: true },
      { unitId: 'unit-005', unitName: 'Lot 5 — 5 / 2 LNP', lot: '5', floor: 1, hasInsulation: true },
      { unitId: 'unit-006', unitName: 'Lot 6 — 6 / 2 LNP', lot: '6', floor: 1, hasInsulation: true },
      { unitId: 'unit-007', unitName: 'Lot 7 — 7 / 2 LNP', lot: '7', floor: 1, hasInsulation: true },
      { unitId: 'unit-008', unitName: 'Lot 8 — 8 / 2 LNP', lot: '8', floor: 1, hasInsulation: true },
      { unitId: 'unit-009', unitName: 'Lot 9 — 9 / 2 LNP', lot: '9', floor: 1, hasInsulation: false },
      { unitId: 'unit-010', unitName: 'Lot 10 — 1 / 4 LNP', lot: '10', floor: 1, hasInsulation: true },
      { unitId: 'unit-011', unitName: 'Lot 11 — 2 / 4 LNP', lot: '11', floor: 1, hasInsulation: true },
      { unitId: 'unit-012', unitName: 'Lot 12 — 3 / 4 LNP', lot: '12', floor: 1, hasInsulation: true },
      { unitId: 'unit-013', unitName: 'Lot 13 — 4 / 4 LNP', lot: '13', floor: 1, hasInsulation: true },
      { unitId: 'unit-014', unitName: 'Lot 14 — 5 / 4 LNP', lot: '14', floor: 1, hasInsulation: true },
      { unitId: 'unit-015', unitName: 'Lot 15 — 6 / 4 LNP', lot: '15', floor: 1, hasInsulation: true },
      { unitId: 'unit-016', unitName: 'Lot 16 — 7 / 4 LNP', lot: '16', floor: 1, hasInsulation: true },
      { unitId: 'unit-017', unitName: 'Lot 17 — 8 / 4 LNP', lot: '17', floor: 1, hasInsulation: true },
      { unitId: 'unit-018', unitName: 'Lot 18 — 9 / 4 LNP', lot: '18', floor: 1, hasInsulation: true },
      { unitId: 'unit-019', unitName: 'Lot 19 — 10 / 4 LNP', lot: '19', floor: 1, hasInsulation: true },
      { unitId: 'unit-020', unitName: 'Lot 20 — 11 / 4 LNP', lot: '20', floor: 1, hasInsulation: true },
      { unitId: 'unit-021', unitName: 'Lot 21 — 12 / 4 LNP', lot: '21', floor: 1, hasInsulation: true },
      { unitId: 'unit-022', unitName: 'Lot 22 — 13 / 4 LNP', lot: '22', floor: 1, hasInsulation: true },
      { unitId: 'unit-023', unitName: 'Lot 23 — 14 / 4 LNP', lot: '23', floor: 1, hasInsulation: true },
      { unitId: 'unit-024', unitName: 'Lot 24 — 15 / 4 LNP', lot: '24', floor: 1, hasInsulation: true },
      { unitId: 'unit-025', unitName: 'Lot 25 — 16 / 4 LNP', lot: '25', floor: 1, hasInsulation: true },
      { unitId: 'unit-026', unitName: 'Lot 26 — 17 / 4 LNP', lot: '26', floor: 1, hasInsulation: false },
      { unitId: 'unit-027', unitName: 'Lot 27 — 18 / 4 LNP', lot: '27', floor: 1, hasInsulation: false },
      { unitId: 'unit-028', unitName: 'Lot 28 — 19 / 4 LNP', lot: '28', floor: 1, hasInsulation: false },
      { unitId: 'unit-029', unitName: 'Lot 29 — 4 / 6 LNP', lot: '29', floor: 1, hasInsulation: true },
      { unitId: 'unit-030', unitName: 'Lot 30 — 5 / 6 LNP', lot: '30', floor: 1, hasInsulation: true },
      { unitId: 'unit-031', unitName: 'Lot 31 — 6 / 6 LNP', lot: '31', floor: 1, hasInsulation: true },
      { unitId: 'unit-032', unitName: 'Lot 32 — 7 / 6 LNP', lot: '32', floor: 1, hasInsulation: true },
      { unitId: 'unit-033', unitName: 'Lot 33 — 8 / 6 LNP', lot: '33', floor: 1, hasInsulation: true },
      { unitId: 'unit-034', unitName: 'Lot 34 — 1 / 6 LNP', lot: '34', floor: 1, hasInsulation: true },
      { unitId: 'unit-035', unitName: 'Lot 35 — 2 / 6 LNP', lot: '35', floor: 1, hasInsulation: true },
      { unitId: 'unit-036', unitName: 'Lot 36 — 3 / 6 LNP', lot: '36', floor: 1, hasInsulation: true },
      { unitId: 'unit-037', unitName: 'Lot 37 — 12 / 6 LNP', lot: '37', floor: 1, hasInsulation: true },
      { unitId: 'unit-038', unitName: 'Lot 38 — 13 / 6 LNP', lot: '38', floor: 1, hasInsulation: true },
      { unitId: 'unit-039', unitName: 'Lot 39 — 14 / 6 LNP', lot: '39', floor: 1, hasInsulation: true },
      { unitId: 'unit-040', unitName: 'Lot 40 — 15 / 6 LNP', lot: '40', floor: 1, hasInsulation: true },
      { unitId: 'unit-041', unitName: 'Lot 41 — 16 / 6 LNP', lot: '41', floor: 1, hasInsulation: true },
      { unitId: 'unit-042', unitName: 'Lot 42 — 17 / 6 LNP', lot: '42', floor: 1, hasInsulation: true },
      { unitId: 'unit-043', unitName: 'Lot 43 — 9 / 6 LNP', lot: '43', floor: 1, hasInsulation: true },
      { unitId: 'unit-044', unitName: 'Lot 44 — 10 / 6 LNP', lot: '44', floor: 1, hasInsulation: true },
      { unitId: 'unit-045', unitName: 'Lot 45 — 11 / 6 LNP', lot: '45', floor: 1, hasInsulation: true },
      { unitId: 'unit-046', unitName: 'Lot 46 — 21 / 6 LNP', lot: '46', floor: 1, hasInsulation: true },
      { unitId: 'unit-047', unitName: 'Lot 47 — 22 / 6 LNP', lot: '47', floor: 1, hasInsulation: true },
      { unitId: 'unit-048', unitName: 'Lot 48 — 23 / 6 LNP', lot: '48', floor: 1, hasInsulation: true },
      { unitId: 'unit-049', unitName: 'Lot 49 — 24 / 6 LNP', lot: '49', floor: 1, hasInsulation: true },
      { unitId: 'unit-050', unitName: 'Lot 50 — 25 / 6 LNP', lot: '50', floor: 1, hasInsulation: true },
      { unitId: 'unit-051', unitName: 'Lot 51 — 26 / 6 LNP', lot: '51', floor: 1, hasInsulation: true },
      { unitId: 'unit-052', unitName: 'Lot 52 — 18 / 6 LNP', lot: '52', floor: 1, hasInsulation: true },
      { unitId: 'unit-053', unitName: 'Lot 53 — 19 / 6 LNP', lot: '53', floor: 1, hasInsulation: true },
      { unitId: 'unit-054', unitName: 'Lot 54 — 20 / 6 LNP', lot: '54', floor: 1, hasInsulation: true },
      { unitId: 'unit-055', unitName: 'Lot 55 — 30 / 6 LNP', lot: '55', floor: 1, hasInsulation: true },
      { unitId: 'unit-056', unitName: 'Lot 56 — 31 / 6 LNP', lot: '56', floor: 1, hasInsulation: true },
      { unitId: 'unit-057', unitName: 'Lot 57 — 32 / 6 LNP', lot: '57', floor: 1, hasInsulation: true },
      { unitId: 'unit-058', unitName: 'Lot 58 — 33 / 6 LNP', lot: '58', floor: 1, hasInsulation: true },
      { unitId: 'unit-059', unitName: 'Lot 59 — 34 / 6 LNP', lot: '59', floor: 1, hasInsulation: true },
      { unitId: 'unit-060', unitName: 'Lot 60 — 35 / 6 LNP', lot: '60', floor: 1, hasInsulation: true },
      { unitId: 'unit-061', unitName: 'Lot 61 — 27 / 6 LNP', lot: '61', floor: 1, hasInsulation: true },
      { unitId: 'unit-062', unitName: 'Lot 62 — 28 / 6 LNP', lot: '62', floor: 1, hasInsulation: true },
      { unitId: 'unit-063', unitName: 'Lot 63 — 29 / 6 LNP', lot: '63', floor: 1, hasInsulation: true },
      { unitId: 'unit-064', unitName: 'Lot 64 — 38 / 6 LNP', lot: '64', floor: 1, hasInsulation: false },
      { unitId: 'unit-065', unitName: 'Lot 65 — 39 / 6 LNP', lot: '65', floor: 1, hasInsulation: false },
      { unitId: 'unit-066', unitName: 'Lot 66 — 40 / 6 LNP', lot: '66', floor: 1, hasInsulation: false },
      { unitId: 'unit-067', unitName: 'Lot 67 — 36 / 6 LNP', lot: '67', floor: 1, hasInsulation: false },
      { unitId: 'unit-068', unitName: 'Lot 68 — 37 / 6 LNP', lot: '68', floor: 1, hasInsulation: false },
    ],
    hasPool: false, poolDoc: null, poolRegNumber: '',
    embeddedElectricity: true, electricityProvider: 'ActewAGL', electricityDoc: 'Embedded-Elec-UP15853.pdf',
    embeddedHotWater: false, hotWaterProvider: '', hotWaterDoc: null,
    embeddedInternet: false, internetProvider: '', internetDoc: null,
  },
  'building-002': {
    ocRulesDoc: 'OC-Rules-UP11043-v1.pdf', ocRulesVersion: 'Adopted 20 June 2022',
    insulationMode: 'all-exempt', insulationDoc: null, lotInsulation: [],
    hasPool: false, poolDoc: null, poolRegNumber: '',
    embeddedElectricity: false, electricityProvider: '', electricityDoc: null,
    embeddedHotWater: false, hotWaterProvider: '', hotWaterDoc: null,
    embeddedInternet: false, internetProvider: '', internetDoc: null,
  },
  'building-003': {
    ocRulesDoc: 'OC-Rules-UP9340-v1.pdf', ocRulesVersion: 'Adopted 10 January 2021',
    insulationMode: 'all-exempt', insulationDoc: null, lotInsulation: [],
    hasPool: false, poolDoc: null, poolRegNumber: '',
    embeddedElectricity: false, electricityProvider: '', electricityDoc: null,
    embeddedHotWater: false, hotWaterProvider: '', hotWaterDoc: null,
    embeddedInternet: false, internetProvider: '', internetDoc: null,
  },
  'building-004': {
    ocRulesDoc: null, ocRulesVersion: '',
    insulationMode: 'not-configured', insulationDoc: null, lotInsulation: [],
    hasPool: false, poolDoc: null, poolRegNumber: '',
    embeddedElectricity: false, electricityProvider: '', electricityDoc: null,
    embeddedHotWater: false, hotWaterProvider: '', hotWaterDoc: null,
    embeddedInternet: false, internetProvider: '', internetDoc: null,
  },
};

function getDefaultTerms(buildingId: string): S119TermsState {
  return DEFAULT_TERMS[buildingId] || {
    ocRulesDoc: null, ocRulesVersion: '', insulationMode: 'not-configured' as InsulationMode, insulationDoc: null, lotInsulation: [],
    hasPool: false, poolDoc: null, poolRegNumber: '',
    embeddedElectricity: false, electricityProvider: '', electricityDoc: null,
    embeddedHotWater: false, hotWaterProvider: '', hotWaterDoc: null,
    embeddedInternet: false, internetProvider: '', internetDoc: null,
  };
}

function getInsulationHold(terms: S119TermsState): boolean {
  if (terms.insulationMode === 'not-configured') return true;
  if (terms.insulationMode === 'all-exempt') return false;
  if (terms.insulationMode === 'none-exempt') return false;
  if (terms.insulationMode === 'per-lot') return terms.lotInsulation.length === 0;
  return true;
}

function getHolds(terms: S119TermsState) {
  const holds: string[] = [];
  if (!terms.ocRulesDoc) holds.push('Owners Corporation Rules');
  if (getInsulationHold(terms)) holds.push('Insulation Statement');
  if (terms.hasPool && !terms.poolDoc) holds.push('Swimming Pool');
  const networkHold = (terms.embeddedElectricity && !terms.electricityDoc) || (terms.embeddedHotWater && !terms.hotWaterDoc) || (terms.embeddedInternet && !terms.internetDoc);
  if (networkHold) holds.push('Embedded Networks');
  return holds;
}

type BuildingFeatures = {
  hasPool: boolean;
  poolRegNumber: string;
  poolComplianceDoc: string | null;
  allLotsExemptInsulation: boolean;
  insulationExemptionDoc: string | null;
};

const DEFAULT_BUILDING_FEATURES: Record<string, BuildingFeatures> = {
  'building-001': { hasPool: false, poolRegNumber: '', poolComplianceDoc: null, allLotsExemptInsulation: false, insulationExemptionDoc: null },
  'building-002': { hasPool: false, poolRegNumber: '', poolComplianceDoc: null, allLotsExemptInsulation: true, insulationExemptionDoc: null },
  'building-003': { hasPool: false, poolRegNumber: '', poolComplianceDoc: null, allLotsExemptInsulation: true, insulationExemptionDoc: null },
};

function getDefaultFeatures(buildingId: string): BuildingFeatures {
  return DEFAULT_BUILDING_FEATURES[buildingId] || { hasPool: false, poolRegNumber: '', poolComplianceDoc: null, allLotsExemptInsulation: false, insulationExemptionDoc: null };
}

type ServiceRules = { disableWhenLost: boolean; pauseWhenUnassigned: boolean; restrictToACT: boolean; disableWhenExpired: boolean };
type ServiceRow = { name: string; managedBy: string; price: string; enabled: boolean; type: 'taylr' | 'strata-appointed'; rules?: ServiceRules };

function getDefaultServices(b: Building): ServiceRow[] {
  const rows: ServiceRow[] = [];
  if (b.services.includes('Onboarding')) rows.push({ name: 'Onboarding Flow', managedBy: 'Taylr', price: 'Included in agreement', enabled: true, type: 'taylr' });
  if (b.services.includes('Parcel Locker')) rows.push({ name: 'Parcel Locker', managedBy: 'Taylr', price: 'Annual building fee', enabled: true, type: 'taylr' });
  if (b.stage === 'Pre-Settlement' && !b.services.includes('Onboarding')) {
    rows.push({ name: 'Onboarding Flow', managedBy: 'Taylr', price: 'Included in agreement', enabled: true, type: 'taylr' });
  }
  const strata = b.strataId ? getStrataById(b.strataId) : null;
  const isPartnerStrata = strata?.isPartner === true;
  const isActiveRelationship = b.relationshipStatus === 'Won';
  if (b.services.includes('S119') && b.stage !== 'Pre-Settlement' && isPartnerStrata && isActiveRelationship) {
    rows.push({ name: 'S119 Rental Certificates', managedBy: `Taylr (via ${strata!.name})`, price: '$342.00 + GST per order', enabled: true, type: 'strata-appointed', rules: { disableWhenLost: true, pauseWhenUnassigned: true, restrictToACT: true, disableWhenExpired: true } });
  }
  return rows;
}

type FileEntry = { name: string; category: string; date: string; uploadedBy: string };

function getDefaultFiles(terms: S119TermsState): FileEntry[] {
  const files: FileEntry[] = [];
  if (terms.ocRulesDoc) files.push({ name: terms.ocRulesDoc, category: 'OC Rules & Governance', date: '01 Feb 2024', uploadedBy: 'Taylr Admin' });
  if (terms.insulationDoc) files.push({ name: terms.insulationDoc, category: 'Compliance Documents', date: '01 Feb 2024', uploadedBy: 'Taylr Admin' });
  if (terms.electricityDoc) files.push({ name: terms.electricityDoc, category: 'Compliance Documents', date: '01 Feb 2024', uploadedBy: 'Taylr Admin' });
  if (terms.hotWaterDoc) files.push({ name: terms.hotWaterDoc, category: 'Compliance Documents', date: '01 Feb 2024', uploadedBy: 'Taylr Admin' });
  if (terms.internetDoc) files.push({ name: terms.internetDoc, category: 'Compliance Documents', date: '01 Feb 2024', uploadedBy: 'Taylr Admin' });
  return files;
}

function isExpiringWithin90Days(expiryDate: string): boolean {
  const d = parseAgreementDate(expiryDate);
  if (!d) return false;
  const now = new Date();
  const diff = d.getTime() - now.getTime();
  return diff > 0 && diff <= 90 * 24 * 60 * 60 * 1000;
}

const isExpired = isAgreementExpired;

type BuildingOverrides = { name: string; displayName: string; address: string; suburb: string; stage: BuildingStage; regDate: string };

export function BuildingDetail() {
  const [, params] = useRoute('/modules/buildings/:slug');
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { view } = usePortalView();
  const slug = params?.slug;
  const building = slug ? getBuildingBySlug(slug) : null;

  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [termsState, setTermsState] = useState<Record<string, S119TermsState>>({});
  const [servicesState, setServicesState] = useState<Record<string, ServiceRow[]>>({});
  const [detailsOverrides, setDetailsOverrides] = useState<Record<string, BuildingOverrides>>({});
  const [editingDetails, setEditingDetails] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDisplayNameOverview, setEditDisplayNameOverview] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [editSuburb, setEditSuburb] = useState('');
  const [editStage, setEditStage] = useState<BuildingStage>('Established');
  const [editRegDate, setEditRegDate] = useState('');
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [editingAgreement, setEditingAgreement] = useState(false);
  const [agrStartDate, setAgrStartDate] = useState('');
  const [agrDuration, setAgrDuration] = useState(3);
  const [agreement, setAgreement] = useState<BuildingAgreement | null>(null);
  const [agreementInitialized, setAgreementInitialized] = useState(false);
  const [gasAvailable, setGasAvailable] = useState(true);
  const [displayName, setDisplayName] = useState('');
  const [canRegister, setCanRegister] = useState(true);
  const [showDisableModal, setShowDisableModal] = useState(false);
  const [settingsInitialized, setSettingsInitialized] = useState(false);
  const [personnelState, setPersonnelState] = useState<Record<string, { bm?: OnSitePersonnel | null; concierge?: OnSitePersonnel | null }>>({});
  const [personnelInitialized, setPersonnelInitialized] = useState(false);
  const [developerState, setDeveloperState] = useState<Record<string, Developer | null>>({});
  const [developerInitialized, setDeveloperInitialized] = useState(false);
  const [relationshipOverrides, setRelationshipOverrides] = useState<Record<string, RelationshipStatus>>({});
  const [showAssignStrataModal, setShowAssignStrataModal] = useState(false);
  const [selectedStrataId, setSelectedStrataId] = useState('');
  const [featuresState, setFeaturesState] = useState<Record<string, BuildingFeatures>>({});
  const [ocInsulationOverrides, setOcInsulationOverrides] = useState<Record<string, 'Yes' | 'No' | 'Unknown'>>({});

  const renewalActivityQuery = useQuery<RenewalActivityDelta>({
    queryKey: [`/api/buildings/${building?.id ?? 'none'}/renewal-activity`],
    enabled: !!building?.id,
  });

  const latestRenewalOutcome = useMemo(() => {
    if (!building) return null;
    const seedRenewal = ((building.taylrAgreement?.renewalActivity || []) as Array<{ id: string; date: string; type: RenewalActivityType; author: string; content: string }>);
    const delta = renewalActivityQuery.data ?? { added: [], edits: {}, deletedIds: [] };
    const deletedSet = new Set(delta.deletedIds);
    const editsMap = delta.edits || {};
    const merged = [
      ...seedRenewal.filter(e => !deletedSet.has(e.id)).map(e => ({ ...e, ...(editsMap[e.id] || {}) })),
      ...(delta.added || []),
    ];
    const outcomes = merged
      .filter(e => /^Marked Renewal (Won|Lost)/.test(e.content))
      .sort((a, b) => parseEntryDate(b.date) - parseEntryDate(a.date));
    if (outcomes.length === 0) return null;
    const latest = outcomes[0];
    const isWon = /^Marked Renewal Won/.test(latest.content);
    const termMatch = latest.content.match(/Renewed term:\s*([^·]+?)(?:\s*·|$)/);
    const reasonMatch = latest.content.match(/Reason:\s*([^·]+?)(?:\s*·|$)/);
    return {
      kind: (isWon ? 'won' : 'lost') as 'won' | 'lost',
      date: latest.date,
      term: termMatch ? termMatch[1].trim() : null,
      reason: reasonMatch ? reasonMatch[1].trim() : null,
    };
  }, [building, renewalActivityQuery.data]);

  if (!building) {
    return (
      <ModuleLayout>
        <div className="text-center py-20">
          <h2 className="text-xl font-bold text-gray-900 mb-2">Building not found</h2>
          <button onClick={() => setLocation('/modules/buildings')} className="text-[#ED017F] hover:underline text-sm" data-testid="btn-back-buildings">← Back to Buildings</button>
        </div>
      </ModuleLayout>
    );
  }

  if (!agreementInitialized) {
    setAgreement(building.taylrAgreement);
    setAgreementInitialized(true);
  }

  if (!settingsInitialized) {
    setDisplayName(building.name);
    setCanRegister(building.stage === 'Registered' || building.stage === 'Established');
    setSettingsInitialized(true);
  }

  if (!personnelInitialized) {
    setPersonnelState(prev => ({
      ...prev,
      [building.id]: { bm: building.buildingManager || null, concierge: building.concierge || null },
    }));
    setPersonnelInitialized(true);
  }

  if (!developerInitialized) {
    setDeveloperState(prev => ({ ...prev, [building.id]: building.developer || null }));
    setDeveloperInitialized(true);
  }

  const currentBM = personnelState[building.id]?.bm ?? building.buildingManager ?? null;
  const currentConcierge = personnelState[building.id]?.concierge ?? building.concierge ?? null;
  const currentDeveloper = developerState[building.id] ?? building.developer ?? null;

  const updatePersonnel = (role: 'bm' | 'concierge', data: OnSitePersonnel | null) => {
    setPersonnelState(prev => ({
      ...prev,
      [building.id]: { ...prev[building.id], [role]: data },
    }));
  };

  const strata = getStrataById(building.strataId);
  const units = getUnitsByBuildingId(building.id);
  const isACT = building.state === 'ACT';

  const getTerms = (id: string) => termsState[id] || getDefaultTerms(id);
  const updateTerms = (id: string, updates: Partial<S119TermsState>) => {
    setTermsState(prev => ({ ...prev, [id]: { ...getTerms(id), ...updates } }));
  };
  const simulateUpload = (id: string, field: keyof S119TermsState, filename: string) => {
    updateTerms(id, { [field]: filename });
    toast({ title: 'Document uploaded', description: filename });
  };

  const getFeatures = (id: string) => featuresState[id] || getDefaultFeatures(id);
  const updateFeatures = (id: string, updates: Partial<BuildingFeatures>) => {
    setFeaturesState(prev => ({ ...prev, [id]: { ...getFeatures(id), ...updates } }));
  };
  const features = getFeatures(building.id);

  const getServices = () => servicesState[building.id] || getDefaultServices(building);
  const setServices = (rows: ServiceRow[]) => setServicesState(prev => ({ ...prev, [building.id]: rows }));

  const terms = getTerms(building.id);
  const currentAgreement = agreement;
  const expiringWithin90 = currentAgreement ? isExpiringWithin90Days(currentAgreement.expiryDate) : false;
  const agreementExpired = currentAgreement ? isExpired(currentAgreement.expiryDate) : false;

  const tBadgeActive = hasActiveTaylrAgreement({ ...building, taylrAgreement: currentAgreement } as Building);

  const currentRelationship = relationshipOverrides[building.id] ?? building.relationshipStatus;
  const isLostBuilding = currentRelationship === 'Expired Lost';
  const isUnassignedBuilding = currentRelationship === 'Unassigned';

  const renewalExpiry = currentAgreement ? parseAgreementDate(currentAgreement.expiryDate) : null;
  const inRenewalWindow = !!renewalExpiry && (
    currentAgreement?.status === 'Expired' ||
    isExpired(currentAgreement!.expiryDate) ||
    (renewalExpiry.getTime() - Date.now()) <= 90 * 24 * 60 * 60 * 1000
  );

  const recordRenewalEvent = (content: string, opts?: { author?: string; type?: RenewalActivityType }) => {
    const today = new Date().toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });
    apiRequest('POST', `/api/buildings/${building.id}/renewal-activity`, {
      date: today,
      type: opts?.type ?? 'Note',
      author: opts?.author ?? 'System',
      content,
    })
      .then(() => queryClient.invalidateQueries({ queryKey: [`/api/buildings/${building.id}/renewal-activity`] }))
      .catch((err: Error) => toast({
        title: 'Could not log renewal change',
        description: err?.message || 'The renewal timeline may be missing this update.',
        variant: 'destructive',
      }));
  };

  const changeRelationshipStatus = (next: RelationshipStatus, extra?: string, opts?: { silent?: boolean }) => {
    const prev = currentRelationship;
    if (prev === next && !extra) return;
    if (prev !== next) {
      setRelationshipOverrides(prevMap => ({ ...prevMap, [building.id]: next }));
    }
    if (inRenewalWindow && !opts?.silent) {
      const base = prev !== next ? `Stage moved: ${prev} → ${next}` : null;
      const content = [base, extra].filter(Boolean).join(' · ');
      if (content) recordRenewalEvent(content);
    }
  };

  const overrides = detailsOverrides[building.id];
  const displayBuilding = overrides ? { ...building, name: overrides.name, address: overrides.address, suburb: overrides.suburb, stage: overrides.stage, _overrides: overrides } : { ...building, _overrides: null };

  // Strata view doesn't configure Taylr services per-building — those are
  // portfolio-wide for the strata company and live in the strata Services
  // module. The per-building Services tab is therefore admin-only.
  const isStrataView = view.mode === 'strata';
  // If the user lands on the Services tab and then switches to strata view
  // (or arrives in strata view with services persisted), bounce them back
  // to Overview so they don't sit on a hidden/empty panel.
  useEffect(() => {
    if (isStrataView && activeTab === 'services') setActiveTab('overview');
  }, [isStrataView, activeTab]);
  const tabs: { id: TabId; label: string; show: boolean }[] = [
    { id: 'overview', label: 'Overview', show: true },
    { id: 'services', label: 'Services', show: !isStrataView },
    { id: 'utilities', label: 'Utilities', show: true },
    { id: 's119terms', label: 'S119 Terms', show: isACT },
    { id: 'files', label: 'Files', show: true },
    { id: 'settings', label: 'Settings', show: true },
  ];

  return (
    <ModuleLayout>
      <div className="flex items-center gap-3 mb-4" data-testid="breadcrumb-building">
        <button onClick={() => setLocation('/modules/buildings')} className="flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors" data-testid="breadcrumb-buildings-link">
          <ArrowLeft className="w-4 h-4 text-slate-600" />
        </button>
        <div className="w-1 h-5 rounded-full bg-slate-200"></div>
        <h1 className="text-lg font-black tracking-wide text-slate-900">Building</h1>
      </div>

      <div className="flex items-start justify-between mb-2">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900" data-testid="building-name">{displayBuilding.name}</h1>
          <p className="text-sm text-gray-500 mt-0.5">{displayBuilding.upNumber ? `${displayBuilding.upNumber} · ` : ''}{displayBuilding.address}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${getStageBadgeClasses(displayBuilding.stage)}`} data-testid="badge-stage">
            {displayBuilding.stage}
          </span>
          {(() => {
            const pill = getStrataPillClasses(building, strata);
            if (currentRelationship === 'Unassigned' || currentRelationship === 'Expired Lost') {
              return (
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${pill.classes}`} data-testid="badge-relationship">
                  {pill.label}
                </span>
              );
            }
            return (
              <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${getRelationshipBadgeClasses(currentRelationship)}`} data-testid="badge-relationship">
                {currentRelationship === 'Agreement Expired' ? 'Expired' : currentRelationship}
              </span>
            );
          })()}
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-200" data-testid="badge-state">
            {displayBuilding.state}
          </span>
          {latestRenewalOutcome && (
            <span
              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                latestRenewalOutcome.kind === 'won'
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-gray-100 text-gray-700 border border-gray-300'
              }`}
              data-testid="badge-renewal-outcome"
              title={latestRenewalOutcome.kind === 'won'
                ? `Renewal Won on ${latestRenewalOutcome.date}${latestRenewalOutcome.term ? ` · ${latestRenewalOutcome.term}` : ''}`
                : `Renewal Lost on ${latestRenewalOutcome.date}${latestRenewalOutcome.reason ? ` — ${latestRenewalOutcome.reason}` : ''}`}
            >
              {latestRenewalOutcome.kind === 'won'
                ? <Check className="w-3 h-3" />
                : <X className="w-3 h-3" />}
              <span>
                {latestRenewalOutcome.kind === 'won'
                  ? `Renewed ${latestRenewalOutcome.date}${latestRenewalOutcome.term ? ` · ${latestRenewalOutcome.term}` : ''}`
                  : `Renewal Lost ${latestRenewalOutcome.date}${latestRenewalOutcome.reason ? ` — ${latestRenewalOutcome.reason}` : ''}`}
              </span>
            </span>
          )}
          {/* Taylr-agreement T badge is admin-only — strata users are
              shielded from Taylr's commercial relationship with the building. */}
          {view.mode !== 'strata' && (tBadgeActive ? (
            <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-[#ED017F]/10 text-[#ED017F] text-xs font-bold" data-testid="badge-taylr-active">t</span>
          ) : currentAgreement && agreementExpired ? (
            <span className="inline-flex items-center justify-center w-7 h-7 rounded-full border-2 border-gray-300 text-gray-400 text-xs font-bold" data-testid="badge-taylr-expired">T</span>
          ) : null)}
        </div>
      </div>

      {(() => {
        const dev = currentDeveloper;
        const stage = displayBuilding.stage;
        if (!dev || !dev.revenueSharing.agreementInPlace) return null;
        const rs = dev.revenueSharing;
        const partiesStr = rs.parties && rs.parties.length > 0
          ? rs.parties.map(p => `${p.name} (${p.percent}%)`).join(' + ')
          : `${dev.companyName} (${rs.sharePercent}%)`;
        const categoriesStr = rs.serviceCategories?.join(', ') || '';
        const termStr = rs.termMonths ? `${rs.termMonths} months` : '';
        const fromDate = rs.appliesFrom;
        const sharingEnds = fromDate && rs.termMonths
          ? (() => { const d = new Date(fromDate); if (isNaN(d.getTime())) return null; d.setMonth(d.getMonth() + rs.termMonths); return d.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' }); })()
          : null;
        const isConcluded = sharingEnds && fromDate && new Date() > (() => { const d = new Date(fromDate); d.setMonth(d.getMonth() + rs.termMonths!); return d; })();
        if (isConcluded) {
          return (
            <div className="flex items-start gap-2.5 p-3 bg-gray-50 border border-gray-200 rounded-xl mb-4" data-testid="banner-revenue-sharing-concluded">
              <CheckCircle2 className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
              <span className="text-sm text-gray-500">
                Revenue sharing concluded {sharingEnds}.
              </span>
            </div>
          );
        }
        return (
          <div className="flex items-start gap-2.5 p-3 bg-amber-50 border border-amber-200 rounded-xl mb-4" data-testid="banner-revenue-sharing-active">
            <Zap className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
            <span className="text-sm text-amber-800">
              Revenue sharing active — {partiesStr}{categoriesStr ? ` · ${categoriesStr}` : ''}{termStr ? ` · ${termStr}` : ''} · End date {sharingEnds || 'not yet set'}
            </span>
          </div>
        );
      })()}

      {isUnassignedBuilding && (
        <div className="flex items-start gap-2.5 p-3.5 bg-orange-50 border border-orange-200 rounded-xl mb-4" data-testid="banner-unassigned">
          <AlertTriangle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <span className="text-sm text-orange-800">
              {isStrataView
                ? 'Strata Unassigned — Management has changed for this building. Strata-appointed services are paused while Taylr re-allocates.'
                : 'Strata Unassigned — Management has changed for this building. Taylr-direct services remain active but strata-appointed services are paused. Assign a new strata company to restore full service capability and resume communications.'}
            </span>
          </div>
          {!isStrataView && (
            <button
              onClick={() => setShowAssignStrataModal(true)}
              className="text-xs font-semibold text-orange-700 border border-orange-300 rounded-lg px-3 py-1.5 hover:bg-orange-100 transition-colors whitespace-nowrap flex-shrink-0"
              data-testid="btn-assign-strata"
            >
              Assign Strata Company →
            </button>
          )}
        </div>
      )}

      {isLostBuilding && (
        <div className="flex items-start gap-2.5 p-3.5 bg-gray-800 border border-gray-700 rounded-xl mb-4" data-testid="banner-lost">
          <X className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <span className="text-sm text-gray-300">
              {view.mode === 'strata'
                ? 'Building Lost — Strata management has been lost. All services are suspended and member registration is disabled.'
                : 'Building Lost — This building has no active Taylr agreement and strata management has been lost. All services are suspended and member registration is disabled.'}
            </span>
          </div>
          {view.mode !== 'strata' && (
            <button
              onClick={() => toast({ title: 'Marked for review', description: 'Taylr team notified.' })}
              className="text-xs font-semibold text-gray-300 border border-gray-600 rounded-lg px-3 py-1.5 hover:bg-gray-700 transition-colors whitespace-nowrap flex-shrink-0"
              data-testid="btn-mark-recovery"
            >
              Mark for Recovery
            </button>
          )}
        </div>
      )}

      {showAssignStrataModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowAssignStrataModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm" onClick={e => e.stopPropagation()} data-testid="modal-assign-strata">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h2 className="text-lg font-semibold text-gray-900">Assign Strata Company</h2>
              <button onClick={() => setShowAssignStrataModal(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Select Strata Company</label>
                <select
                  value={selectedStrataId}
                  onChange={e => setSelectedStrataId(e.target.value)}
                  className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                  data-testid="select-assign-strata"
                >
                  <option value="">Choose a strata company...</option>
                  {strataCompanies.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3 p-5 border-t border-gray-100">
              <button onClick={() => setShowAssignStrataModal(false)} className="px-4 py-2 border border-gray-200 text-sm text-gray-600 rounded-lg hover:bg-gray-50" data-testid="btn-cancel-assign">Cancel</button>
              <button
                onClick={() => {
                  setShowAssignStrataModal(false);
                  const strataLabel = strataCompanies.find(s => s.id === selectedStrataId)?.name;
                  changeRelationshipStatus('Won', strataLabel ? `Strata assigned: ${strataLabel}` : undefined);
                  toast({ title: 'Strata company assigned', description: 'Services will be reviewed.' });
                }}
                className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-sm font-medium rounded-lg hover:bg-[#ED017F] hover:text-white disabled:opacity-50"
                disabled={!selectedStrataId}
                data-testid="btn-confirm-assign"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex border-b border-gray-200 mb-6 mt-4">
        {tabs.filter(t => t.show).map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors ${activeTab === t.id ? 'text-[#ED017F] border-b-2 border-[#ED017F]' : 'text-gray-400 hover:text-gray-600'}`}
            data-testid={`tab-${t.id}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <OverviewTab
          building={building}
          displayBuilding={displayBuilding}
          strata={strata}
          units={units}
          agreement={currentAgreement}
          agreementExpired={agreementExpired}
          expiringWithin90={expiringWithin90}
          editingDetails={editingDetails}
          editName={editName}
          editDisplayNameOverview={editDisplayNameOverview}
          editAddress={editAddress}
          editSuburb={editSuburb}
          editStage={editStage}
          editRegDate={editRegDate}
          setEditingDetails={setEditingDetails}
          setEditName={setEditName}
          setEditDisplayNameOverview={setEditDisplayNameOverview}
          setEditAddress={setEditAddress}
          setEditSuburb={setEditSuburb}
          setEditStage={setEditStage}
          setEditRegDate={setEditRegDate}
          onSaveDetails={(overrides: BuildingOverrides) => setDetailsOverrides(prev => ({ ...prev, [building.id]: overrides }))}
          showRemoveModal={showRemoveModal}
          setShowRemoveModal={setShowRemoveModal}
          showAssignModal={showAssignModal}
          setShowAssignModal={setShowAssignModal}
          editingAgreement={editingAgreement}
          setEditingAgreement={setEditingAgreement}
          agrStartDate={agrStartDate}
          setAgrStartDate={setAgrStartDate}
          agrDuration={agrDuration}
          setAgrDuration={setAgrDuration}
          setAgreement={setAgreement}
          toast={toast}
          currentBM={currentBM}
          currentConcierge={currentConcierge}
          updatePersonnel={updatePersonnel}
          currentDeveloper={currentDeveloper}
          setDeveloperState={setDeveloperState}
          currentRelationship={currentRelationship}
          inRenewalWindow={inRenewalWindow}
          changeRelationshipStatus={changeRelationshipStatus}
          recordRenewalEvent={recordRenewalEvent}
          latestRenewalOutcome={latestRenewalOutcome}
        />
      )}

      {activeTab === 'services' && !isStrataView && (
        <ServicesTab building={building} services={getServices()} setServices={setServices} toast={toast} relationshipStatus={currentRelationship} strata={strata} />
      )}

      {activeTab === 'utilities' && (
        <UtilitiesTab building={building} strata={strata} terms={terms} onUpdateTerms={(updates) => updateTerms(building.id, updates)} services={getServices()} gasAvailable={gasAvailable} setGasAvailable={setGasAvailable} toast={toast} />
      )}

      {activeTab === 's119terms' && isACT && (
        <S119ComplianceDashboard
          building={building}
          terms={terms}
          features={features}
          onUpdateTerms={(updates) => updateTerms(building.id, updates)}
          onUploadTerms={(field, filename) => simulateUpload(building.id, field, filename)}
          ocInsulationOverrides={ocInsulationOverrides}
          toast={toast}
          onSwitchTab={setActiveTab}
        />
      )}

      {activeTab === 'files' && (
        <FilesTab terms={terms} toast={toast} />
      )}

      {activeTab === 'settings' && (
        <SettingsTab
          building={building}
          displayName={displayName}
          setDisplayName={setDisplayName}
          canRegister={canRegister}
          setCanRegister={setCanRegister}
          showDisableModal={showDisableModal}
          setShowDisableModal={setShowDisableModal}
          toast={toast}
          relationshipStatus={currentRelationship}
          features={features}
          onUpdateFeatures={(updates: Partial<BuildingFeatures>) => updateFeatures(building.id, updates)}
          isACT={isACT}
          view={view}
        />
      )}
    </ModuleLayout>
  );
}

function ReadRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">{label}</span>
      <span className="text-sm text-gray-900">{value}</span>
    </div>
  );
}


type RenewalEntryShape = { id: string; date: string; type: RenewalActivityType; author: string; content: string };

function OriginAndHistoryCard({
  building,
  agreement,
  isAdminView,
  currentRelationship,
  inRenewalWindow: inRenewalWindowProp,
  onMarkRenewalWon,
  onMarkRenewalLost,
}: {
  building: Building;
  agreement: BuildingAgreement | null;
  isAdminView: boolean;
  currentRelationship: RelationshipStatus;
  inRenewalWindow: boolean;
  onMarkRenewalWon: (notes: string, term: string) => void;
  onMarkRenewalLost: (reason: string, notes: string) => void;
}) {
  const origin = building.origin;
  const activity = building.leadInfo?.activity || [];
  const sortedActivity = useMemo(
    () => [...activity].sort((a, b) => parseEntryDate(b.date) - parseEntryDate(a.date)),
    [activity],
  );
  const seedRenewal = (building.taylrAgreement?.renewalActivity || []) as RenewalEntryShape[];

  const inRenewalWindow = inRenewalWindowProp;
  const canEditRenewal = isAdminView && !!agreement && inRenewalWindow;
  const canMarkOutcome = canEditRenewal && currentRelationship !== 'Expired Lost';

  const deltaQuery = useQuery<RenewalActivityDelta>({
    queryKey: [`/api/buildings/${building.id}/renewal-activity`],
    enabled: !!building.id,
  });
  const delta = deltaQuery.data ?? { added: [], edits: {}, deletedIds: [] };

  const mergedRenewal: RenewalEntryShape[] = useMemo(() => {
    const deletedSet = new Set(delta.deletedIds);
    const editsMap = delta.edits || {};
    const fromSeed = seedRenewal
      .filter(e => !deletedSet.has(e.id))
      .map(e => ({ ...e, ...(editsMap[e.id] || {}) } as RenewalEntryShape));
    const fromAdded = (delta.added || []).map(e => ({
      id: e.id, date: e.date, type: e.type, author: e.author, content: e.content,
    }));
    return [...fromSeed, ...fromAdded];
  }, [seedRenewal, delta]);

  const sortedRenewal = useMemo(
    () => [...mergedRenewal].sort((a, b) => parseEntryDate(b.date) - parseEntryDate(a.date)),
    [mergedRenewal],
  );
  const addedIdSet = useMemo(() => new Set((delta.added || []).map(e => e.id)), [delta]);

  const [showActivity, setShowActivity] = useState(false);
  const [showRenewal, setShowRenewal] = useState(true);

  const { toast } = useToast();
  const invalidate = () => queryClient.invalidateQueries({ queryKey: [`/api/buildings/${building.id}/renewal-activity`] });

  const addMutation = useMutation({
    mutationFn: async (input: Omit<RenewalEntryShape, 'id'>) => {
      const res = await apiRequest('POST', `/api/buildings/${building.id}/renewal-activity`, input);
      return res.json();
    },
    onSuccess: () => { invalidate(); toast({ title: 'Renewal entry added' }); },
    onError: (err: Error) => toast({ title: 'Could not add entry', description: err.message, variant: 'destructive' }),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<RenewalEntryShape> }) => {
      const res = await apiRequest('PATCH', `/api/buildings/${building.id}/renewal-activity/${id}`, updates);
      return res.json();
    },
    onSuccess: () => { invalidate(); toast({ title: 'Renewal entry updated' }); },
    onError: (err: Error) => toast({ title: 'Could not update entry', description: err.message, variant: 'destructive' }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('DELETE', `/api/buildings/${building.id}/renewal-activity/${id}`);
      return res.json();
    },
    onSuccess: () => { invalidate(); toast({ title: 'Renewal entry removed' }); },
    onError: (err: Error) => toast({ title: 'Could not remove entry', description: err.message, variant: 'destructive' }),
  });

  const today = useMemo(
    () => new Date().toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' }),
    [],
  );
  const [showAdd, setShowAdd] = useState(false);
  const [newDate, setNewDate] = useState(today);
  const [newType, setNewType] = useState<RenewalActivityType>('Note');
  const [newAuthor, setNewAuthor] = useState('You (admin)');
  const [newContent, setNewContent] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDate, setEditDate] = useState('');
  const [editType, setEditType] = useState<RenewalActivityType>('Note');
  const [editAuthor, setEditAuthor] = useState('');
  const [editContent, setEditContent] = useState('');

  const beginEdit = (entry: RenewalEntryShape) => {
    setEditingId(entry.id);
    setEditDate(entry.date);
    setEditType(entry.type);
    setEditAuthor(entry.author);
    setEditContent(entry.content);
  };
  const cancelEdit = () => setEditingId(null);
  const saveEdit = () => {
    if (!editingId) return;
    if (!editDate.trim() || !editAuthor.trim() || !editContent.trim()) return;
    updateMutation.mutate({
      id: editingId,
      updates: { date: editDate.trim(), type: editType, author: editAuthor.trim(), content: editContent.trim() },
    }, { onSuccess: () => setEditingId(null) });
  };

  const submitAdd = () => {
    if (!newDate.trim() || !newAuthor.trim() || !newContent.trim()) return;
    addMutation.mutate({
      date: newDate.trim(), type: newType, author: newAuthor.trim(), content: newContent.trim(),
    }, {
      onSuccess: () => {
        setNewContent('');
        setNewType('Note');
        setNewDate(today);
        setShowAdd(false);
      },
    });
  };

  const ACTIVITY_TYPES: RenewalActivityType[] = ['Note', 'Call', 'Email', 'Meeting', 'Reminder'];

  const [wonDialogOpen, setWonDialogOpen] = useState(false);
  const [wonNotes, setWonNotes] = useState('');
  const [wonTerm, setWonTerm] = useState('');
  const [lostDialogOpen, setLostDialogOpen] = useState(false);
  const [lostReason, setLostReason] = useState('Lost to competitor');
  const [lostNotes, setLostNotes] = useState('');

  const submitWon = () => {
    onMarkRenewalWon(wonNotes.trim(), wonTerm.trim());
    setWonDialogOpen(false);
    setWonNotes('');
    setWonTerm('');
  };
  const submitLost = () => {
    if (!lostReason.trim()) return;
    onMarkRenewalLost(lostReason.trim(), lostNotes.trim());
    setLostDialogOpen(false);
    setLostNotes('');
    setLostReason('Lost to competitor');
  };

  return (
    <Card data-testid="card-origin-history">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Compass className="w-4 h-4 text-gray-500" />
          <CardTitle className="text-sm font-semibold">Origin & CRM History</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        {origin ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">How it came about</p>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getOriginSourceClasses(origin.source)}`} data-testid="pill-origin-source">{origin.source}</span>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Added on</p>
                <p className="text-sm text-gray-900" data-testid="text-origin-date">{origin.date}</p>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Added by</p>
                <p className="text-sm text-gray-900" data-testid="text-origin-added-by">{origin.addedBy}</p>
              </div>
            </div>

            {origin.notes && (
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Background</p>
                <p className="text-sm text-gray-700 bg-gray-50 border border-gray-100 rounded-lg p-3 leading-relaxed" data-testid="text-origin-notes">{origin.notes}</p>
              </div>
            )}

            {building.historyNotes && building.historyNotes !== origin.notes && (
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">History notes</p>
                <p className="text-sm text-gray-600 italic" data-testid="text-history-notes">{building.historyNotes}</p>
              </div>
            )}

            {sortedActivity.length > 0 && (
              <div className="border-t border-gray-100 pt-4">
                <button
                  onClick={() => setShowActivity(v => !v)}
                  className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                  data-testid="btn-toggle-preagreement-activity"
                >
                  {showActivity ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  Pre-agreement activity ({sortedActivity.length} {sortedActivity.length === 1 ? 'entry' : 'entries'})
                </button>
                <p className="text-[11px] text-gray-400 mt-1 ml-6">Activity log preserved from when this building was a lead — read-only.</p>
                {showActivity && (
                  <div className="mt-4 space-y-3" data-testid="list-preagreement-activity">
                    {sortedActivity.map(entry => (
                      <div key={entry.id} className="flex items-start gap-3" data-testid={`entry-preagreement-${entry.id}`}>
                        <div className={`shrink-0 w-7 h-7 rounded-full border flex items-center justify-center ${activityChipClasses(entry.type)}`}>
                          {activityIcon(entry.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <span className="font-medium text-gray-900">{entry.type}</span>
                            <span>·</span>
                            <span>{entry.date}</span>
                            <span>·</span>
                            <span>{entry.author}</span>
                          </div>
                          <p className="text-sm text-gray-700 mt-0.5">{entry.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {(sortedRenewal.length > 0 || canEditRenewal) && (
              <div className="border-t border-gray-100 pt-4">
                <div className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => setShowRenewal(v => !v)}
                    className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                    data-testid="btn-toggle-renewal-activity"
                  >
                    {showRenewal ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    Renewal activity ({sortedRenewal.length} {sortedRenewal.length === 1 ? 'entry' : 'entries'})
                  </button>
                  {canEditRenewal && !showAdd && (
                    <div className="flex items-center gap-2">
                      {canMarkOutcome && (
                        <>
                          <button
                            onClick={() => setWonDialogOpen(true)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-emerald-200 bg-emerald-50 text-emerald-700 text-xs font-medium hover:bg-emerald-100"
                            data-testid="btn-mark-renewal-won"
                          >
                            <Check className="w-3.5 h-3.5" /> Mark Renewal Won
                          </button>
                          <button
                            onClick={() => setLostDialogOpen(true)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-gray-200 bg-white text-gray-700 text-xs font-medium hover:bg-gray-50"
                            data-testid="btn-mark-renewal-lost"
                          >
                            <X className="w-3.5 h-3.5" /> Mark Renewal Lost
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => { setShowAdd(true); setShowRenewal(true); }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#ED017F] text-white text-xs font-medium hover:bg-[#c80169]"
                        data-testid="btn-add-renewal-entry"
                      >
                        <Plus className="w-3.5 h-3.5" /> Add renewal entry
                      </button>
                    </div>
                  )}
                </div>
                <p className="text-[11px] text-gray-400 mt-1 ml-6">
                  {canEditRenewal
                    ? 'Log calls, emails, meetings and notes for the renewal cycle. Admins only.'
                    : 'Post-agreement renewal engagement leading up to and after the agreement expiry.'}
                </p>
                {showRenewal && (
                  <div className="mt-4 space-y-3" data-testid="list-renewal-activity">
                    {canEditRenewal && showAdd && (
                      <div className="rounded-lg border border-gray-200 p-4 bg-gray-50" data-testid="form-add-renewal-entry">
                        <div className="text-xs font-semibold text-gray-700 mb-2.5">Log a renewal entry</div>
                        <div className="flex gap-2 mb-3 flex-wrap">
                          {ACTIVITY_TYPES.map(t => (
                            <button
                              key={t}
                              onClick={() => setNewType(t)}
                              data-testid={`btn-renewal-type-${t.toLowerCase()}`}
                              className={`px-3 py-1.5 rounded-md text-xs font-medium border ${newType === t ? activityChipClasses(t) : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-100'}`}
                            >
                              <span className="inline-flex items-center gap-1.5">{activityIcon(t)}{t}</span>
                            </button>
                          ))}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
                          <input
                            type="text"
                            value={newDate}
                            onChange={e => setNewDate(e.target.value)}
                            placeholder="e.g. 18 Apr 2026"
                            data-testid="input-renewal-date"
                            className="text-sm rounded-md border border-gray-200 px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#ED017F]/30"
                          />
                          <input
                            type="text"
                            value={newAuthor}
                            onChange={e => setNewAuthor(e.target.value)}
                            placeholder="Author"
                            data-testid="input-renewal-author"
                            className="text-sm rounded-md border border-gray-200 px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#ED017F]/30"
                          />
                        </div>
                        <textarea
                          value={newContent}
                          onChange={e => setNewContent(e.target.value)}
                          placeholder={newType === 'Reminder' ? 'What needs to happen and when?' : 'Notes from this interaction…'}
                          rows={3}
                          data-testid="input-renewal-content"
                          className="w-full text-sm rounded-md border border-gray-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#ED017F]/30 bg-white"
                        />
                        <div className="flex justify-end items-center gap-2 mt-2.5">
                          <button
                            onClick={() => { setShowAdd(false); setNewContent(''); }}
                            className="px-3 py-1.5 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100"
                            data-testid="btn-cancel-renewal-entry"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={submitAdd}
                            disabled={!newContent.trim() || !newDate.trim() || !newAuthor.trim() || addMutation.isPending}
                            data-testid="btn-save-renewal-entry"
                            className="px-3 py-1.5 rounded-md bg-[#ED017F] text-white text-sm font-medium hover:bg-[#c80169] disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            {addMutation.isPending ? 'Saving…' : 'Save entry'}
                          </button>
                        </div>
                      </div>
                    )}

                    {sortedRenewal.length === 0 && !showAdd && (
                      <div className="text-sm text-gray-400 py-6 text-center border border-dashed border-gray-200 rounded-lg">
                        No renewal activity logged yet.
                      </div>
                    )}

                    {sortedRenewal.map(entry => {
                      const isEditing = editingId === entry.id;
                      const isUserAdded = addedIdSet.has(entry.id);
                      if (isEditing) {
                        return (
                          <div key={entry.id} className="rounded-lg border border-gray-200 p-4 bg-gray-50" data-testid={`form-edit-renewal-${entry.id}`}>
                            <div className="text-xs font-semibold text-gray-700 mb-2.5">Edit renewal entry</div>
                            <div className="flex gap-2 mb-3 flex-wrap">
                              {ACTIVITY_TYPES.map(t => (
                                <button
                                  key={t}
                                  onClick={() => setEditType(t)}
                                  data-testid={`btn-edit-renewal-type-${t.toLowerCase()}`}
                                  className={`px-3 py-1.5 rounded-md text-xs font-medium border ${editType === t ? activityChipClasses(t) : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-100'}`}
                                >
                                  <span className="inline-flex items-center gap-1.5">{activityIcon(t)}{t}</span>
                                </button>
                              ))}
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
                              <input
                                type="text"
                                value={editDate}
                                onChange={e => setEditDate(e.target.value)}
                                data-testid="input-edit-renewal-date"
                                className="text-sm rounded-md border border-gray-200 px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#ED017F]/30"
                              />
                              <input
                                type="text"
                                value={editAuthor}
                                onChange={e => setEditAuthor(e.target.value)}
                                data-testid="input-edit-renewal-author"
                                className="text-sm rounded-md border border-gray-200 px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#ED017F]/30"
                              />
                            </div>
                            <textarea
                              value={editContent}
                              onChange={e => setEditContent(e.target.value)}
                              rows={3}
                              data-testid="input-edit-renewal-content"
                              className="w-full text-sm rounded-md border border-gray-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#ED017F]/30 bg-white"
                            />
                            <div className="flex justify-end items-center gap-2 mt-2.5">
                              <button
                                onClick={cancelEdit}
                                className="px-3 py-1.5 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100"
                                data-testid={`btn-cancel-edit-renewal-${entry.id}`}
                              >
                                Cancel
                              </button>
                              <button
                                onClick={saveEdit}
                                disabled={!editContent.trim() || !editDate.trim() || !editAuthor.trim() || updateMutation.isPending}
                                data-testid={`btn-save-edit-renewal-${entry.id}`}
                                className="px-3 py-1.5 rounded-md bg-[#ED017F] text-white text-sm font-medium hover:bg-[#c80169] disabled:opacity-40 disabled:cursor-not-allowed"
                              >
                                {updateMutation.isPending ? 'Saving…' : 'Save changes'}
                              </button>
                            </div>
                          </div>
                        );
                      }
                      const isSystem = entry.author === 'System';
                      const authorLabel = isSystem ? 'Taylr automation' : entry.author;
                      const authorTooltip = isSystem
                        ? 'Logged automatically by the Taylr system'
                        : `Logged by ${entry.author}`;
                      return (
                        <div key={entry.id} className="flex items-start gap-3 group" data-testid={`entry-renewal-${entry.id}`}>
                          <div className={`shrink-0 w-7 h-7 rounded-full border flex items-center justify-center ${activityChipClasses(entry.type)}`}>
                            {activityIcon(entry.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-gray-500">
                              <span className="font-medium text-gray-900">{entry.type}</span>
                              <span>·</span>
                              <span>{entry.date}</span>
                              <span>·</span>
                              <span
                                className="inline-flex items-center gap-1.5"
                                title={authorTooltip}
                                data-testid={`author-renewal-${entry.id}`}
                              >
                                {isSystem ? (
                                  <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200" aria-hidden="true">
                                    <Bot className="w-3 h-3" />
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-gray-200 text-gray-700 border border-gray-300 text-[9px] font-semibold tracking-wide" aria-hidden="true">
                                    {getAuthorInitials(entry.author)}
                                  </span>
                                )}
                                <span className="text-gray-700">{authorLabel}</span>
                              </span>
                              {isSystem && (
                                <span
                                  className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide bg-indigo-50 text-indigo-700 border border-indigo-200"
                                  title="Created by automated workflow"
                                  data-testid={`badge-system-${entry.id}`}
                                >
                                  System
                                </span>
                              )}
                              {isUserAdded && !isSystem && (
                                <span
                                  className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide bg-emerald-50 text-emerald-700 border border-emerald-200"
                                  title="Added in this session"
                                >
                                  New
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-gray-700 mt-0.5">{entry.content}</p>
                          </div>
                          {canEditRenewal && (
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                onClick={() => beginEdit(entry)}
                                className="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 hover:text-gray-700"
                                data-testid={`btn-edit-renewal-${entry.id}`}
                                title="Edit entry"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  if (window.confirm('Remove this renewal entry?')) {
                                    deleteMutation.mutate(entry.id);
                                  }
                                }}
                                className="p-1.5 rounded-md text-gray-500 hover:bg-red-50 hover:text-red-600"
                                data-testid={`btn-delete-renewal-${entry.id}`}
                                title="Delete entry"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="text-sm text-gray-500">
            <p>No origin recorded for this building.</p>
            {building.historyNotes && (
              <p className="text-xs text-gray-500 mt-2 italic" data-testid="text-history-notes-fallback">{building.historyNotes}</p>
            )}
            <p className="text-[11px] text-gray-400 mt-2">New buildings should capture how they came to Taylr at creation time.</p>
          </div>
        )}
      </CardContent>
      {wonDialogOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setWonDialogOpen(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm" onClick={e => e.stopPropagation()} data-testid="modal-renewal-won">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h2 className="text-lg font-semibold text-gray-900">Mark Renewal Won</h2>
              <button onClick={() => setWonDialogOpen(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Renewed term (optional)</label>
                <input type="text" value={wonTerm} onChange={e => setWonTerm(e.target.value)} placeholder="e.g. 3 years" className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-renewal-won-term" />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Notes (optional)</label>
                <textarea value={wonNotes} onChange={e => setWonNotes(e.target.value)} rows={3} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-renewal-won-notes" />
              </div>
            </div>
            <div className="flex justify-end gap-3 p-5 border-t border-gray-100">
              <button onClick={() => setWonDialogOpen(false)} className="px-4 py-2 border border-gray-200 text-sm text-gray-600 rounded-lg hover:bg-gray-50" data-testid="btn-cancel-renewal-won">Cancel</button>
              <button onClick={submitWon} className="px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700" data-testid="btn-confirm-renewal-won">Confirm Won</button>
            </div>
          </div>
        </div>
      )}
      {lostDialogOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setLostDialogOpen(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm" onClick={e => e.stopPropagation()} data-testid="modal-renewal-lost">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h2 className="text-lg font-semibold text-gray-900">Mark Renewal Lost</h2>
              <button onClick={() => setLostDialogOpen(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Reason</label>
                <select value={lostReason} onChange={e => setLostReason(e.target.value)} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="select-renewal-lost-reason">
                  <option>Lost to competitor</option>
                  <option>Strata terminated</option>
                  <option>Owners decided not to renew</option>
                  <option>Pricing</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Notes (optional)</label>
                <textarea value={lostNotes} onChange={e => setLostNotes(e.target.value)} rows={3} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-renewal-lost-notes" />
              </div>
            </div>
            <div className="flex justify-end gap-3 p-5 border-t border-gray-100">
              <button onClick={() => setLostDialogOpen(false)} className="px-4 py-2 border border-gray-200 text-sm text-gray-600 rounded-lg hover:bg-gray-50" data-testid="btn-cancel-renewal-lost">Cancel</button>
              <button onClick={submitLost} className="px-4 py-2 bg-gray-800 text-white text-sm font-medium rounded-lg hover:bg-gray-900" data-testid="btn-confirm-renewal-lost">Confirm Lost</button>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}

function FieldInput({ label, value, onChange, testId, placeholder }: { label: string; value: string; onChange: (v: string) => void; testId: string; placeholder?: string }) {
  return (
    <div>
      <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">{label}</label>
      <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#ED017F] focus:border-transparent" data-testid={testId} />
    </div>
  );
}

const APPOINTMENT_TYPES: AppointmentType[] = ['Full-time', 'Part-time', 'On-call', 'Casual'];
const ALL_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function emptyPersonnel(): OnSitePersonnel {
  return { name: '', appointedBy: '', phone: '', appointmentType: 'Full-time', daysOnSite: [], hoursFrom: '', hoursTo: '' };
}

function formatTimeDisplay(t: string): string {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  const suffix = h >= 12 ? 'pm' : 'am';
  const hour = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return m === 0 ? `${hour}${suffix}` : `${hour}:${m.toString().padStart(2, '0')}${suffix}`;
}

function formatDaysDisplay(days: string[]): string {
  if (!days || days.length === 0) return '';
  const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  if (weekdays.every(d => days.includes(d)) && days.length === 5) return 'Mon\u2013Fri';
  if (ALL_DAYS.every(d => days.includes(d)) && days.length === 7) return 'Mon\u2013Sun';
  return days.join(', ');
}

function OnSitePersonnelCard({ role, data, onSave, onRemove, toast }: {
  role: 'Building Manager' | 'Concierge';
  data: OnSitePersonnel | null;
  onSave: (d: OnSitePersonnel) => void;
  onRemove: () => void;
  toast: any;
}) {
  const [editing, setEditing] = useState(false);
  const [showConfirmRemove, setShowConfirmRemove] = useState(false);
  const [draft, setDraft] = useState<OnSitePersonnel>(emptyPersonnel());
  const roleSlug = role.toLowerCase().replace(/\s+/g, '-');
  const showDaysHours = draft.appointmentType !== 'On-call';

  const startEdit = () => {
    setDraft(data ? { ...data } : emptyPersonnel());
    setEditing(true);
  };

  const startAdd = () => {
    setDraft(emptyPersonnel());
    setEditing(true);
  };

  const save = () => {
    onSave(draft);
    setEditing(false);
  };

  return (
    <div data-testid={`personnel-card-${roleSlug}`}>
      <Card className="border border-gray-200 shadow-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold text-gray-900">{role}</CardTitle>
              <p className="text-[11px] text-gray-400 mt-0.5">On-site {role.toLowerCase()} for this building. Appointed by the strata company, Taylr, or an external operator.</p>
            </div>
            {data && !editing && (
              <button onClick={startEdit} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600" data-testid={`btn-edit-${roleSlug}`}>
                <Pencil className="w-4 h-4" />
              </button>
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {editing ? (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Name</label>
                <input type="text" value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`input-${roleSlug}-name`} />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Organisation</label>
                <input type="text" value={draft.organisation || ''} onChange={e => setDraft({ ...draft, organisation: e.target.value || undefined })} placeholder="Optional" className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`input-${roleSlug}-org`} />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Appointed by</label>
                <input type="text" value={draft.appointedBy} onChange={e => setDraft({ ...draft, appointedBy: e.target.value })} placeholder='e.g. "Vantage Strata" / "Taylr"' className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`input-${roleSlug}-appointed`} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Phone</label>
                  <input type="text" value={draft.phone} onChange={e => setDraft({ ...draft, phone: e.target.value })} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`input-${roleSlug}-phone`} />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Email</label>
                  <input type="text" value={draft.email || ''} onChange={e => setDraft({ ...draft, email: e.target.value || undefined })} placeholder="Optional" className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`input-${roleSlug}-email`} />
                </div>
              </div>
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Appointment type</label>
                <div className="flex gap-2 mt-1">
                  {APPOINTMENT_TYPES.map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setDraft({ ...draft, appointmentType: t })}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${draft.appointmentType === t ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}
                      data-testid={`btn-${roleSlug}-type-${t.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              {showDaysHours && (
                <>
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Days on site</label>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {ALL_DAYS.map(day => {
                        const active = draft.daysOnSite.includes(day);
                        return (
                          <button
                            key={day}
                            type="button"
                            onClick={() => setDraft({ ...draft, daysOnSite: active ? draft.daysOnSite.filter(d => d !== day) : [...draft.daysOnSite, day] })}
                            className={`px-2 py-1 rounded text-[11px] font-medium border ${active ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white text-gray-400 border-gray-200'}`}
                            data-testid={`btn-${roleSlug}-day-${day.toLowerCase()}`}
                          >
                            {day}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Hours</label>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex-1">
                        <label className="block text-[10px] text-gray-400 mb-0.5">From</label>
                        <input type="time" value={draft.hoursFrom} onChange={e => setDraft({ ...draft, hoursFrom: e.target.value })} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs" data-testid={`input-${roleSlug}-hours-from`} />
                      </div>
                      <span className="text-gray-400 text-xs mt-4">\u2013</span>
                      <div className="flex-1">
                        <label className="block text-[10px] text-gray-400 mb-0.5">To</label>
                        <input type="time" value={draft.hoursTo} onChange={e => setDraft({ ...draft, hoursTo: e.target.value })} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs" data-testid={`input-${roleSlug}-hours-to`} />
                      </div>
                    </div>
                  </div>
                </>
              )}
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Notes</label>
                <textarea value={draft.notes || ''} onChange={e => setDraft({ ...draft, notes: e.target.value || undefined })} placeholder="e.g. Available by phone outside hours" rows={2} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm resize-none" data-testid={`input-${roleSlug}-notes`} />
              </div>
              <div className="flex items-center gap-3 pt-1">
                <button onClick={save} className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-sm font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid={`btn-save-${roleSlug}`}>Save Changes</button>
                <button onClick={() => setEditing(false)} className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-lg" data-testid={`btn-cancel-${roleSlug}`}>Cancel</button>
              </div>
              {data && (
                <button onClick={() => setShowConfirmRemove(true)} className="text-xs text-red-500 hover:text-red-600 hover:underline" data-testid={`btn-remove-${roleSlug}`}>Remove</button>
              )}
            </div>
          ) : data ? (
            <div className="space-y-1.5">
              <ReadRow label="Name" value={data.name} />
              {data.organisation && <ReadRow label="Organisation" value={data.organisation} />}
              <ReadRow label="Appointed by" value={data.appointedBy} />
              <ReadRow label="Phone" value={data.phone} />
              {data.email && <ReadRow label="Email" value={data.email} />}
              <ReadRow label="Appointment type" value={data.appointmentType} />
              {data.appointmentType !== 'On-call' && data.daysOnSite.length > 0 && (
                <ReadRow label="Days on site" value={formatDaysDisplay(data.daysOnSite)} />
              )}
              {data.appointmentType !== 'On-call' && data.hoursFrom && data.hoursTo && (
                <ReadRow label="Hours" value={`${formatTimeDisplay(data.hoursFrom)} \u2013 ${formatTimeDisplay(data.hoursTo)}`} />
              )}
              {data.notes && <ReadRow label="Notes" value={data.notes} />}
            </div>
          ) : (
            <div>
              <p className="text-sm text-gray-400 italic mb-3">No {role.toLowerCase()} assigned to this building.</p>
              <button onClick={startAdd} className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-50" data-testid={`btn-add-${roleSlug}`}>
                <Plus className="w-3.5 h-3.5" />
                Add {role}
              </button>
            </div>
          )}
          <p className="text-[11px] text-gray-400 italic mt-3">Hours entered here determine member-facing access availability for bookings requiring on-site access at this building.</p>
        </CardContent>
      </Card>

      {showConfirmRemove && (
        <Modal onClose={() => setShowConfirmRemove(false)}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Remove {role}</h3>
          <p className="text-sm text-gray-600 mb-6">Remove {data?.name} as {role.toLowerCase()} for this building?</p>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowConfirmRemove(false)} className="px-4 py-2 border border-gray-200 text-sm rounded-lg" data-testid={`btn-cancel-remove-${roleSlug}`}>Cancel</button>
            <button
              onClick={() => { onRemove(); setShowConfirmRemove(false); setEditing(false); }}
              className="px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700"
              data-testid={`btn-confirm-remove-${roleSlug}`}
            >
              Remove
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function OverviewTab({ building, displayBuilding, strata, units, agreement, agreementExpired, expiringWithin90, editingDetails, editName, editDisplayNameOverview, editAddress, editSuburb, editStage, editRegDate, setEditingDetails, setEditName, setEditDisplayNameOverview, setEditAddress, setEditSuburb, setEditStage, setEditRegDate, onSaveDetails, showRemoveModal, setShowRemoveModal, showAssignModal, setShowAssignModal, editingAgreement, setEditingAgreement, agrStartDate, setAgrStartDate, agrDuration, setAgrDuration, setAgreement, toast, currentBM, currentConcierge, updatePersonnel, currentDeveloper, setDeveloperState, currentRelationship, inRenewalWindow, changeRelationshipStatus, recordRenewalEvent, latestRenewalOutcome }: any) {
  const [, setLocation] = useLocation();
  const { view } = usePortalView();

  const overrides = displayBuilding._overrides;
  const startEdit = () => {
    setEditName(displayBuilding.name);
    setEditDisplayNameOverview(overrides?.displayName || displayBuilding.name);
    setEditAddress(displayBuilding.address);
    setEditSuburb(displayBuilding.suburb);
    setEditStage(displayBuilding.stage);
    setEditRegDate(overrides?.regDate || '');
    setEditingDetails(true);
  };

  const saveEdit = () => {
    onSaveDetails({ name: editName, displayName: editDisplayNameOverview, address: editAddress, suburb: editSuburb, stage: editStage, regDate: editRegDate });
    setEditingDetails(false);
    toast({ title: 'Building updated.' });
  };

  const startEditAgreement = () => {
    if (agreement) {
      setAgrStartDate(agreement.startDate);
      setAgrDuration(agreement.durationYears);
    }
    setEditingAgreement(true);
  };

  const saveAgreement = () => {
    const parts = agrStartDate.split(' ');
    const months: Record<string, number> = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
    if (parts.length === 3) {
      const startD = new Date(parseInt(parts[2]), months[parts[1]], parseInt(parts[0]));
      const expD = new Date(startD);
      expD.setFullYear(expD.getFullYear() + agrDuration);
      const expStr = `${String(expD.getDate()).padStart(2, '0')} ${Object.keys(months).find(k => months[k] === expD.getMonth())} ${expD.getFullYear()}`;
      setAgreement({ startDate: agrStartDate, durationYears: agrDuration, expiryDate: expStr, status: 'Active' as const });
    }
    setEditingAgreement(false);
    toast({ title: 'Agreement updated' });
  };

  const assignAgreement = () => {
    const parts = agrStartDate.split(' ');
    const months: Record<string, number> = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
    if (parts.length === 3) {
      const startD = new Date(parseInt(parts[2]), months[parts[1]], parseInt(parts[0]));
      const expD = new Date(startD);
      expD.setFullYear(expD.getFullYear() + agrDuration);
      const expStr = `${String(expD.getDate()).padStart(2, '0')} ${Object.keys(months).find(k => months[k] === expD.getMonth())} ${expD.getFullYear()}`;
      setAgreement({ startDate: agrStartDate, durationYears: agrDuration, expiryDate: expStr, status: 'Active' as const });
    }
    setShowAssignModal(false);
    toast({ title: 'Agreement assigned' });
  };

  const removeAgreement = () => {
    setAgreement(null);
    setShowRemoveModal(false);
    toast({ title: 'Agreement removed', description: 'T badge has been removed.' });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold">Building Details</CardTitle>
              {!editingDetails && (
                <button onClick={startEdit} className="text-gray-400 hover:text-gray-600" data-testid="btn-edit-details">
                  <Pencil className="w-4 h-4" />
                </button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {editingDetails ? (
              <div className="space-y-3">
                <FieldInput label="Building Name" value={editName} onChange={setEditName} testId="input-edit-name" />
                <FieldInput label="Display Name" value={editDisplayNameOverview} onChange={setEditDisplayNameOverview} testId="input-edit-display-name" />
                {(editStage === 'Registered' || editStage === 'Established') && (
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">UP Number</label>
                    {building.upNumber ? (
                      <p className="text-sm text-gray-500 mt-1">{building.upNumber}</p>
                    ) : (
                      <p className="text-sm text-gray-400 italic mt-1">Not yet registered — UP number assigned on registration</p>
                    )}
                  </div>
                )}
                <FieldInput label="Address" value={editAddress} onChange={setEditAddress} testId="input-edit-address" />
                <FieldInput label="Suburb" value={editSuburb} onChange={setEditSuburb} testId="input-edit-suburb" />
                <div>
                  <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">State</label>
                  <p className="text-sm text-gray-500 mt-1">{building.state}</p>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Building Stage</label>
                  <select value={editStage} onChange={e => setEditStage(e.target.value as BuildingStage)} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="select-edit-stage">
                    <option value="Development">Development</option>
                    <option value="Pre-Settlement">Pre-Settlement</option>
                    <option value="Registered">Registered</option>
                    <option value="Established">Established</option>
                  </select>
                </div>
                {(editStage === 'Registered' || editStage === 'Established') && (
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Registration Date *</label>
                    <p className="text-[10px] text-gray-400 mt-0.5 mb-1">The date the UP was formally registered. This is used to calculate the Established Date (Registration Date + 3 months).</p>
                    <input type="date" value={editRegDate} onChange={e => setEditRegDate(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-edit-reg-date" />
                  </div>
                )}
                {editStage === 'Established' && editRegDate && (
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Established Date</label>
                    <p className="text-sm text-gray-900 mt-1">{(() => { const d = new Date(editRegDate); d.setMonth(d.getMonth() + 3); return d.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' }); })()}</p>
                    <p className="text-[10px] text-gray-400 mt-0.5">Automatically set 3 months after registration. Building stage updates to Established on this date.</p>
                  </div>
                )}
                <div className="flex gap-2 pt-2">
                  <button onClick={saveEdit} className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-save-details">Save Changes</button>
                  <button onClick={() => setEditingDetails(false)} className="px-4 py-2 border border-gray-200 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-50" data-testid="btn-cancel-details">Cancel</button>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5">
                <ReadRow label="Building Name" value={displayBuilding.name} />
                <ReadRow label="Display Name" value={overrides?.displayName || displayBuilding.name} />
                {(displayBuilding.stage === 'Registered' || displayBuilding.stage === 'Established') ? (
                  <ReadRow label="UP Number" value={displayBuilding.upNumber || '—'} />
                ) : (
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">UP Number</span>
                    <span className="text-sm text-gray-400 italic">Not yet registered — UP number assigned on registration</span>
                  </div>
                )}
                <ReadRow label="Address" value={displayBuilding.address} />
                <ReadRow label="Suburb" value={displayBuilding.suburb} />
                <ReadRow label="State" value={displayBuilding.state} />
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Total Units</span>
                  <div className="text-right">
                    <span className="text-sm text-gray-900">{displayBuilding.totalUnits}</span>
                    <p className="text-[10px] text-gray-400">Set at the building level — reflects total lots regardless of unit records loaded.</p>
                  </div>
                </div>
                <ReadRow label="Building Stage" value={displayBuilding.stage} />
                {(displayBuilding.stage === 'Registered' || displayBuilding.stage === 'Established') && (
                  <>
                    <ReadRow label="Registration Date" value={overrides?.regDate || displayBuilding.registrationDate || '—'} />
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Established Date</span>
                      <div className="text-right">
                        <span className="text-sm text-gray-900">{displayBuilding.establishedDate || '—'}</span>
                        {displayBuilding.establishedDate && (
                          <p className="text-[10px] text-gray-400">Automatically set 3 months after registration. Building stage updates to Established on this date.</p>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {strata?.isPartner && (
          <Card data-testid="card-strata-management">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold">Strata Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Managed By</span>
                  <span className="ml-auto inline-flex items-center gap-1.5">
                    <span className="text-sm text-gray-900" data-testid="text-strata-name">{strata.name}</span>
                    {view.mode !== 'strata' && (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-purple-50 text-purple-700 border border-purple-200" title="Taylr partner strata">Partner</span>
                    )}
                  </span>
                </div>
                {building.agreementStart ? (
                  <>
                    <ReadRow label="Start Date" value={building.agreementStart} />
                    {building.agreementTerm && <ReadRow label="Term" value={building.agreementTerm} />}
                    {(() => {
                      const state = getStrataAgreementState(building);
                      const dotColour =
                        state.status === 'active' ? 'bg-emerald-500'
                        : state.status === 'terminated' ? 'bg-gray-400'
                        : 'bg-red-500';
                      const statusLabel =
                        state.status === 'active' ? 'Active'
                        : state.status === 'terminated' ? 'Terminated'
                        : 'Expired';
                      return (
                        <>
                          {state.expiryLabel && <ReadRow label="Expires" value={state.expiryLabel} />}
                          <div className="flex items-center gap-1.5" title={state.tooltip}>
                            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Status</span>
                            <span className="ml-auto flex items-center gap-1.5 text-sm">
                              <span className={`w-2 h-2 rounded-full ${dotColour}`} />
                              <span className="text-gray-900" data-testid="text-strata-agreement-status">{statusLabel}</span>
                            </span>
                          </div>
                        </>
                      );
                    })()}
                  </>
                ) : (
                  <p className="text-xs text-gray-400 mt-2">Management contract details not on file. Ask {strata.name} for the current strata management agreement.</p>
                )}
                {(() => {
                  const opp = getOpportunitySize(building);
                  if (opp.strataFeePerUnit === null || opp.strataAnnualMgmtFee === null) return null;
                  return (
                    <div className="mt-3 pt-3 border-t border-gray-100 space-y-2.5" data-testid="section-strata-fees">
                      <ReadRow label="Mgmt Fee" value={`${formatAud(opp.strataFeePerUnit)} / unit / yr`} />
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Strata Annual Fee</span>
                        <span className="ml-auto text-sm font-semibold text-gray-900" data-testid="text-strata-annual-value">
                          {formatAud(opp.strataAnnualMgmtFee)}
                          <span className="ml-1 text-[10px] font-medium text-gray-400">{opp.isAgreed ? 'agreed' : 'anticipated'}</span>
                        </span>
                      </div>
                    </div>
                  );
                })()}
                {building.previousStrata && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Previous Strata</p>
                    <p className="text-xs text-gray-600">{building.previousStrata}</p>
                  </div>
                )}
                <p className="text-[11px] text-gray-400 mt-3 pt-3 border-t border-gray-100">Sourced from {strata.name} — Taylr admin cannot edit a partner's internal management contract.</p>
              </div>
            </CardContent>
          </Card>
        )}

        <DeveloperCard
          building={building}
          developer={currentDeveloper}
          setDeveloperState={setDeveloperState}
          toast={toast}
          isAdmin={true}
        />

        {/* Taylr Agreement card is admin-only. Strata users still have
            access to the agreement document under the Files tab, but the
            commercial terms (start/expiry/duration/revenue) belong to
            Taylr's view of the relationship. */}
        {view.mode !== 'strata' && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold">Taylr Agreement</CardTitle>
              {agreement && !editingAgreement && (
                <div className="flex items-center gap-1.5">
                  <button onClick={startEditAgreement} className="text-gray-400 hover:text-gray-600" data-testid="btn-edit-agreement">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => setShowRemoveModal(true)} className="text-gray-400 hover:text-gray-600" data-testid="btn-remove-agreement">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {agreement ? (
              <div className="space-y-4">
                {editingAgreement ? (
                  <div className="space-y-3 pt-2">
                    <FieldInput label="Start Date" value={agrStartDate} onChange={setAgrStartDate} testId="input-agr-start" placeholder="e.g. 01 Jan 2024" />
                    <div>
                      <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Duration (years)</label>
                      <input type="number" value={agrDuration} onChange={e => setAgrDuration(parseInt(e.target.value) || 1)} min={1} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-agr-duration" />
                    </div>
                    <div className="flex gap-2">
                      <button onClick={saveAgreement} className="px-4 py-2 bg-[#ED017F] text-white text-xs font-medium rounded-lg" data-testid="btn-save-agreement">Save</button>
                      <button onClick={() => setEditingAgreement(false)} className="px-4 py-2 border border-gray-200 text-gray-600 text-xs font-medium rounded-lg" data-testid="btn-cancel-agreement">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <ReadRow label="Start Date" value={agreement.startDate} />
                    <ReadRow label="Duration" value={`${agreement.durationYears} years`} />
                    <ReadRow label="Expires" value={agreement.expiryDate} />
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Status</span>
                      <span className="ml-auto flex items-center gap-1.5 text-sm">
                        <span className={`w-2 h-2 rounded-full ${agreementExpired ? 'bg-red-500' : 'bg-emerald-500'}`} />
                        <span className="text-gray-900">{agreementExpired ? 'Expired' : 'Active'}</span>
                      </span>
                    </div>
                    {latestRenewalOutcome && (
                      <div
                        className={`flex items-start gap-2 p-2.5 rounded-lg mt-3 border ${
                          latestRenewalOutcome.kind === 'won'
                            ? 'bg-emerald-50 border-emerald-200'
                            : 'bg-gray-50 border-gray-200'
                        }`}
                        data-testid="agreement-renewal-outcome"
                      >
                        {latestRenewalOutcome.kind === 'won'
                          ? <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          : <X className="w-3.5 h-3.5 text-gray-500 shrink-0 mt-0.5" />}
                        <span className={`text-xs ${latestRenewalOutcome.kind === 'won' ? 'text-emerald-800' : 'text-gray-700'}`}>
                          {latestRenewalOutcome.kind === 'won'
                            ? `Renewed ${latestRenewalOutcome.date}${latestRenewalOutcome.term ? ` · ${latestRenewalOutcome.term} term` : ''}`
                            : `Renewal Lost ${latestRenewalOutcome.date}${latestRenewalOutcome.reason ? ` — ${latestRenewalOutcome.reason}` : ''}`}
                        </span>
                      </div>
                    )}
                    {expiringWithin90 && !latestRenewalOutcome && (
                      <div className="flex items-start gap-2 p-2.5 bg-amber-50 border border-amber-200 rounded-lg mt-3">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span className="text-xs text-amber-800">Agreement expiring soon — due for renewal {agreement.expiryDate}</span>
                      </div>
                    )}

                    {(() => {
                      const bldgPayments = paymentOrders.filter(o => o.building === building.name);
                      const paidOrFulfilled = bldgPayments.filter(o => o.status === 'Fulfilled' || o.status === 'Paid');
                      const totalGross = paidOrFulfilled.reduce((s, o) => s + o.gross, 0);
                      const totalNet = paidOrFulfilled.reduce((s, o) => s + (o.netPaid - o.stripeFee), 0);
                      return (
                        <div className="mt-3 pt-3 border-t border-gray-100">
                          <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Revenue (this month)</p>
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-500">Orders</span>
                              <span className="text-sm text-gray-800" data-testid="agr-revenue-orders">{paidOrFulfilled.length}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-500">Gross</span>
                              <span className="text-sm text-gray-800" data-testid="agr-revenue-gross">${totalGross.toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-500">Net</span>
                              <span className="text-sm text-gray-800" data-testid="agr-revenue-net">${totalNet.toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                          </div>
                          <button onClick={() => setLocation('/modules/finance')} className="text-xs text-[#ED017F] hover:text-[#d0016e] font-medium flex items-center gap-0.5 mt-2" data-testid="btn-agr-view-finance">
                            View in Finance <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-center py-4">
                  <p className="text-sm font-medium text-gray-500">No direct agreement</p>
                  <p className="text-xs text-gray-400 mt-1">This building does not have a direct Taylr agreement. Services are provided via the strata company appointment only.</p>
                </div>
                <button onClick={() => { setAgrStartDate(''); setAgrDuration(3); setShowAssignModal(true); }} className="w-full px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-assign-agreement">Assign Agreement</button>
              </div>
            )}
          </CardContent>
        </Card>
        )}
      </div>

      {view.mode !== 'strata' && (
      <OriginAndHistoryCard
        building={building}
        agreement={agreement}
        isAdminView={true}
        currentRelationship={currentRelationship}
        inRenewalWindow={inRenewalWindow}
        onMarkRenewalWon={(notes, term) => {
          const parts = ['Marked Renewal Won'];
          if (term) parts.push(`Renewed term: ${term}`);
          if (notes) parts.push(`Notes: ${notes}`);
          changeRelationshipStatus('Won', undefined, { silent: true });
          recordRenewalEvent(parts.join(' · '));
        }}
        onMarkRenewalLost={(reason, notes) => {
          const parts = [`Marked Renewal Lost — Reason: ${reason}`];
          if (notes) parts.push(`Notes: ${notes}`);
          changeRelationshipStatus('Expired Lost', undefined, { silent: true });
          recordRenewalEvent(parts.join(' · '));
        }}
      />

      )}

      {view.mode !== 'strata' && (
      <RevenueSharingCard
        building={building}
        displayBuilding={displayBuilding}
        developer={currentDeveloper}
        setDeveloperState={setDeveloperState}
        toast={toast}
      />
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold">Strata & Contacts</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {currentRelationship === 'Unassigned' && building.previousStrata ? (
            <div className="space-y-2">
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-medium text-gray-500">Unassigned</span>
              </div>
              <p className="text-xs text-gray-500">Previous: {building.previousStrata} (lost 14 Mar 2026)</p>
              <p className="text-xs text-gray-400 mt-1">Assign new strata company</p>
            </div>
          ) : currentRelationship === 'Expired Lost' && building.previousStrata ? (
            <div className="space-y-2">
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-medium text-gray-400">Lost</span>
              </div>
              <p className="text-xs text-gray-500">Previous: {building.previousStrata} (management lost)</p>
            </div>
          ) : strata && (
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                {strata.isPartner && <Handshake className="w-4 h-4 text-emerald-600" />}
                <span className="text-sm font-medium text-gray-900">{strata.name}</span>
              </div>
              <p className="text-xs text-gray-400">vantagestrata.com.au</p>
              {strata.isPartner && (
                <button onClick={() => setLocation('/modules/strata/vantage-strata')} className="flex items-center gap-1 text-xs text-[#ED017F] hover:underline mt-1" data-testid="link-view-strata">
                  View in Strata module <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          )}
          <div className="border-t border-gray-100 pt-3">
            <h4 className="text-xs font-semibold text-gray-900 mb-1">Building Contacts</h4>
            <p className="text-[11px] text-gray-400 mb-3">Resolved from building assignments in the Strata module.</p>
            {building.contacts.length > 0 ? (
              <div className="space-y-2.5">
                {building.contacts.map((c: any, i: number) => {
                  const availSummary = c.role === 'Building Manager' && c.availability ? formatContactAvailability(c) : '';
                  return (
                  <div key={i} className="bg-gray-50 border border-gray-100 rounded-lg p-3" data-testid={`contact-card-${i}`}>
                    <p className="text-sm font-medium text-gray-900">{c.name}</p>
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 mt-1">{c.role}</span>
                    <p className="text-xs text-gray-500 mt-1.5">{c.email}</p>
                    <p className="text-xs text-gray-500">{c.phone}</p>
                    {availSummary && <p className="text-xs text-gray-400 mt-1">{availSummary}</p>}
                  </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-gray-400 italic">No contacts assigned yet — assign via Strata module.</p>
            )}
          </div>
        </CardContent>
      </Card>

      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Building Images</h3>
        <div className="grid grid-cols-3 gap-4">
          {['Primary Image', 'Secondary Image', 'Image 3'].map(label => (
            <button
              key={label}
              onClick={() => toast({ title: 'Upload simulated', description: 'Not available in demo' })}
              className="border-2 border-dashed border-gray-200 rounded-xl py-10 flex flex-col items-center justify-center gap-2 hover:border-[#ED017F]/30 hover:bg-pink-50/20 transition-colors group"
              data-testid={`upload-${label.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <ImageIcon className="w-8 h-8 text-gray-300 group-hover:text-[#ED017F]/40" />
              <span className="text-xs text-gray-400 font-medium">{label}</span>
              <span className="text-[11px] text-gray-300 group-hover:text-gray-500">Upload Image</span>
            </button>
          ))}
        </div>
        <p className="text-[11px] text-gray-400 mt-2">Building images are used in member-facing materials and owner communications.</p>
      </div>

      <OnSitePersonnelCard
        role="Building Manager"
        data={currentBM}
        onSave={d => { updatePersonnel('bm', d); toast({ title: 'Building Manager details updated.' }); }}
        onRemove={() => { updatePersonnel('bm', null); toast({ title: 'Building Manager removed.' }); }}
        toast={toast}
      />

      <OnSitePersonnelCard
        role="Concierge"
        data={currentConcierge}
        onSave={d => { updatePersonnel('concierge', d); toast({ title: 'Concierge details updated.' }); }}
        onRemove={() => { updatePersonnel('concierge', null); toast({ title: 'Concierge removed.' }); }}
        toast={toast}
      />

      {showRemoveModal && (
        <Modal onClose={() => setShowRemoveModal(false)}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Remove Taylr Agreement</h3>
          <p className="text-sm text-gray-600 mb-6">Remove Taylr agreement for {building.name}? The T badge will be removed.</p>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowRemoveModal(false)} className="px-4 py-2 border border-gray-200 text-sm rounded-lg" data-testid="btn-modal-cancel">Cancel</button>
            <button onClick={removeAgreement} className="px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700" data-testid="btn-modal-remove">Remove</button>
          </div>
        </Modal>
      )}

      {showAssignModal && (
        <Modal onClose={() => setShowAssignModal(false)}>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Assign Agreement</h3>
          <div className="space-y-3 mb-6">
            <FieldInput label="Start Date" value={agrStartDate} onChange={setAgrStartDate} testId="input-assign-start" placeholder="e.g. 01 Jan 2024" />
            <div>
              <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Duration (years)</label>
              <input type="number" value={agrDuration} onChange={e => setAgrDuration(parseInt(e.target.value) || 1)} min={1} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-assign-duration" />
            </div>
          </div>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowAssignModal(false)} className="px-4 py-2 border border-gray-200 text-sm rounded-lg" data-testid="btn-assign-cancel">Cancel</button>
            <button onClick={assignAgreement} className="px-4 py-2 bg-[#ED017F] text-white text-sm rounded-lg" data-testid="btn-assign-confirm">Confirm Agreement</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function DeveloperCard({ building, developer, setDeveloperState, toast, isAdmin }: any) {
  const [editing, setEditing] = useState(false);
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [form, setForm] = useState({
    companyName: '', abn: '', website: '', address: '',
    contactName: '', contactTitle: '', contactEmail: '', contactPhone: '',
  });

  const startEdit = () => {
    if (developer) {
      setForm({
        companyName: developer.companyName || '',
        abn: developer.abn || '',
        website: developer.website || '',
        address: developer.address || '',
        contactName: developer.primaryContact?.name || '',
        contactTitle: developer.primaryContact?.title || '',
        contactEmail: developer.primaryContact?.email || '',
        contactPhone: developer.primaryContact?.phone || '',
      });
    } else {
      setForm({ companyName: '', abn: '', website: '', address: '', contactName: '', contactTitle: '', contactEmail: '', contactPhone: '' });
    }
    setEditing(true);
  };

  const saveEdit = () => {
    const existingRevSharing = developer?.revenueSharing || { agreementInPlace: false };
    const updated: Developer = {
      companyName: form.companyName,
      abn: form.abn || undefined,
      website: form.website || undefined,
      address: form.address || undefined,
      primaryContact: { name: form.contactName, title: form.contactTitle || undefined, email: form.contactEmail, phone: form.contactPhone || undefined },
      revenueSharing: existingRevSharing,
    };
    setDeveloperState((prev: any) => ({ ...prev, [building.id]: updated }));
    setEditing(false);
    toast({ title: 'Developer details updated.' });
  };

  const removeDeveloper = () => {
    setDeveloperState((prev: any) => ({ ...prev, [building.id]: null }));
    setShowRemoveModal(false);
    toast({ title: 'Developer removed.' });
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold">Developer</CardTitle>
              <p className="text-[11px] text-gray-400 mt-0.5">The property developer for this building.</p>
            </div>
            {isAdmin && developer && !editing && (
              <div className="flex items-center gap-1.5">
                <button onClick={startEdit} className="text-gray-400 hover:text-gray-600" data-testid="btn-edit-developer">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => setShowRemoveModal(true)} className="text-gray-400 hover:text-gray-600" data-testid="btn-remove-developer">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {editing ? (
            <div className="space-y-4">
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Developer Details</p>
                <div className="space-y-2">
                  <FieldInput label="Company Name" value={form.companyName} onChange={v => setForm(f => ({ ...f, companyName: v }))} testId="input-dev-company" />
                  <FieldInput label="ABN" value={form.abn} onChange={v => setForm(f => ({ ...f, abn: v }))} testId="input-dev-abn" />
                  <FieldInput label="Website" value={form.website} onChange={v => setForm(f => ({ ...f, website: v }))} testId="input-dev-website" />
                  <FieldInput label="Address" value={form.address} onChange={v => setForm(f => ({ ...f, address: v }))} testId="input-dev-address" />
                </div>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Primary Contact</p>
                <div className="space-y-2">
                  <FieldInput label="Name" value={form.contactName} onChange={v => setForm(f => ({ ...f, contactName: v }))} testId="input-dev-contact-name" />
                  <FieldInput label="Title / Role" value={form.contactTitle} onChange={v => setForm(f => ({ ...f, contactTitle: v }))} testId="input-dev-contact-title" />
                  <FieldInput label="Email" value={form.contactEmail} onChange={v => setForm(f => ({ ...f, contactEmail: v }))} testId="input-dev-contact-email" />
                  <FieldInput label="Phone" value={form.contactPhone} onChange={v => setForm(f => ({ ...f, contactPhone: v }))} testId="input-dev-contact-phone" />
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={saveEdit} className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-save-developer">Save Changes</button>
                <button onClick={() => setEditing(false)} className="px-4 py-2 border border-gray-200 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-50" data-testid="btn-cancel-developer">Cancel</button>
              </div>
            </div>
          ) : developer ? (
            <div className="space-y-4">
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Developer Details</p>
                <div className="space-y-2">
                  <ReadRow label="Company Name" value={developer.companyName} />
                  {developer.abn && <ReadRow label="ABN" value={developer.abn} />}
                  {developer.website && <ReadRow label="Website" value={developer.website} />}
                  {developer.address && <ReadRow label="Address" value={developer.address} />}
                </div>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Primary Contact</p>
                <div className="space-y-2">
                  <ReadRow label="Name" value={developer.primaryContact.name} />
                  {developer.primaryContact.title && <ReadRow label="Title / Role" value={developer.primaryContact.title} />}
                  <ReadRow label="Email" value={developer.primaryContact.email} />
                  {developer.primaryContact.phone && <ReadRow label="Phone" value={developer.primaryContact.phone} />}
                </div>
              </div>
              
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-gray-400 italic">No developer details recorded.</p>
              {isAdmin && (
                <button onClick={startEdit} className="mt-3 px-4 py-2 border border-gray-200 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-50" data-testid="btn-add-developer">+ Add Developer</button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {showRemoveModal && (
        <Modal onClose={() => setShowRemoveModal(false)}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Remove Developer</h3>
          <p className="text-sm text-gray-600 mb-6">Remove developer details for {building.name}?</p>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowRemoveModal(false)} className="px-4 py-2 border border-gray-200 text-sm rounded-lg" data-testid="btn-modal-cancel-dev">Cancel</button>
            <button onClick={removeDeveloper} className="px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700" data-testid="btn-modal-remove-dev">Remove</button>
          </div>
        </Modal>
      )}
    </>
  );
}

function RevenueSharingCard({ building, displayBuilding, developer, setDeveloperState, toast }: any) {
  const [editing, setEditing] = useState(false);
  const [showRemoveModal, setShowRemoveModal] = useState(false);

  const rs: RevenueSharing | undefined = developer?.revenueSharing;
  const hasAgreement = rs?.agreementInPlace === true;

  interface PartyForm {
    name: string;
    partyType: 'Developer' | 'Third Party';
    percent: number;
    contactName: string;
    contactEmail: string;
    contactPhone: string;
  }

  const [parties, setParties] = useState<PartyForm[]>([]);
  const [serviceCategories, setServiceCategories] = useState<ServiceCategory[]>([]);
  const [appliesFrom, setAppliesFrom] = useState('');
  const [termMonths, setTermMonths] = useState(3);
  const [notes, setNotes] = useState('');

  const startEdit = () => {
    if (hasAgreement && rs) {
      if (rs.parties && rs.parties.length > 0) {
        setParties(rs.parties.map(p => ({
          name: p.name,
          partyType: p.partyType || 'Developer',
          percent: p.percent,
          contactName: p.contactName || '',
          contactEmail: p.contactEmail || '',
          contactPhone: p.contactPhone || '',
        })));
      } else {
        setParties([{ name: '', partyType: 'Developer', percent: rs.sharePercent || 0, contactName: '', contactEmail: '', contactPhone: '' }]);
      }
      setServiceCategories(rs.serviceCategories || []);
      setAppliesFrom(rs.appliesFrom || '');
      setTermMonths(rs.termMonths || 3);
      setNotes(rs.notes || '');
    } else {
      setParties([{ name: '', partyType: 'Developer', percent: 0, contactName: '', contactEmail: '', contactPhone: '' }]);
      setServiceCategories([]);
      setAppliesFrom('');
      setTermMonths(3);
      setNotes('');
    }
    setEditing(true);
  };

  const saveEdit = () => {
    const validParties = parties.filter(p => p.name.trim());
    const totalPercent = validParties.reduce((sum, p) => sum + p.percent, 0);
    const updatedRS: RevenueSharing = {
      agreementInPlace: true,
      sharePercent: totalPercent,
      parties: validParties.map(p => ({
        name: p.name,
        partyType: p.partyType,
        percent: p.percent,
        contactName: p.contactName || undefined,
        contactEmail: p.contactEmail || undefined,
        contactPhone: p.contactPhone || undefined,
      })),
      serviceCategories,
      appliesFrom: appliesFrom || undefined,
      termMonths,
      notes: notes || undefined,
    };
    if (developer) {
      setDeveloperState((prev: any) => ({ ...prev, [building.id]: { ...developer, revenueSharing: updatedRS } }));
    }
    setEditing(false);
    toast({ title: 'Revenue sharing agreement updated.' });
  };

  const removeAgreement = () => {
    if (developer) {
      setDeveloperState((prev: any) => ({ ...prev, [building.id]: { ...developer, revenueSharing: { agreementInPlace: false } } }));
    }
    setShowRemoveModal(false);
    toast({ title: 'Revenue sharing agreement removed.' });
  };

  const addParty = () => {
    setParties(prev => [...prev, { name: '', partyType: 'Third Party', percent: 0, contactName: '', contactEmail: '', contactPhone: '' }]);
  };

  const removeParty = (idx: number) => {
    setParties(prev => prev.filter((_, i) => i !== idx));
  };

  const updateParty = (idx: number, field: keyof PartyForm, value: any) => {
    setParties(prev => prev.map((p, i) => i === idx ? { ...p, [field]: value } : p));
  };

  const totalPercent = parties.reduce((sum, p) => sum + p.percent, 0);

  const allServiceCategories: { value: ServiceCategory; label: string; sublabel: string }[] = [
    { value: 'Pre-Settlement Services', label: 'Pre-Settlement Services', sublabel: 'Services delivered to incoming owners and buyers during the pre-settlement phase. Includes: TV Wall Mount, Depreciation Report, and any other services tagged as Pre-Settlement.' },
    { value: 'Onboarding Services', label: 'Onboarding Services', sublabel: 'Member onboarding and welcome flow services.' },
    { value: 'Utility Connection Services', label: 'Utility Connection Services', sublabel: 'Electricity, internet, gas and other connection services.' },
    { value: 'All Taylr Services', label: 'All Taylr Services', sublabel: 'Revenue share applies to all services delivered by Taylr at this building. Use with caution.' },
  ];

  const toggleCategory = (cat: ServiceCategory) => {
    setServiceCategories(prev =>
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const getSharingEndsDate = () => {
    if (!appliesFrom || !termMonths) return null;
    const d = new Date(appliesFrom);
    if (isNaN(d.getTime())) return null;
    d.setMonth(d.getMonth() + termMonths);
    return d.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const getSharingEndsDateFromRS = (revSharing: RevenueSharing) => {
    if (!revSharing.appliesFrom || !revSharing.termMonths) return null;
    const d = new Date(revSharing.appliesFrom);
    if (isNaN(d.getTime())) return null;
    d.setMonth(d.getMonth() + revSharing.termMonths);
    return d.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold">Pre-Settlement Revenue Sharing</CardTitle>
            </div>
            {hasAgreement && !editing && (
              <div className="flex items-center gap-1.5">
                <button onClick={startEdit} className="text-gray-400 hover:text-gray-600" data-testid="btn-edit-revenue-sharing">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => setShowRemoveModal(true)} className="text-gray-400 hover:text-gray-600" data-testid="btn-remove-revenue-sharing">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {editing ? (
            <div className="space-y-5">
              {parties.map((party, idx) => (
                <div key={idx} className="bg-gray-50 border border-gray-100 rounded-lg p-4 space-y-3" data-testid={`party-block-${idx}`}>
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Party {idx + 1}</p>
                    {parties.length > 1 && (
                      <button onClick={() => removeParty(idx)} className="text-xs text-red-500 hover:text-red-700" data-testid={`btn-remove-party-${idx}`}>Remove party</button>
                    )}
                  </div>
                  <FieldInput label="Party Name *" value={party.name} onChange={v => updateParty(idx, 'name', v)} testId={`input-party-name-${idx}`} />
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Party Type *</label>
                    <select value={party.partyType} onChange={e => updateParty(idx, 'partyType', e.target.value)} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`select-party-type-${idx}`}>
                      <option value="Developer">Developer</option>
                      <option value="Third Party">Third Party</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Share % *</label>
                    <input type="number" min={0} max={100} value={party.percent} onChange={e => updateParty(idx, 'percent', parseInt(e.target.value) || 0)} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid={`input-party-percent-${idx}`} />
                  </div>
                  <FieldInput label="Contact Name" value={party.contactName} onChange={v => updateParty(idx, 'contactName', v)} testId={`input-party-contact-name-${idx}`} />
                  <FieldInput label="Contact Email" value={party.contactEmail} onChange={v => updateParty(idx, 'contactEmail', v)} testId={`input-party-contact-email-${idx}`} />
                  <FieldInput label="Contact Phone" value={party.contactPhone} onChange={v => updateParty(idx, 'contactPhone', v)} testId={`input-party-contact-phone-${idx}`} />
                </div>
              ))}

              <button onClick={addParty} className="text-xs text-[#ED017F] hover:underline font-medium" data-testid="btn-add-party">+ Add Another Party</button>

              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Total Share:</span>
                <span className={`text-sm font-semibold ${totalPercent > 100 ? 'text-red-600' : 'text-gray-900'}`}>{totalPercent}%</span>
                {totalPercent !== 100 && totalPercent > 0 && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
                    <AlertTriangle className="w-3 h-3" /> Total ≠ 100%
                  </span>
                )}
              </div>

              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2 block">Service Categories</label>
                <div className="space-y-2">
                  {allServiceCategories.map(cat => (
                    <label key={cat.value} className="flex items-start gap-2 cursor-pointer" data-testid={`checkbox-rs-cat-${cat.value.toLowerCase().replace(/\s+/g, '-')}`}>
                      <input type="checkbox" checked={serviceCategories.includes(cat.value)} onChange={() => toggleCategory(cat.value)} className="mt-0.5 rounded border-gray-300" />
                      <div>
                        <span className="text-xs font-medium text-gray-700">{cat.label}</span>
                        <p className="text-[10px] text-gray-400 leading-tight">{cat.sublabel}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <FieldInput label="Applies From *" value={appliesFrom} onChange={setAppliesFrom} testId="input-rs-applies-from" />

              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Term (months) *</label>
                <p className="text-[10px] text-gray-400 mt-0.5 mb-1">Months from the Applies From date</p>
                <input type="number" min={1} max={60} value={termMonths} onChange={e => setTermMonths(parseInt(e.target.value) || 0)} placeholder="e.g. 6" className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-rs-term-months" />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Sharing Ends</label>
                {getSharingEndsDate() ? (
                  <p className="text-sm text-gray-500 italic mt-1">{getSharingEndsDate()}</p>
                ) : (
                  <p className="text-sm text-gray-400 italic mt-1">Set Applies From date and term to calculate</p>
                )}
              </div>

              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Notes</label>
                <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" placeholder="Optional notes about this agreement" data-testid="input-rs-notes" />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button onClick={saveEdit} className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-save-revenue-sharing">Save Changes</button>
                <button onClick={() => setEditing(false)} className="px-4 py-2 border border-gray-200 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-50" data-testid="btn-cancel-revenue-sharing">Cancel</button>
              </div>
              
            </div>
          ) : hasAgreement && rs ? (
            <div className="space-y-4">
              <div>
                <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Parties</p>
                {rs.parties && rs.parties.length > 0 ? (
                  <div className="space-y-1.5">
                    {rs.parties.map((p, i) => (
                      <div key={i} className="flex items-center justify-between text-sm" data-testid={`read-party-${i}`}>
                        <span className="text-gray-900">{p.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400 text-xs">{p.partyType}</span>
                          <span className="font-semibold text-gray-900">{p.percent}%</span>
                        </div>
                      </div>
                    ))}
                    <div className="flex items-center justify-between text-sm border-t border-gray-100 pt-1.5 mt-1.5">
                      <span className="text-gray-500 font-medium">Total</span>
                      <span className="font-semibold text-gray-900">{rs.parties.reduce((s, p) => s + p.percent, 0)}%</span>
                    </div>
                  </div>
                ) : rs.sharePercent ? (
                  <ReadRow label="Revenue Share" value={`${rs.sharePercent}%`} />
                ) : null}
              </div>

              {rs.serviceCategories && rs.serviceCategories.length > 0 && (
                <div>
                  <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Service Categories</p>
                  <div className="flex flex-wrap gap-1.5">
                    {rs.serviceCategories.map(cat => (
                      <span key={cat} className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-medium bg-gray-100 text-gray-600 border border-gray-200">{cat}</span>
                    ))}
                  </div>
                </div>
              )}

              {rs.appliesFrom && <ReadRow label="Applies From" value={rs.appliesFrom} />}
              <ReadRow label="Term" value={`${rs.termMonths || '—'} months`} />
              <ReadRow label="Sharing Ends" value={getSharingEndsDateFromRS(rs) || 'Not yet set'} />
              {rs.notes && <ReadRow label="Notes" value={rs.notes} />}
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-gray-400 italic">No revenue sharing agreement recorded for this building.</p>
              {developer && (
                <button onClick={startEdit} className="mt-3 px-4 py-2 border border-gray-200 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-50" data-testid="btn-add-revenue-sharing">+ Add Agreement</button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {showRemoveModal && (
        <Modal onClose={() => setShowRemoveModal(false)}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Remove Revenue Sharing Agreement</h3>
          <p className="text-sm text-gray-600 mb-6">Remove the revenue sharing agreement for {building.name}? This cannot be undone.</p>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowRemoveModal(false)} className="px-4 py-2 border border-gray-200 text-sm rounded-lg" data-testid="btn-modal-cancel-rs">Cancel</button>
            <button onClick={removeAgreement} className="px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700" data-testid="btn-modal-remove-rs">Remove</button>
          </div>
        </Modal>
      )}
    </>
  );
}

function ServicesTab({ building, services, setServices, toast, relationshipStatus, strata }: { building: Building; services: ServiceRow[]; setServices: (r: ServiceRow[]) => void; toast: any; relationshipStatus: RelationshipStatus; strata: ReturnType<typeof getStrataById> }) {
  const [, setLocation] = useLocation();
  const [showAssign, setShowAssign] = useState(false);
  const [selectedAssignService, setSelectedAssignService] = useState('');
  const [assignPriceOverride, setAssignPriceOverride] = useState('');
  const isLost = relationshipStatus === 'Expired Lost' || relationshipStatus === 'Agreement Expired';
  const isUnassigned = relationshipStatus === 'Unassigned';
  const buildingAssignableServices = useMemo(() => getBuildingAssignableServices(), []);

  const taylrServices = services.filter(s => s.type === 'taylr');
  const strataAppointedServices = services.filter(s => s.type === 'strata-appointed');

  const toggleService = (idx: number) => {
    if (isLost) return;
    const updated = [...services];
    updated[idx] = { ...updated[idx], enabled: !updated[idx].enabled };
    setServices(updated);
    toast({ title: updated[idx].enabled ? 'Service enabled' : 'Service disabled', description: updated[idx].name });
  };

  const removeService = (idx: number) => {
    if (isLost) return;
    const name = services[idx].name;
    setServices(services.filter((_, i) => i !== idx));
    toast({ title: 'Service removed', description: name });
  };

  const getGlobalIdx = (s: ServiceRow) => services.indexOf(s);

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Taylr Services</h2>
            <p className="text-sm text-gray-500">Services Taylr offers directly to members at this building.</p>
          </div>
          {!isLost && (
            <button onClick={() => setShowAssign(true)} className="flex items-center gap-1.5 px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-assign-service">
              <Plus className="w-3.5 h-3.5" />
              Assign Taylr Service
            </button>
          )}
        </div>

        <div className="space-y-3">
          {taylrServices.map((s) => {
            const gi = getGlobalIdx(s);
            return (
              <div key={gi} className={`flex items-center justify-between bg-white border border-gray-200 rounded-xl px-5 py-4 group ${isLost ? 'opacity-60' : ''}`} data-testid={`service-row-${gi}`}>
                <div>
                  <p className={`text-sm font-medium ${isLost ? 'text-gray-400' : 'text-gray-900'}`}>{s.name}</p>
                  <p className="text-xs text-gray-400 mt-0.5">Managed by: {s.managedBy}</p>
                  <p className="text-xs text-gray-400">{s.price}</p>
                </div>
                <div className="flex items-center gap-4">
                  {!isLost && (
                    <button onClick={() => toggleService(gi)} data-testid={`toggle-service-${gi}`}>
                      {s.enabled ? <ToggleRight className="w-6 h-6 text-emerald-500" /> : <ToggleLeft className="w-6 h-6 text-gray-300" />}
                    </button>
                  )}
                  {isLost && <span className="text-xs text-gray-400">Suspended</span>}
                  {!isLost && (
                    <button onClick={() => removeService(gi)} className="opacity-0 group-hover:opacity-100 text-gray-300 hover:text-red-500 transition-all" data-testid={`remove-service-${gi}`}>
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {taylrServices.length === 0 && !isLost && (
            <p className="text-sm text-gray-400 text-center py-8">No Taylr services assigned to this building.</p>
          )}
          {isLost && taylrServices.length === 0 && (
            <p className="text-sm text-gray-400 text-center py-8">All services are suspended. Building status: Lost.</p>
          )}
        </div>
      </div>

      {strataAppointedServices.length > 0 && (
        <div>
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Strata Appointed Services</h2>
            <p className="text-sm text-gray-500">Services Taylr manages on behalf of the appointed strata company. Configured by Taylr admin in the Strata module.</p>
          </div>

          <div className="flex items-start gap-2 p-3 bg-gray-50 border border-gray-200 rounded-lg mb-4">
            <Lock className="w-3.5 h-3.5 text-gray-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-gray-500">These services are configured by Taylr admin in the Strata module. Contact the Taylr team to update.</p>
              <button onClick={() => setLocation('/modules/strata/vantage-strata')} className="flex items-center gap-1 text-xs text-[#ED017F] hover:underline mt-1" data-testid="link-strata-services">
                View in Strata module <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {strataAppointedServices.map((s) => {
              const gi = getGlobalIdx(s);
              const rules = s.rules;
              const isSuspended = isLost && (rules?.disableWhenLost !== false);
              const isS119Service = isS119RentalServiceName(s.name);
              const s119Unavailable = isS119Service && !isS119RentalAvailableForBuilding(building, strata);
              const s119Reason = s119Unavailable ? s119UnavailableReason(building, strata) : null;
              // S119 unavailability supersedes the generic "paused on unassigned"
              // rule: if the service is structurally not available, the building
              // can't order or pay for it — there's nothing to pause.
              const isPaused = !s119Unavailable && isUnassigned && (rules?.pauseWhenUnassigned !== false);
              let statusLabel = s.enabled ? 'Enabled' : 'Disabled';
              let statusClasses = s.enabled ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-gray-100 text-gray-500 border border-gray-200';
              let ruleNote: string | null = null;
              if (s119Unavailable) {
                statusLabel = 'Unavailable';
                statusClasses = 'bg-gray-100 text-gray-500 border border-gray-200';
                ruleNote = 'Rule: Strata not engaged for S119';
              } else if (isSuspended) {
                statusLabel = 'Suspended';
                statusClasses = 'bg-red-50 text-red-600 border border-red-200';
                ruleNote = 'Rule: Lost';
              } else if (isPaused) {
                statusLabel = 'Paused';
                statusClasses = 'bg-amber-50 text-amber-700 border border-amber-200';
                ruleNote = 'Rule: Unassigned';
              }
              return (
                <div key={gi} className={`flex items-center justify-between bg-white border border-gray-200 rounded-xl px-5 py-4 ${(isSuspended || s119Unavailable) ? 'opacity-60' : ''}`} data-testid={`service-row-${gi}`}>
                  <div>
                    <p className={`text-sm font-medium ${(isSuspended || s119Unavailable) ? 'text-gray-400' : 'text-gray-900'}`}>{s.name}</p>
                    <p className="text-xs text-gray-400 mt-0.5">Managed by: {s.managedBy}</p>
                    <p className="text-xs text-gray-400">{s.price}</p>
                    {s119Unavailable && s119Reason && (
                      <p className="text-xs text-red-600 mt-1.5" data-testid={`text-s119-unavailable-reason-${gi}`}>
                        {s119Reason} Agents and OCs cannot order or pay for an S119 cert at this building.
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-medium ${statusClasses}`}>
                      {statusLabel}
                    </span>
                    {ruleNote && (
                      <span className="text-[10px] text-gray-400">{ruleNote}</span>
                    )}
                    <Lock className="w-4 h-4 text-gray-300" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {showAssign && (
        <Modal onClose={() => { setShowAssign(false); setSelectedAssignService(''); setAssignPriceOverride(''); }}>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Assign Taylr Service</h3>
          <div className="space-y-3 mb-6">
            <div>
              <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Service</label>
              <select value={selectedAssignService} onChange={e => { setSelectedAssignService(e.target.value); const cs = buildingAssignableServices.find(s => s.name === e.target.value); setAssignPriceOverride(cs?.defaultPrice || ''); }} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="select-service">
                <option value="">Select a service…</option>
                {buildingAssignableServices.map(cs => (
                  <option key={cs.id} value={cs.name}>{cs.name}</option>
                ))}
              </select>
              {selectedAssignService && (() => { const cs = buildingAssignableServices.find(s => s.name === selectedAssignService); return cs ? (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {cs.categories.map(cat => {
                    const c = CATEGORY_COLORS[cat];
                    return <span key={cat} className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium border ${c.bg} ${c.text} ${c.border}`}>{cat}</span>;
                  })}
                  {cs.defaultPrice && <span className="text-[10px] text-gray-400 ml-1">{cs.defaultPrice}</span>}
                </div>
              ) : null; })()}
            </div>
            <div>
              <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Price Override</label>
              <input value={assignPriceOverride} onChange={e => setAssignPriceOverride(e.target.value)} className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. $342.00" data-testid="input-service-price" />
            </div>
          </div>
          <div className="flex gap-3 justify-end">
            <button onClick={() => { setShowAssign(false); setSelectedAssignService(''); setAssignPriceOverride(''); }} className="px-4 py-2 border border-gray-200 text-sm rounded-lg">Cancel</button>
            <button onClick={() => { if (selectedAssignService) { const cs = buildingAssignableServices.find(s => s.name === selectedAssignService); const newRow: ServiceRow = { name: selectedAssignService, managedBy: 'Taylr', price: assignPriceOverride || cs?.defaultPrice || 'Custom', enabled: true, type: 'taylr' }; setServices([...services, newRow]); } setShowAssign(false); setSelectedAssignService(''); setAssignPriceOverride(''); toast({ title: 'Service assigned' }); }} disabled={!selectedAssignService} className="px-4 py-2 bg-[#ED017F] text-white text-sm rounded-lg disabled:opacity-40 disabled:cursor-not-allowed" data-testid="btn-confirm-service">Assign</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function UtilitiesTab({ building, strata, terms, onUpdateTerms, services, gasAvailable, setGasAvailable, toast }: {
  building: Building;
  strata: ReturnType<typeof getStrataById>;
  terms: S119TermsState;
  onUpdateTerms: (updates: Partial<S119TermsState>) => void;
  services: ServiceRow[];
  gasAvailable: boolean;
  setGasAvailable: (v: boolean) => void;
  toast: any;
}) {
  const isACT = building.state === 'ACT';
  const isPartnered = strata?.isPartner ?? false;
  const s119Service = services.find(s => s.name === 'S119 Rental Certificates');
  const s119Active = s119Service?.enabled ?? false;
  const isLocked = isACT && isPartnered && s119Active;

  const embeddedCards = [
    {
      icon: <Zap className="w-5 h-5 text-amber-500" />,
      title: 'Electricity',
      slug: 'electricity',
      hasEmbedded: terms.embeddedElectricity,
      provider: terms.electricityProvider,
      toggleKey: 'embeddedElectricity' as const,
      providerKey: 'electricityProvider' as const,
      sublabel: 'Does this building have an embedded electricity network? If yes, Taylr cannot offer this service to members.',
    },
    {
      icon: <Flame className="w-5 h-5 text-red-500" />,
      title: 'Hot Water',
      slug: 'hot-water',
      hasEmbedded: terms.embeddedHotWater,
      provider: terms.hotWaterProvider,
      toggleKey: 'embeddedHotWater' as const,
      providerKey: 'hotWaterProvider' as const,
      sublabel: 'Does this building have an embedded hot water network? If yes, Taylr cannot offer this service to members.',
    },
    {
      icon: <Globe className="w-5 h-5 text-blue-500" />,
      title: 'Internet / Data',
      slug: 'internet-data',
      hasEmbedded: terms.embeddedInternet,
      provider: terms.internetProvider,
      toggleKey: 'embeddedInternet' as const,
      providerKey: 'internetProvider' as const,
      sublabel: 'Does this building have an embedded internet network? If yes, Taylr cannot offer this service to members.',
    },
  ];

  return (
    <div>
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Utility Services</h2>
        <p className="text-sm text-gray-500">Utility connection services available to members at this building. If a building has an embedded network, Taylr cannot offer that utility service to members as they are contracted to the embedded network provider.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {embeddedCards.map(uc => (
          <Card key={uc.slug}>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-3 mb-3">
                {uc.icon}
                <h3 className="text-sm font-semibold text-gray-900">{uc.title}</h3>
                {uc.hasEmbedded ? (
                  <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 text-gray-500 border border-gray-200">Not available — embedded network</span>
                ) : (
                  <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Available to members</span>
                )}
              </div>

              <div className="mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-medium text-gray-600">Embedded network:</span>
                  <div className="flex items-center gap-2">
                    {isLocked ? (
                      <>
                        <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border cursor-not-allowed ${uc.hasEmbedded ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white text-gray-300 border-gray-200'}`}>{uc.hasEmbedded ? 'Yes' : 'No'}</span>
                        <Lock className="w-3.5 h-3.5 text-gray-400" />
                      </>
                    ) : (
                      <>
                        <button onClick={() => onUpdateTerms({ [uc.toggleKey]: !uc.hasEmbedded })} data-testid={`toggle-${uc.slug}`}>
                          {uc.hasEmbedded ? <ToggleRight className="w-6 h-6 text-blue-500" /> : <ToggleLeft className="w-6 h-6 text-gray-300" />}
                        </button>
                        <span className="text-[11px] text-gray-500">{uc.hasEmbedded ? 'Yes' : 'No'}</span>
                      </>
                    )}
                  </div>
                </div>
                <p className="text-[11px] text-gray-400 mt-1">{uc.sublabel}</p>
              </div>

              {uc.hasEmbedded ? (
                <div className="space-y-2 border-t border-gray-100 pt-3">
                  <p className="text-xs text-gray-400">Members are contracted to the embedded network provider. Taylr cannot offer this service.</p>
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Embedded Provider</label>
                    <input
                      type="text"
                      value={uc.provider}
                      onChange={e => onUpdateTerms({ [uc.providerKey]: e.target.value })}
                      placeholder="Embedded provider name"
                      className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#ED017F] focus:border-transparent"
                      data-testid={`input-provider-${uc.slug}`}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2 border-t border-gray-100 pt-3">
                  <div>
                    <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Provider</label>
                    <input
                      type="text"
                      value={uc.provider}
                      onChange={e => onUpdateTerms({ [uc.providerKey]: e.target.value })}
                      placeholder="Provider name (optional)"
                      className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#ED017F] focus:border-transparent"
                      data-testid={`input-provider-${uc.slug}`}
                    />
                  </div>
                  <button onClick={() => toast({ title: 'Plan added (simulated)' })} className="text-xs text-[#ED017F] hover:underline flex items-center gap-1" data-testid={`btn-add-plan-${uc.slug}`}>
                    <Plus className="w-3 h-3" /> Add Plan
                  </button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}

        <Card>
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center gap-3 mb-3">
              <Flame className="w-5 h-5 text-orange-500" />
              <h3 className="text-sm font-semibold text-gray-900">Gas</h3>
              {gasAvailable ? (
                <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Available to members</span>
              ) : (
                <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 text-gray-500 border border-gray-200">Not available</span>
              )}
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-medium text-gray-600">Mains gas available:</span>
              <button onClick={() => setGasAvailable(!gasAvailable)} data-testid="toggle-gas">
                {gasAvailable ? <ToggleRight className="w-6 h-6 text-emerald-500" /> : <ToggleLeft className="w-6 h-6 text-gray-300" />}
              </button>
              <span className="text-[11px] text-gray-500">{gasAvailable ? 'Yes' : 'No'}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {isLocked && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 mt-4 flex items-start gap-2">
          <Lock className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500">Embedded network data is maintained by Vantage Strata for S119 certificate purposes. Contact the strata manager to update.</p>
        </div>
      )}
    </div>
  );
}

function getIssuedOCsForBuilding(buildingName: string) {
  return ocListData
    .filter(oc => oc.building === buildingName && !oc.isArchived)
    .filter(oc => {
      if (!getStrataServices(oc.strataCompany).s119Rental) return false;
      const seed = getOCSeedOrDefault(oc.id);
      const rawStatus = seed.s119Rental.status;
      const required = isS119Required(seed.contacts, seed.tenancy);
      const effective = hasConfirmedOwnerOccupier(seed.contacts)
        ? 'Not Applicable'
        : (rawStatus === 'Not Set' && !required) ? 'Not Applicable' : rawStatus;
      return effective === 'Issued';
    })
    .map(oc => {
      const seed = getOCSeedOrDefault(oc.id);
      const activeContacts = seed.contacts.filter(c => !c.isArchived);
      const owners = activeContacts.filter(c => c.role.toLowerCase().includes('owner') || c.role.toLowerCase().includes('director'));
      const ownerName = owners.length > 0 ? owners[0].name : (seed.ownershipCard?.namePerTitle || oc.ownerNames[0] || '—');
      return { id: oc.id, unit: oc.unit, ownerName };
    });
}

type EditingCategory = 'oc-rules' | 'insulation' | 'pool' | 'networks' | null;

function InsulationReadMode({ terms }: { terms: S119TermsState }) {
  const [showLots, setShowLots] = useState(false);

  if (terms.insulationMode === 'not-configured') {
    return (
      <div className="space-y-3">
        <p className="text-xs text-gray-400 italic">Insulation compliance not yet configured for this building.</p>
      </div>
    );
  }

  if (terms.insulationMode === 'all-exempt') {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <label className="text-xs font-medium text-gray-600">Exemption status:</label>
          <span className="px-3 py-1 rounded-full text-xs font-semibold border bg-emerald-100 text-emerald-700 border-emerald-200">All lots exempt</span>
        </div>
        <p className="text-xs text-gray-500">All lots in this building are exempt from minimum insulation standards. This will be stated on all certificates.</p>
        {terms.insulationDoc && (
          <DocUploadSlot label="Insulation exemption document" currentDoc={terms.insulationDoc} onUpload={() => {}} onReplace={() => {}} testId="upload-insulation" readOnly />
        )}
      </div>
    );
  }

  if (terms.insulationMode === 'none-exempt') {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <label className="text-xs font-medium text-gray-600">Exemption status:</label>
          <span className="px-3 py-1 rounded-full text-xs font-semibold border bg-blue-100 text-blue-700 border-blue-200">No lots exempt</span>
        </div>
        <p className="text-xs text-gray-500">No lots in this building are exempt from minimum ceiling insulation standards. All lots must comply.</p>
        {terms.insulationDoc && (
          <DocUploadSlot label="Insulation compliance document" currentDoc={terms.insulationDoc} onUpload={() => {}} onReplace={() => {}} testId="upload-insulation" readOnly />
        )}
      </div>
    );
  }

  const withInsulation = terms.lotInsulation.filter(l => l.hasInsulation).length;
  const total = terms.lotInsulation.length;
  const without = total - withInsulation;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <label className="text-xs font-medium text-gray-600">Exemption status:</label>
        <span className="px-3 py-1 rounded-full text-xs font-semibold border bg-blue-100 text-blue-700 border-blue-200">Per-lot assessment</span>
      </div>
      <p className="text-xs text-gray-600">{withInsulation} of {total} lots have insulation &middot; {without} {without === 1 ? 'does' : 'do'} not</p>
      <button onClick={() => setShowLots(!showLots)} className="flex items-center gap-1.5 text-xs font-medium text-[#ED017F] hover:underline" data-testid="btn-view-lots">
        {showLots ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
        {showLots ? 'Hide lots' : 'View lots'}
      </button>
      {showLots && (
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          <table className="w-full text-xs">
            <thead><tr className="bg-gray-50 text-gray-500">
              <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Unit</th>
              <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Lot</th>
              <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Floor</th>
              <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Has Insulation</th>
            </tr></thead>
            <tbody>
              {terms.lotInsulation.map(lot => (
                <tr key={lot.unitId} className="border-t border-gray-100">
                  <td className="px-3 py-2 text-gray-700">{lot.unitName}</td>
                  <td className="px-3 py-2 text-gray-700">{lot.lot}</td>
                  <td className="px-3 py-2 text-gray-700">{lot.floor}</td>
                  <td className="px-3 py-2">{lot.hasInsulation
                    ? <span className="inline-flex items-center gap-1 text-emerald-700"><CheckCircle2 className="w-3.5 h-3.5" /> Yes</span>
                    : <span className="inline-flex items-center gap-1 text-amber-700"><AlertTriangle className="w-3.5 h-3.5" /> No</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {terms.insulationDoc && (
        <DocUploadSlot label="Insulation compliance document" currentDoc={terms.insulationDoc} onUpload={() => {}} onReplace={() => {}} testId="upload-insulation" readOnly />
      )}
    </div>
  );
}

function InsulationEditMode({ building, editDraft, setEditDraft, terms }: {
  building: { id: string; name: string; upNumber: string };
  editDraft: Partial<S119TermsState>;
  setEditDraft: React.Dispatch<React.SetStateAction<Partial<S119TermsState>>>;
  terms: S119TermsState;
}) {
  const mode = (editDraft.insulationMode ?? terms.insulationMode) as InsulationMode;
  const lots: LotInsulation[] = editDraft.lotInsulation ?? terms.lotInsulation;
  const buildingUnits = getUnitsByBuildingId(building.id);

  const effectiveLots: LotInsulation[] = lots.length > 0 ? lots : buildingUnits.map(u => ({
    unitId: u.id, unitName: u.name, lot: u.lot, floor: u.floor, hasInsulation: false,
  }));

  const toggleLot = (unitId: string) => {
    const updated = effectiveLots.map(l => l.unitId === unitId ? { ...l, hasInsulation: !l.hasInsulation } : l);
    setEditDraft(d => ({ ...d, lotInsulation: updated }));
  };

  const selectAll = () => {
    setEditDraft(d => ({ ...d, lotInsulation: effectiveLots.map(l => ({ ...l, hasInsulation: true })) }));
  };

  const deselectAll = () => {
    setEditDraft(d => ({ ...d, lotInsulation: effectiveLots.map(l => ({ ...l, hasInsulation: false })) }));
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-medium text-gray-600 block mb-2">Are all lots in this building exempt from complying with minimum ceiling insulation standards?</label>
        <div className="flex items-center gap-2 flex-wrap">
          <button onClick={() => setEditDraft(d => ({ ...d, insulationMode: 'all-exempt' as InsulationMode, lotInsulation: [] }))} className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${mode === 'all-exempt' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'}`} data-testid="btn-insulation-exempt">Yes \u2014 all lots exempt</button>
          <button onClick={() => setEditDraft(d => ({ ...d, insulationMode: 'none-exempt' as InsulationMode, lotInsulation: [] }))} className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${mode === 'none-exempt' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'}`} data-testid="btn-insulation-none-exempt">No \u2014 all lots must comply</button>
          <button onClick={() => {
            setEditDraft(d => ({
              ...d,
              insulationMode: 'per-lot' as InsulationMode,
              lotInsulation: effectiveLots.length > 0 ? effectiveLots : buildingUnits.map(u => ({ unitId: u.id, unitName: u.name, lot: u.lot, floor: u.floor, hasInsulation: false })),
            }));
          }} className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${mode === 'per-lot' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'}`} data-testid="btn-insulation-perlot">Mixed \u2014 per-lot assessment</button>
        </div>
      </div>

      {mode === 'all-exempt' && (
        <DocUploadSlot label="Upload insulation exemption document (optional)" currentDoc={editDraft.insulationDoc ?? terms.insulationDoc} onUpload={() => setEditDraft(d => ({ ...d, insulationDoc: `Insulation-Exempt-${building.upNumber}.pdf` }))} onReplace={() => setEditDraft(d => ({ ...d, insulationDoc: null }))} testId="upload-insulation" />
      )}

      {mode === 'none-exempt' && (
        <DocUploadSlot label="Upload insulation compliance document (optional)" currentDoc={editDraft.insulationDoc ?? terms.insulationDoc} onUpload={() => setEditDraft(d => ({ ...d, insulationDoc: `Insulation-${building.upNumber}.pdf` }))} onReplace={() => setEditDraft(d => ({ ...d, insulationDoc: null }))} testId="upload-insulation" />
      )}

      {mode === 'per-lot' && (
        <>
          <p className="text-xs text-gray-500">Specify which lots have insulation. This information will appear on each unit\u2019s S119 certificate.</p>
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead><tr className="bg-gray-50 text-gray-500">
                <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Unit</th>
                <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Lot</th>
                <th className="text-left text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Floor</th>
                <th className="text-center text-xs font-semibold tracking-wide text-gray-500 uppercase px-4 py-3">Has Insulation</th>
              </tr></thead>
              <tbody>
                {effectiveLots.map(lot => (
                  <tr key={lot.unitId} className="border-t border-gray-100 hover:bg-gray-50 cursor-pointer" onClick={() => toggleLot(lot.unitId)}>
                    <td className="px-3 py-2 text-gray-700">{lot.unitName}</td>
                    <td className="px-3 py-2 text-gray-700">{lot.lot}</td>
                    <td className="px-3 py-2 text-gray-700">{lot.floor}</td>
                    <td className="px-3 py-2 text-center">
                      <div className={`w-5 h-5 rounded border-2 mx-auto flex items-center justify-center ${lot.hasInsulation ? 'bg-emerald-500 border-emerald-500' : 'border-gray-300 bg-white'}`} data-testid={`checkbox-insulation-${lot.unitId}`}>
                        {lot.hasInsulation && <Check className="w-3.5 h-3.5 text-white" />}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={selectAll} className="text-xs font-medium text-[#ED017F] hover:underline" data-testid="btn-select-all-insulation">Select All</button>
            <button onClick={deselectAll} className="text-xs font-medium text-[#ED017F] hover:underline" data-testid="btn-deselect-all-insulation">Deselect All</button>
          </div>
          <DocUploadSlot label="Upload insulation compliance document (optional)" currentDoc={editDraft.insulationDoc ?? terms.insulationDoc} onUpload={() => setEditDraft(d => ({ ...d, insulationDoc: `Insulation-${building.upNumber}-2026.pdf` }))} onReplace={() => setEditDraft(d => ({ ...d, insulationDoc: null }))} testId="upload-insulation" />
        </>
      )}
    </div>
  );
}

function S119UploadModal({ open, title, onClose, onUpload }: { open: boolean; title: string; onClose: () => void; onUpload: (filename: string, version: string) => void }) {
  const [version, setVersion] = useState('');
  const [note, setNote] = useState('');
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/20" onClick={onClose} />
      <div className="relative bg-white rounded-xl shadow-xl max-w-md w-full mx-4 p-6" data-testid="modal-s119-upload">
        <h3 className="text-base font-bold text-gray-900 mb-4">Update {title}</h3>
        <div className="space-y-3">
          <button onClick={() => onUpload(`${title.replace(/\s+/g, '-')}-doc.pdf`, version)} className="w-full border-2 border-dashed border-gray-200 rounded-lg px-4 py-5 text-center hover:border-[#ED017F]/30 hover:bg-pink-50/30 transition-colors group" data-testid="modal-upload-file">
            <Upload className="w-5 h-5 text-gray-300 mx-auto mb-1.5 group-hover:text-[#ED017F]/50" />
            <span className="text-xs text-gray-400 group-hover:text-gray-600">Choose PDF — drag or click</span>
          </button>
          <div>
            <label className="text-xs text-gray-500 block mb-1">Version note</label>
            <input value={version} onChange={e => setVersion(e.target.value)} placeholder="e.g. Adopted 15 March 2023" className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="modal-upload-version" />
          </div>
          <div>
            <label className="text-xs text-gray-500 block mb-1">Internal note</label>
            <input value={note} onChange={e => setNote(e.target.value)} placeholder="e.g. Annual review update" className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="modal-upload-note" />
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5">
          <button onClick={onClose} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800" data-testid="modal-upload-cancel">Cancel</button>
          <button onClick={() => onUpload(`${title.replace(/\s+/g, '-')}-doc.pdf`, version)} className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-sm font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="modal-upload-submit">Upload</button>
        </div>
      </div>
    </div>
  );
}

function S119HistoryPanel({ open, title, entries, onClose }: { open: boolean; title: string; entries: { filename: string; version?: string; note?: string; uploadedBy: string; date: string }[]; onClose: () => void }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/10" onClick={onClose} />
      <div className="relative bg-white shadow-xl w-full max-w-sm h-full overflow-y-auto" data-testid="panel-s119-history">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-gray-900">{title} — Update History</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-gray-100"><X className="w-4 h-4 text-gray-400" /></button>
        </div>
        <div className="p-5 space-y-4">
          {entries.length === 0 ? (
            <p className="text-xs text-gray-400">No history yet.</p>
          ) : entries.map((e, i) => (
            <div key={i} className="space-y-0.5">
              <p className="text-xs font-medium text-gray-700">{e.filename}</p>
              {e.version && <p className="text-[11px] text-gray-500">{e.version}</p>}
              {e.note && <p className="text-[11px] text-gray-400 italic">{e.note}</p>}
              <p className="text-[11px] text-gray-400">Uploaded by {e.uploadedBy} · {e.date}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function S119OverflowMenu({ items }: { items: { label: string; onClick: () => void; testId: string }[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="p-1 rounded hover:bg-gray-100" data-testid="btn-overflow-menu">
        <MoreHorizontal className="w-4 h-4 text-gray-400" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-7 z-50 bg-white border border-gray-200 rounded-lg shadow-lg py-1 min-w-[160px]">
            {items.map(item => (
              <button key={item.testId} onClick={() => { item.onClick(); setOpen(false); }} className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50" data-testid={item.testId}>{item.label}</button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function S119StatusPill({ done, label }: { done: boolean; label?: string }) {
  if (done) return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-gray-700 text-white" data-testid="pill-done">✓ Done</span>;
  return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-200" data-testid="pill-required">⚠ Required</span>;
}

function S119ComplianceDashboard({ building, terms, features, onUpdateTerms, onUploadTerms, ocInsulationOverrides, toast, onSwitchTab }: {
  building: Building;
  terms: S119TermsState;
  features: BuildingFeatures;
  onUpdateTerms: (updates: Partial<S119TermsState>) => void;
  onUploadTerms: (field: keyof S119TermsState, filename: string) => void;
  ocInsulationOverrides: Record<string, 'Yes' | 'No' | 'Unknown'>;
  toast: any;
  onSwitchTab: (tab: TabId) => void;
}) {
  const [uploadModal, setUploadModal] = useState<string | null>(null);
  const [historyPanel, setHistoryPanel] = useState<string | null>(null);

  const buildingOCs = ocListData.filter(oc => oc.buildingId === building.id && !oc.isArchived);
  const ocInsulationData = buildingOCs.map(oc => ({
    id: oc.id, unit: oc.unit, lot: oc.lot, floor: oc.floor,
    insulation: (ocInsulationOverrides[oc.id] ?? oc.ceilingInsulation ?? 'Unknown') as 'Yes' | 'No' | 'Unknown',
  }));
  const totalLots = ocInsulationData.length;
  const yesLots = ocInsulationData.filter(l => l.insulation === 'Yes').length;
  const noLots = ocInsulationData.filter(l => l.insulation === 'No').length;
  const unknownLots = ocInsulationData.filter(l => l.insulation === 'Unknown').length;

  const ocRulesOk = !!terms.ocRulesDoc;
  const insulationOk = features.allLotsExemptInsulation || (totalLots > 0 && unknownLots === 0);
  const poolOk = !features.hasPool || !!features.poolComplianceDoc;
  const networkDocMissing = (terms.embeddedElectricity && !terms.electricityDoc) || (terms.embeddedHotWater && !terms.hotWaterDoc) || (terms.embeddedInternet && !terms.internetDoc);
  const networksOk = !networkDocMissing;

  const incompleteCount = [ocRulesOk, insulationOk, poolOk, networksOk].filter(x => !x).length;
  const allClear = incompleteCount === 0;

  const networkSummary = [
    terms.embeddedElectricity ? `Electricity: Yes (${terms.electricityProvider || '?'})` : 'Electricity: No',
    terms.embeddedHotWater ? `Hot Water: Yes (${terms.hotWaterProvider || '?'})` : 'Hot Water: No',
    terms.embeddedInternet ? `Internet: Yes (${terms.internetProvider || '?'})` : 'Internet: No',
  ].join(' · ');

  const ocRulesHistory = [
    ...(terms.ocRulesDoc ? [{ filename: terms.ocRulesDoc, version: terms.ocRulesVersion, uploadedBy: 'Taylr Admin', date: '01 Feb 2024' }] : []),
    { filename: `OC-Rules-${building.upNumber}-v1.pdf`, version: 'Adopted 01 March 2020', uploadedBy: 'Strata Manager', date: '15 Mar 2020' },
  ];

  let insulationAnswer = '';
  if (features.allLotsExemptInsulation) {
    insulationAnswer = 'All lots exempt';
  } else if (totalLots === 0) {
    insulationAnswer = '';
  } else if (unknownLots === 0) {
    insulationAnswer = `${yesLots} of ${totalLots} lots have insulation · ${noLots} ${noLots === 1 ? 'does' : 'do'} not`;
  } else {
    insulationAnswer = `${totalLots - unknownLots} of ${totalLots} lots assessed`;
  }

  let poolAnswer = '';
  if (!features.hasPool) {
    poolAnswer = 'No pool';
  } else if (features.poolComplianceDoc) {
    poolAnswer = 'Yes — doc on file';
  } else {
    poolAnswer = 'Yes — document required';
  }

  return (
    <div>
      <div className="mb-4" data-testid="s119-status-line">
        {allClear ? (
          <p className="text-sm text-gray-500">Certificate terms complete — no holds</p>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">⚠ {incompleteCount} item{incompleteCount !== 1 ? 's' : ''} need{incompleteCount === 1 ? 's' : ''} attention</span>
        )}
      </div>

      <div className="border border-gray-200 rounded-xl divide-y divide-gray-100" data-testid="s119-compliance-list">
        <div className="flex items-start justify-between px-5 py-4" data-testid="row-oc-rules">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-gray-900">OC Rules</p>
            {ocRulesOk ? (
              <p className="text-sm text-gray-500 mt-0.5">{terms.ocRulesDoc} · {terms.ocRulesVersion || '—'}</p>
            ) : (
              <p className="text-sm text-amber-700 mt-0.5 cursor-pointer hover:underline" onClick={() => setUploadModal('OC Rules')} data-testid="prompt-upload-oc-rules">Upload required</p>
            )}
          </div>
          <div className="flex items-center gap-2 ml-4 shrink-0">
            <S119StatusPill done={ocRulesOk} />
            <S119OverflowMenu items={[
              { label: 'Edit', onClick: () => setUploadModal('OC Rules'), testId: 'menu-edit-oc-rules' },
              ...(ocRulesOk ? [{ label: 'Upload new version', onClick: () => setUploadModal('OC Rules'), testId: 'menu-upload-oc-rules' }] : [{ label: 'Upload', onClick: () => setUploadModal('OC Rules'), testId: 'menu-upload-oc-rules' }]),
              ...(ocRulesHistory.length > 0 ? [{ label: 'View history', onClick: () => setHistoryPanel('OC Rules'), testId: 'menu-history-oc-rules' }] : []),
            ]} />
          </div>
        </div>

        <div className="flex items-start justify-between px-5 py-4" data-testid="row-insulation">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-gray-900">Ceiling Insulation</p>
            {insulationOk ? (
              <p className="text-sm text-gray-500 mt-0.5">{insulationAnswer}</p>
            ) : totalLots === 0 || !features.allLotsExemptInsulation && totalLots === 0 ? (
              <p className="text-sm text-amber-700 mt-0.5 cursor-pointer hover:underline" onClick={() => onSwitchTab('settings')} data-testid="prompt-settings-insulation">Set in Building Settings →</p>
            ) : (
              <p className="text-sm text-amber-700 mt-0.5">{insulationAnswer} · <span className="cursor-pointer hover:underline" onClick={() => onSwitchTab('settings')} data-testid="prompt-units-insulation">Enter status for remaining lots →</span></p>
            )}
          </div>
          <div className="flex items-center gap-2 ml-4 shrink-0">
            <S119StatusPill done={insulationOk} />
            <S119OverflowMenu items={[
              { label: 'Edit', onClick: () => onSwitchTab('settings'), testId: 'menu-edit-insulation' },
            ]} />
          </div>
        </div>

        <div className="flex items-start justify-between px-5 py-4" data-testid="row-pool">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-gray-900">Swimming Pool</p>
            {poolOk ? (
              <p className="text-sm text-gray-500 mt-0.5">{poolAnswer}</p>
            ) : (
              <p className="text-sm text-amber-700 mt-0.5">{poolAnswer} · <span className="cursor-pointer hover:underline" onClick={() => setUploadModal('Swimming Pool')} data-testid="prompt-upload-pool">Upload compliance document</span></p>
            )}
          </div>
          <div className="flex items-center gap-2 ml-4 shrink-0">
            <S119StatusPill done={poolOk} />
            <S119OverflowMenu items={[
              { label: 'Edit', onClick: () => onSwitchTab('settings'), testId: 'menu-edit-pool' },
              ...(features.hasPool ? [{ label: 'Upload new version', onClick: () => setUploadModal('Swimming Pool'), testId: 'menu-upload-pool' }] : []),
              ...(features.hasPool && features.poolComplianceDoc ? [{ label: 'View history', onClick: () => setHistoryPanel('Swimming Pool'), testId: 'menu-history-pool' }] : []),
            ]} />
          </div>
        </div>

        <div className="flex items-start justify-between px-5 py-4" data-testid="row-networks">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-gray-900">Embedded Networks</p>
            {networksOk ? (
              <p className="text-sm text-gray-500 mt-0.5">{networkSummary}</p>
            ) : (
              <p className="text-sm text-amber-700 mt-0.5 cursor-pointer hover:underline" onClick={() => onSwitchTab('utilities')} data-testid="prompt-utilities-networks">Configure in Utilities tab →</p>
            )}
          </div>
          <div className="flex items-center gap-2 ml-4 shrink-0">
            <S119StatusPill done={networksOk} />
            <S119OverflowMenu items={[
              { label: 'Edit', onClick: () => onSwitchTab('utilities'), testId: 'menu-edit-networks' },
              ...(terms.electricityDoc ? [{ label: 'View history', onClick: () => setHistoryPanel('Embedded Networks'), testId: 'menu-history-networks' }] : []),
            ]} />
          </div>
        </div>
      </div>

      <S119UploadModal
        open={uploadModal === 'OC Rules'}
        title="OC Rules"
        onClose={() => setUploadModal(null)}
        onUpload={(filename, version) => {
          onUploadTerms('ocRulesDoc', `OC-Rules-${building.upNumber}-v${terms.ocRulesDoc ? '3' : '1'}.pdf`);
          if (version) onUpdateTerms({ ocRulesVersion: version });
          setUploadModal(null);
          toast({ title: 'Updated.' });
        }}
      />
      <S119UploadModal
        open={uploadModal === 'Swimming Pool'}
        title="Swimming Pool"
        onClose={() => setUploadModal(null)}
        onUpload={() => {
          setUploadModal(null);
          toast({ title: 'Updated.' });
        }}
      />

      <S119HistoryPanel
        open={historyPanel === 'OC Rules'}
        title="OC Rules"
        entries={ocRulesHistory}
        onClose={() => setHistoryPanel(null)}
      />
      <S119HistoryPanel
        open={historyPanel === 'Swimming Pool'}
        title="Swimming Pool"
        entries={features.poolComplianceDoc ? [{ filename: features.poolComplianceDoc, uploadedBy: 'Taylr Admin', date: '01 Feb 2024' }] : []}
        onClose={() => setHistoryPanel(null)}
      />
      <S119HistoryPanel
        open={historyPanel === 'Embedded Networks'}
        title="Embedded Networks"
        entries={terms.electricityDoc ? [{ filename: terms.electricityDoc, version: 'Embedded electricity network', uploadedBy: 'Taylr Admin', date: '01 Feb 2024' }] : []}
        onClose={() => setHistoryPanel(null)}
      />
    </div>
  );
}

function FilesTab({ terms, toast }: { terms: S119TermsState; toast: any }) {
  const files = getDefaultFiles(terms);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const categories = [
    { name: 'OC Rules & Governance', files: files.filter(f => f.category === 'OC Rules & Governance') },
    { name: 'Compliance Documents', files: files.filter(f => f.category === 'Compliance Documents') },
    { name: 'Taylr Agreement', files: [] as FileEntry[] },
    { name: 'Building Images', files: [] as FileEntry[] },
    { name: 'Other Documents', files: [] as FileEntry[] },
  ];

  const toggle = (cat: string) => setCollapsed(prev => ({ ...prev, [cat]: !prev[cat] }));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Building Files</h2>
          <p className="text-sm text-gray-500">All documents stored for this building, organised by category.</p>
        </div>
        <button onClick={() => toast({ title: 'Upload simulated', description: 'Not available in demo' })} className="flex items-center gap-1.5 px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-upload-file">
          <Plus className="w-3.5 h-3.5" /> Upload File
        </button>
      </div>

      <div className="space-y-4">
        {categories.map(cat => (
          <div key={cat.name} className="border border-gray-200 rounded-xl overflow-hidden" data-testid={`files-category-${cat.name.toLowerCase().replace(/\s+/g, '-')}`}>
            <button onClick={() => toggle(cat.name)} className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors">
              <span className="text-sm font-semibold text-gray-700">{cat.name}</span>
              <span className="text-xs text-gray-400">{cat.files.length} file{cat.files.length !== 1 ? 's' : ''}</span>
            </button>
            {!collapsed[cat.name] && (
              <div className="px-4 py-3">
                {cat.files.length > 0 ? (
                  <div className="space-y-2">
                    {cat.files.map((f, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-gray-400" />
                          <div>
                            <p className="text-sm text-gray-800">{f.name}</p>
                            <p className="text-[11px] text-gray-400">{f.date} · {f.uploadedBy}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => toast({ title: 'Download simulated' })} className="text-xs text-gray-400 hover:text-[#ED017F]" data-testid={`btn-download-${i}`}>Download</button>
                          <button onClick={() => toast({ title: 'File removed (simulated)' })} className="text-gray-300 hover:text-red-500" data-testid={`btn-remove-file-${i}`}>
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-4 text-center">
                    {cat.name === 'Building Images' ? (
                      <p className="text-xs text-gray-400">Upload images via the Overview tab.</p>
                    ) : cat.name === 'Taylr Agreement' ? (
                      <button onClick={() => toast({ title: 'Upload simulated', description: 'Not available in demo' })} className="px-3 py-1.5 border border-gray-200 text-xs text-gray-500 rounded-lg hover:bg-gray-50" data-testid="btn-upload-contract">Upload Contract PDF</button>
                    ) : (
                      <button onClick={() => toast({ title: 'Upload simulated', description: 'Not available in demo' })} className="text-xs text-gray-400 hover:text-[#ED017F] flex items-center gap-1 mx-auto" data-testid="btn-upload-other">
                        <Plus className="w-3 h-3" /> Upload
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsTab({ building, displayName, setDisplayName, canRegister, setCanRegister, showDisableModal, setShowDisableModal, toast, relationshipStatus, features, onUpdateFeatures, isACT, view }: any) {
  const isLost = relationshipStatus === 'Expired Lost' || relationshipStatus === 'Agreement Expired';
  const isStrataView = view?.mode === 'strata';
  const feat = features as BuildingFeatures;
  return (
    <div>
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Building Settings</h2>
        <p className="text-sm text-gray-500">Infrequently changed configuration for this building.</p>
      </div>

      {isLost && (
        <div className="flex items-start gap-2.5 p-3 bg-gray-100 border border-gray-200 rounded-xl mb-4" data-testid="settings-lost-note">
          <Lock className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
          <span className="text-sm text-gray-500">{isStrataView ? 'Building is disabled because strata management has been lost. Contact Taylr to review reactivation.' : (relationshipStatus === 'Agreement Expired' ? 'Building is disabled due to expired agreement. Renew the agreement to re-enable.' : 'Building is disabled due to Lost status. Contact Taylr to review reactivation.')}</span>
        </div>
      )}

      <div className="space-y-6">
        {isACT && (
          <Card data-testid="card-building-features">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold">Building Features</CardTitle>
              <p className="text-xs text-gray-400 mt-0.5">Physical features of this building used across Taylr services.</p>
            </CardHeader>
            <CardContent className="space-y-5">
              <div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className={`text-sm font-medium ${isLost ? 'text-gray-400' : 'text-gray-700'}`}>Swimming pool on site</p>
                    <p className="text-[11px] text-gray-400">Used for S119 compliance disclosure and other building services.</p>
                  </div>
                  {isLost ? (
                    <span className="flex items-center gap-1.5 text-xs text-gray-400"><Lock className="w-3 h-3" /><ToggleLeft className="w-7 h-7 text-gray-300" /></span>
                  ) : (
                    <button onClick={() => onUpdateFeatures({ hasPool: !feat.hasPool })} data-testid="toggle-pool-feature">
                      {feat.hasPool ? <ToggleRight className="w-7 h-7 text-emerald-500" /> : <ToggleLeft className="w-7 h-7 text-gray-300" />}
                    </button>
                  )}
                </div>
                {feat.hasPool && (
                  <div className="pl-4 border-l-2 border-gray-100 space-y-3 mt-2">
                    <div>
                      <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Pool registration number (optional)</label>
                      <input type="text" value={feat.poolRegNumber} onChange={e => onUpdateFeatures({ poolRegNumber: e.target.value })} placeholder="e.g. PR-12345" className="mt-1 w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" data-testid="input-pool-reg-feature" disabled={isLost} />
                    </div>
                    <DocUploadSlot label="Upload pool compliance document" currentDoc={feat.poolComplianceDoc} onUpload={() => onUpdateFeatures({ poolComplianceDoc: `Pool-Compliance-${building.upNumber}.pdf` })} onReplace={() => onUpdateFeatures({ poolComplianceDoc: null })} testId="upload-pool-feature" readOnly={isLost} />
                  </div>
                )}
              </div>

              <div className="border-t border-gray-100 pt-4">
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className={`text-sm font-medium ${isLost ? 'text-gray-400' : 'text-gray-700'}`}>Ceiling insulation — all lots exempt</p>
                    <p className="text-[11px] text-gray-400">Are all lots in this building exempt from minimum ceiling insulation standards? (ACT Unit Titles Act)</p>
                  </div>
                  {isLost ? (
                    <span className="flex items-center gap-1.5 text-xs text-gray-400"><Lock className="w-3 h-3" /><ToggleLeft className="w-7 h-7 text-gray-300" /></span>
                  ) : (
                    <button onClick={() => onUpdateFeatures({ allLotsExemptInsulation: !feat.allLotsExemptInsulation })} data-testid="toggle-insulation-exempt-feature">
                      {feat.allLotsExemptInsulation ? <ToggleRight className="w-7 h-7 text-emerald-500" /> : <ToggleLeft className="w-7 h-7 text-gray-300" />}
                    </button>
                  )}
                </div>
                {feat.allLotsExemptInsulation && (
                  <div className="pl-4 border-l-2 border-gray-100 space-y-2 mt-2">
                    <p className="text-xs text-gray-500">All lots treated as exempt — no per-lot entry needed.</p>
                    <DocUploadSlot label="Upload exemption document (optional)" currentDoc={feat.insulationExemptionDoc} onUpload={() => onUpdateFeatures({ insulationExemptionDoc: `Insulation-Exempt-${building.upNumber}.pdf` })} onReplace={() => onUpdateFeatures({ insulationExemptionDoc: null })} testId="upload-insulation-exempt-feature" readOnly={isLost} />
                  </div>
                )}
                {!feat.allLotsExemptInsulation && (
                  <p className="text-xs text-gray-500 mt-1 pl-0.5">Per-lot insulation status must be entered at the unit/OC level.</p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Registration & Display</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Display Name (shown to members)</label>
              <div className="flex gap-2 mt-1">
                <input type="text" value={displayName} onChange={e => !isLost && setDisplayName(e.target.value)} className={`flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm ${isLost ? 'bg-gray-50 text-gray-400' : ''}`} data-testid="input-display-name" disabled={isLost} />
                {!isLost && <button onClick={() => toast({ title: 'Display name saved' })} className="px-3 py-2 bg-[#ED017F] text-white text-xs rounded-lg" data-testid="btn-save-display-name">Save Display Name</button>}
                {!isLost && <button onClick={() => setDisplayName(building.name)} className="px-3 py-2 border border-gray-200 text-xs text-gray-500 rounded-lg" data-testid="btn-clear-display-name">Clear</button>}
              </div>
            </div>

            {(building.stage === 'Registered' || building.stage === 'Established') && (
              <div>
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Registration Date *</label>
                <p className="text-[10px] text-gray-400 mt-0.5 mb-1">The date the UP was formally registered. This is used to calculate the Established Date (Registration Date + 3 months).</p>
                <div className="flex gap-2">
                  <input type="date" className={`flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm ${isLost ? 'bg-gray-50 text-gray-400' : ''}`} data-testid="input-reg-date" disabled={isLost} />
                  {!isLost && <button onClick={() => toast({ title: 'Registration date saved' })} className="px-3 py-2 bg-[#ED017F] text-white text-xs rounded-lg" data-testid="btn-save-reg-date">Save Date</button>}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between py-2">
              <div>
                <p className={`text-sm font-medium ${isLost ? 'text-gray-400' : 'text-gray-700'}`}>Can Register</p>
                <p className="text-[11px] text-gray-400">Controls whether members can register for this building</p>
              </div>
              {isLost ? (
                <span className="flex items-center gap-1.5 text-xs text-gray-400"><Lock className="w-3 h-3" /><ToggleLeft className="w-7 h-7 text-gray-300" /></span>
              ) : (
                <button onClick={() => setCanRegister(!canRegister)} data-testid="toggle-can-register">
                  {canRegister ? <ToggleRight className="w-7 h-7 text-emerald-500" /> : <ToggleLeft className="w-7 h-7 text-gray-300" />}
                </button>
              )}
            </div>

            <div className="flex items-center justify-between py-2">
              <div>
                <p className={`text-sm font-medium ${isLost ? 'text-gray-400' : 'text-gray-700'}`}>Platform Visible</p>
                <p className="text-[11px] text-gray-400">Building is visible and active when stage is Registered or Established</p>
              </div>
              <span className="text-xs font-medium px-2 py-1 rounded-full bg-gray-100 text-gray-500" data-testid="label-platform-visible">
                {isLost ? 'Disabled' : (building.stage === 'Registered' || building.stage === 'Established' ? 'Active' : 'Inactive')}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-red-700">Danger Zone</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm font-medium text-gray-700 mb-1">Disable Building</p>
            <p className="text-xs text-gray-400 mb-4">{isStrataView ? 'Disabling this building will prevent all member activity and hide it from the Taylr platform. This is automatic when strata management is lost.' : 'Disabling this building will prevent all member activity and hide it from the Taylr platform. This is automatic when an agreement lapses or strata management is lost without a direct Taylr agreement.'}</p>
            <button onClick={() => setShowDisableModal(true)} className="px-4 py-2 border border-red-300 text-red-600 text-xs font-medium rounded-lg hover:bg-red-50" data-testid="btn-disable-building">Disable Building</button>
          </CardContent>
        </Card>
      </div>

      {showDisableModal && (
        <Modal onClose={() => setShowDisableModal(false)}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Disable Building</h3>
          <p className="text-sm text-gray-600 mb-6">Are you sure you want to disable {building.name}? All member activity will be suspended.</p>
          <div className="flex gap-3 justify-end">
            <button onClick={() => setShowDisableModal(false)} className="px-4 py-2 border border-gray-200 text-sm rounded-lg">Cancel</button>
            <button onClick={() => { setShowDisableModal(false); toast({ title: 'Building disabled (simulated)' }); }} className="px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700" data-testid="btn-confirm-disable">Disable</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function TermCard({ icon, title, subtitle, holdOk, holdOkLabel, holdWarningLabel, children, editing, onEdit, onCancel, onSave }: { icon: React.ReactNode; title: string; subtitle: string; holdOk: boolean; holdOkLabel: string; holdWarningLabel: string; children: React.ReactNode; editing?: boolean; onEdit?: () => void; onCancel?: () => void; onSave?: () => void }) {
  return (
    <div className={`border rounded-xl p-4 space-y-3 ${editing ? 'border-[#ED017F]/30 ring-1 ring-[#ED017F]/10' : 'border-gray-200'}`} data-testid={`card-term-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex items-start gap-2.5">
        <div className="mt-0.5">{icon}</div>
        <div className="flex-1">
          <h4 className="text-sm font-bold text-gray-900">{title}</h4>
          <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">{subtitle}</p>
        </div>
        {!editing && onEdit && (
          <button onClick={onEdit} className="text-gray-400 hover:text-[#ED017F] transition-colors p-1" data-testid={`btn-edit-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            <Pencil className="w-4 h-4" />
          </button>
        )}
      </div>
      <div className="pl-6.5 space-y-3">{children}</div>
      {editing && onCancel && onSave && (
        <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
          <button onClick={onCancel} className="px-4 py-2 text-xs text-gray-600 hover:text-gray-800 font-medium" data-testid="btn-cancel-term-edit">Cancel</button>
          <button onClick={onSave} className="px-4 py-2 border border-[#ED017F] bg-white text-[#ED017F] text-xs font-medium rounded-lg hover:bg-[#ED017F] hover:text-white" data-testid="btn-save-term-edit">Save Changes</button>
        </div>
      )}
      {!editing && (
        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium ${holdOk ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-800'}`}>
          {holdOk ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />}
          {holdOk ? holdOkLabel : holdWarningLabel}
        </div>
      )}
    </div>
  );
}

function DocUploadSlot({ label, currentDoc, onUpload, onReplace, testId, readOnly, showNewVersion, onUploadNewVersion }: { label: string; currentDoc: string | null; onUpload: () => void; onReplace: () => void; testId: string; readOnly?: boolean; showNewVersion?: boolean; onUploadNewVersion?: () => void }) {
  if (currentDoc) {
    return (
      <div className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-gray-500" />
          <span className="text-xs font-medium text-gray-700">{currentDoc}</span>
        </div>
        {!readOnly && (
          <div className="flex items-center gap-2">
            <button onClick={onReplace} className="text-[11px] text-gray-400 hover:text-red-500 font-medium" data-testid={`btn-replace-${testId}`}>Replace</button>
            {showNewVersion && onUploadNewVersion && (
              <button onClick={onUploadNewVersion} className="text-[11px] text-[#ED017F] hover:text-[#d0016e] font-medium" data-testid={`btn-new-version-${testId}`}>Upload New Version</button>
            )}
          </div>
        )}
      </div>
    );
  }
  if (readOnly) return null;
  return (
    <button onClick={onUpload} className="w-full border-2 border-dashed border-gray-200 rounded-lg px-4 py-4 text-center hover:border-[#ED017F]/30 hover:bg-pink-50/30 transition-colors group" data-testid={`btn-${testId}`}>
      <Upload className="w-5 h-5 text-gray-300 mx-auto mb-1.5 group-hover:text-[#ED017F]/50" />
      <span className="text-xs text-gray-400 group-hover:text-gray-600">{label}</span>
    </button>
  );
}

function NetworkRow({ icon, label, enabled, onToggle, provider, onProviderChange, doc, onUpload, onRemoveDoc, testId, readOnly }: { icon: React.ReactNode; label: string; enabled: boolean; onToggle: (v: boolean) => void; provider: string; onProviderChange: (v: string) => void; doc: string | null; onUpload: () => void; onRemoveDoc: () => void; testId: string; readOnly?: boolean }) {
  return (
    <div className="border-b border-gray-100 pb-3 last:border-0 last:pb-0 space-y-2" data-testid={testId}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-gray-700">
          {icon}
          <span className="font-medium">{label}</span>
        </div>
        {readOnly ? (
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border ${enabled ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-emerald-100 text-emerald-700 border-emerald-200'}`}>{enabled ? 'Yes' : 'No'}</span>
        ) : (
          <div className="flex items-center gap-2">
            <button onClick={() => onToggle(true)} className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border ${enabled ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white text-gray-400 border-gray-200'}`} data-testid={`${testId}-yes`}>Yes</button>
            <button onClick={() => onToggle(false)} className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border ${!enabled ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-white text-gray-400 border-gray-200'}`} data-testid={`${testId}-no`}>No</button>
          </div>
        )}
      </div>
      {enabled ? (
        <div className="pl-5 space-y-2">
          {readOnly ? (
            <p className="text-xs text-gray-600">{provider || '\u2014'}</p>
          ) : (
            <input type="text" value={provider} onChange={(e) => onProviderChange(e.target.value)} placeholder="Network provider name" className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs focus:ring-2 focus:ring-[#ED017F] focus:border-transparent" data-testid={`${testId}-provider`} />
          )}
          <DocUploadSlot label="Upload exemption document" currentDoc={doc} onUpload={onUpload} onReplace={onRemoveDoc} testId={`upload-${testId}`} readOnly={readOnly} />
        </div>
      ) : (
        <div className="pl-5 flex items-center gap-1.5">
          <CheckCircle2 className="w-3 h-3 text-emerald-500" />
          <span className="text-[11px] text-emerald-600">No documentation required</span>
        </div>
      )}
    </div>
  );
}

function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/20" onClick={onClose} />
      <div className="relative bg-white rounded-xl shadow-xl max-w-md w-full mx-4 p-6">{children}</div>
    </div>
  );
}

function formatContactAvailability(c: { availability?: string; daysOnSite?: string[]; hours?: string }): string {
  if (!c.availability) return '';
  if (c.availability === 'On-call') return 'On-call';
  if (c.availability === 'Not currently assigned') return '';
  const parts = [c.availability];
  if (c.daysOnSite && c.daysOnSite.length > 0) {
    const allWeekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    const isFullWeek = allWeekdays.every(d => c.daysOnSite!.includes(d)) && c.daysOnSite.length === 5;
    parts.push(isFullWeek ? 'Mon\u2013Fri' : c.daysOnSite.join(', '));
  }
  if (c.hours) parts.push(c.hours);
  return parts.join(' \u00b7 ');
}
