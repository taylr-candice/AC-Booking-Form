import type { OwnershipCard } from "../schema";

export function updateOwnershipCard(
  current: OwnershipCard,
  updates: Partial<OwnershipCard>
): OwnershipCard {
  return { ...current, ...updates };
}
