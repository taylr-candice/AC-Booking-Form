import type { Contact, ContactSource, TenancyState, EmailFlow, AccessLevel, S119Service } from "../schema";
import { generateEmailsForNewContact } from "./emails";

function isOwnerOrUnknownRole(role: string): boolean {
  const r = role.toLowerCase();
  return r.includes('owner') || r.includes('director') || r.includes('trustee') || r === 'unassigned' || r === 'unknown';
}

function isTenantRole(role: string): boolean {
  const r = role.toLowerCase();
  return r.includes('tenant') || r === 'household member';
}

export function isStrictTenantRole(role: string): boolean {
  const r = role.toLowerCase();
  return r.includes('tenant') && !r.includes('household');
}

function isHouseholdMember(role: string): boolean {
  return role.toLowerCase() === 'household member';
}

function isAgentRole(role: string): boolean {
  const r = role.toLowerCase();
  return r.includes('agent') || r.includes('property manager');
}

function isAgentSource(source: string): boolean {
  const s = source.toLowerCase();
  return s.includes('agent') || s.includes('property manager');
}

function isOwnerOccupierRole(role: string): boolean {
  return role.toLowerCase() === 'owner occupier';
}

export function isContactVerified(c: Contact): boolean {
  if (c.isArchived) return false;

  if (isHouseholdMember(c.role)) return c.verified === true;

  if (isTenantRole(c.role) && c.authorised) return true;

  if (c.onboarded) return true;

  return false;
}

export function isOCVerified(contacts: Contact[]): boolean {
  const active = contacts.filter(c => !c.isArchived);
  return active.some(c => isOwnerOrUnknownRole(c.role) && isContactVerified(c));
}

export function isOCFullyVerified(contacts: Contact[]): boolean {
  const active = contacts.filter(c => !c.isArchived);
  return active.length > 0 && active.every(c => isContactVerified(c));
}

export type NewContactInput = Omit<Contact, 'id' | 'isArchived' | 'sources' | 'hasConflict' | 'history' | 'emails'> & {
  source: ContactSource;
};

export interface AddContactResult {
  contacts: Contact[];
}

export function addContact(
  currentContacts: Contact[],
  newContact: NewContactInput,
  tenancyStatus: TenancyState['status'],
  tenantIds?: string[]
): AddContactResult {
  if (!newContact.email || !newContact.email.trim()) {
    return { contacts: currentContacts };
  }

  let updatedContacts = [...currentContacts];

  const existingIndex = updatedContacts.findIndex(c =>
    !c.isArchived &&
    (newContact.originFingerprint && c.originFingerprint === newContact.originFingerprint ? true :
    (!newContact.originFingerprint && ((c.email && c.email.toLowerCase() === newContact.email.toLowerCase()) ||
     (c.phone && c.phone === newContact.phone))))
  );

  if (existingIndex >= 0) {
    const existing = updatedContacts[existingIndex];
    const hasConflict = existing.role !== newContact.role;
    const newSources = Array.from(new Set([...existing.sources, newContact.source])) as ContactSource[];

    const highestAccess: AccessLevel =
      (existing.access === 'Active (Full portal)' || newContact.access === 'Active (Full portal)') ? 'Active (Full portal)' :
      (existing.access === 'Limited portal' || newContact.access === 'Limited portal') ? 'Limited portal' : 'None';

    let historyMsg = `Identity matched/merged (sources: ${newSources.join(', ')}).`;
    if (hasConflict) historyMsg += ` Role conflict: kept '${existing.role}', saw '${newContact.role}'.`;

    updatedContacts[existingIndex] = {
      ...existing,
      sources: newSources,
      access: highestAccess,
      hasConflict: existing.hasConflict || hasConflict,
      history: [historyMsg, ...existing.history]
    };
  } else {
    let verificationSource = '';
    if (newContact.source === 'Admin') verificationSource = 'Taylr Admin';
    else if (newContact.source === 'Self') verificationSource = 'Self-registration';
    else if (newContact.source === 'Strata') {
      verificationSource = 'Strata import (PIQ)';
    }

    const isAgent = newContact.role.toLowerCase().includes('agent');
    const isStrata = newContact.source === 'Strata';
    const isSelf = newContact.source === 'Self';
    const isTenant = newContact.role.toLowerCase().includes('tenant');
    const isHH = isHouseholdMember(newContact.role);
    const isOwnerProvidedByAdminDelegate = newContact.role.toLowerCase().includes('owner') &&
      ['Lawyer', 'Accountant', 'Agent', 'Property Manager', 'Sales Agent', 'Company Secretary', 'POA'].includes(newContact.source);

    let isAuthorisedAgent = false;
    if (newContact.source.toLowerCase().includes('agent')) {
      isAuthorisedAgent = currentContacts.some(c => c.role.toLowerCase().includes('agent') && c.authorised);
    }

    if (isHH && isAgentSource(newContact.source)) {
      return { contacts: currentContacts };
    }

    const isUnknownRole = newContact.role.toLowerCase() === 'unknown';
    const isStrataOwnerOrUnknown = isStrata && (isOwnerOrUnknownRole(newContact.role) && !isTenant && !isAgent);
    const isCreatedByAuthorisedParty =
      newContact.authorised || isStrataOwnerOrUnknown || newContact.source === 'Admin' ||
      newContact.source === 'Owner' || isOwnerProvidedByAdminDelegate ||
      (newContact.source.toLowerCase().includes('agent') && isAuthorisedAgent);

    let contactAuthorised = newContact.authorised;
    let contactAccess = newContact.access;
    let strataRoleLabel = newContact.role;
    let tenantNotOnLease = false;
    let historyMsg = newContact.source === 'Self' ? 'Self registered.' :
                     newContact.source === 'Strata' ? `Imported from Strata (PIQ) as ${strataRoleLabel}.` :
                     newContact.source === 'Admin' ? 'Created manually by Taylr Admin.' :
                     `Created by ${newContact.source}.`;

    if (isStrata && isTenant) {
      contactAuthorised = false;
      contactAccess = 'Pending approval';
      historyMsg += ' Auth in card pending — Strata-imported tenants require approval from an authorised owner, agent, or Taylr admin.';
    } else if (isStrata && isAgent) {
      contactAuthorised = false;
      contactAccess = 'Pending approval';
      historyMsg += ' Auth in card pending — Strata-imported agents require confirmation from an authorised owner or Taylr admin.';
    } else if (isStrata && isUnknownRole) {
      contactAuthorised = true;
      contactAccess = 'Pending onboarding';
      historyMsg += ' Auth in card — Unknown contacts are authorised pending role determination via onboarding.';
    } else if (isStrata && isOwnerOrUnknownRole(newContact.role)) {
      contactAuthorised = true;
      contactAccess = 'Pending onboarding';
    }

    if (isHH) {
      const hasAuthorisedTenant = currentContacts.some(c =>
        !c.isArchived && c.role.toLowerCase().includes('tenant') && c.authorised
      );
      const hasOwnerOccupier = currentContacts.some(c =>
        !c.isArchived && isOwnerOccupierRole(c.role)
      );

      if (!hasAuthorisedTenant && !hasOwnerOccupier) {
        contactAuthorised = false;
        contactAccess = 'Pending approval';
        historyMsg += ' Household member pending — requires authorised tenant or owner occupier.';
      } else if (hasAuthorisedTenant) {
        contactAuthorised = true;
        contactAccess = 'Active';
        historyMsg += ' Authorised via verified tenant.';
      } else if (hasOwnerOccupier) {
        contactAuthorised = true;
        contactAccess = 'Active';
        historyMsg += ' Authorised via owner occupier.';
      }
    } else if (isTenant) {
      const isTenancyExpired = ['Expired', 'Ended'].includes(tenancyStatus);
      const isTenancyActive = tenancyStatus === 'Active';
      const contactIsOnLease = tenantIds ? tenantIds.includes(newContact.email) || tenantIds.some(tid => currentContacts.find(c => c.id === tid)?.email === newContact.email) : false;
      const hasActiveLease = isTenancyActive && tenantIds && tenantIds.length > 0;
      tenantNotOnLease = hasActiveLease && !contactIsOnLease;

      if (!isCreatedByAuthorisedParty) {
        contactAuthorised = false;
        const suspendedAccess = tenancyStatus === 'Ended' ? 'Suspended (tenancy ended)' : 'Suspended (tenancy expired)';
        contactAccess = isTenancyExpired ? suspendedAccess : 'Pending approval';
        historyMsg += ` Note: Tenant created by unauthorised source. Access set to ${contactAccess} until delegated agent is approved.`;
        if (tenantNotOnLease) {
          historyMsg += ' Tenant is not on the active lease — flagged for agent/owner review.';
        }
      } else {
        if (isTenancyExpired) {
          contactAuthorised = false;
          contactAccess = tenancyStatus === 'Ended' ? 'Suspended (tenancy ended)' : 'Suspended (tenancy expired)';
          historyMsg += tenancyStatus === 'Ended'
            ? ` Note: Tenant created by authorised source but lease was terminated early. Access suspended.`
            : ` Note: Tenant created by authorised source but lease is expired. Access suspended.`;
        } else if (tenantNotOnLease) {
          contactAuthorised = false;
          contactAccess = 'Pending approval';
          historyMsg += ` Tenant is not on the active lease. Access held pending — agent or owner must confirm lease status.`;
        } else {
          contactAuthorised = true;
          contactAccess = 'Active';
        }
      }
    }

    const nextEmails = generateEmailsForNewContact(isSelf, isCreatedByAuthorisedParty, isTenant, contactAuthorised);

    updatedContacts.push({
      ...newContact,
      authorised: contactAuthorised,
      access: contactAccess,
      id: Date.now().toString(),
      sources: [newContact.source],
      hasConflict: false,
      isArchived: false,
      notOnLease: tenantNotOnLease || undefined,
      onboarded: !isAgent && newContact.source !== 'Strata',
      history: [`Role assigned as ${newContact.role} (Verification: ${verificationSource}).`, historyMsg],
      emails: nextEmails
    });

    if (tenantNotOnLease) {
      const authorisedAgent = updatedContacts.find(c => !c.isArchived && c.role.toLowerCase().includes('agent') && c.authorised);
      const recipientContact = authorisedAgent || updatedContacts.find(c => !c.isArchived && c.role.toLowerCase().includes('owner') && c.authorised && !!c.email);
      if (recipientContact) {
        const alreadyQueued = recipientContact.emails.some(e => e.type === 'Tenant Lease Query' && e.status === 'Pending');
        if (!alreadyQueued) {
          const idx = updatedContacts.findIndex(c => c.id === recipientContact.id);
          if (idx >= 0) {
            updatedContacts[idx] = {
              ...updatedContacts[idx],
              emails: [{ id: Date.now().toString() + '-tlq', type: 'Tenant Lease Query', status: 'Pending' }, ...updatedContacts[idx].emails],
              history: [`Tenant Lease Query queued — "${newContact.name}" self-registered as Tenant but is not on the active lease.`, ...updatedContacts[idx].history]
            };
          }
        }
      }
    }
  }

  return { contacts: updatedContacts };
}

export function archiveContact(
  contacts: Contact[],
  id: string,
  reason?: string
): Contact[] {
  return contacts.map(c => {
    if (c.id === id) {
      let historyMsg = reason || "Archived manually.";
      const hasResvuSync = c.emails.some(e => e.type === 'Resvu Sync' && e.status === 'Sent');

      if (hasResvuSync) {
        historyMsg = `${historyMsg} Resvu API removal signal sent.`;
      }

      return {
        ...c,
        isArchived: true,
        history: [historyMsg, ...c.history]
      };
    }
    return c;
  });
}

export function deleteContact(contacts: Contact[], id: string): Contact[] {
  return contacts.filter(c => c.id !== id);
}

export function processAgentHandover(contacts: Contact[], newAgentId: string): Contact[] {
  return contacts.map(c => {
    if (c.role.toLowerCase().includes('agent') && c.access === 'Active (Full portal)' && c.id !== newAgentId) {
      return {
        ...c,
        isArchived: true,
        access: 'Not applicable' as const,
        role: 'Managing Agent (Previous)',
        authorised: false,
        history: ['Archived — agent handover completed. Replaced by new managing agent.', ...c.history]
      };
    }
    if (c.id === newAgentId) {
      return {
        ...c,
        authorised: true,
        access: 'Active (Full portal)' as const,
        history: ['Access approved via Agent Handover.', ...c.history]
      };
    }
    return c;
  });
}

export function updateContact(
  contacts: Contact[],
  id: string,
  updates: Partial<Contact>,
  tenancyStatus: TenancyState['status']
): Contact[] {
  return contacts.map(c => {
    if (c.id !== id) return c;

    const nextC = { ...c, ...updates };
    let historyMsgs: string[] = [];
    let nextEmails = nextC.emails;

    if (updates.name && updates.name !== c.name) {
      historyMsgs.push(`Name updated from "${c.name}" to "${updates.name}" via Vantage verification.`);
    }
    if (updates.email && updates.email !== c.email) {
      historyMsgs.push(`Email updated from "${c.email}" to "${updates.email}" via Vantage verification.`);
    }
    if (updates.phone && updates.phone !== c.phone) {
      historyMsgs.push(`Phone updated from "${c.phone}" to "${updates.phone}" via Vantage verification.`);
    }

    let historyMsg = "Contact details updated.";

    if (updates.role && updates.role !== c.role) {
      let verificationSource = "Taylr Admin";
      if (updates.history && updates.history.length > 0) {
        const histMsg = updates.history[0].toLowerCase();
        if (histMsg.includes('strata welcome')) verificationSource = "Strata Welcome link";
        else if (histMsg.includes('taylr intro')) verificationSource = "Taylr Intro link";
        else if (histMsg.includes('strata portal')) verificationSource = "Strata Portal Admin";
      }

      historyMsg = `Role changed to ${updates.role} (verified via ${verificationSource}).`;

      if (updates.role.toLowerCase().includes('tenant')) {
        const isTenancyExpired = ['Expired', 'Ended'].includes(tenancyStatus);

        if (isTenancyExpired) {
          nextC.authorised = false;
          nextC.access = tenancyStatus === 'Ended' ? 'Suspended (tenancy ended)' : 'Suspended (tenancy expired)';
          historyMsg += tenancyStatus === 'Ended'
            ? " Tenant access suspended — lease terminated early."
            : " Tenant access suspended due to expired lease.";
        } else if (updates.authorised === undefined && c.authorised === false) {
          if (['Taylr Admin', 'Strata Portal Admin'].includes(verificationSource)) {
            nextC.authorised = true;
            nextC.access = 'Active';
          } else {
            nextC.authorised = false;
            nextC.access = 'Pending approval';
            historyMsg += " Pending authorisation from Owner/Agent.";
          }
        }
      }

      const hasResvuSync = c.emails.some(e => e.type === 'Resvu Sync' && (e.status === 'Sent' || e.status === 'Pending'));

      if (hasResvuSync) {
        historyMsg += " Resvu API Update scheduled.";
        nextEmails = nextEmails.map(e => e.type === 'Resvu Sync' ? { ...e, status: 'Pending' as const } : e);
      }
    } else if (updates.authorised === true && !c.authorised) {
      historyMsg = "Access approved by Admin.";
      if (!c.sources.includes('Strata')) {
        if (!c.role.toLowerCase().includes('tenant') || nextC.authorised) {
          historyMsg += " Taylr Intro and Resvu Sync queued.";
          const hasTaylrIntro = nextEmails.find(e => e.type === 'Taylr Intro');
          if (!hasTaylrIntro) nextEmails = [{ id: Date.now() + '1', type: 'Taylr Intro', status: 'Pending' }, ...nextEmails];
          else nextEmails = nextEmails.map(e => e.type === 'Taylr Intro' ? { ...e, status: 'Pending' as const } : e);

          const hasResvuSync = nextEmails.find(e => e.type === 'Resvu Sync');
          if (!hasResvuSync) nextEmails = [{ id: Date.now() + '2', type: 'Resvu Sync', status: 'Pending' }, ...nextEmails];
          else nextEmails = nextEmails.map(e => e.type === 'Resvu Sync' ? { ...e, status: 'Pending' as const } : e);
        }
      }
    } else if (updates.hasConflict === false && c.hasConflict) {
      historyMsg = updates.history ? updates.history[0] : "Identity conflict resolved by Admin.";
    }

    if (historyMsg !== "Contact details updated." || (updates.history && updates.history[0]?.includes('resolved'))) {
      historyMsgs.push(historyMsg);
    }

    return {
      ...nextC,
      emails: nextEmails,
      history: [...historyMsgs, ...c.history]
    };
  });
}

export function isS119Required(contacts: Contact[], tenancy: TenancyState): boolean {
  const activeContacts = contacts.filter(c => !c.isArchived);
  
  const hasOffsiteInvestor = activeContacts.some(c => c.role.toLowerCase() === 'offsite investor');
  const hasAgent = activeContacts.some(c => isAgentRole(c.role));
  const hasTenant = activeContacts.some(c => isTenantRole(c.role));
  const hasLeaseActivity = tenancy.status !== 'Not Applicable' && tenancy.status !== 'Missing Tenancy';
  
  return hasOffsiteInvestor || hasAgent || hasTenant || hasLeaseActivity;
}
