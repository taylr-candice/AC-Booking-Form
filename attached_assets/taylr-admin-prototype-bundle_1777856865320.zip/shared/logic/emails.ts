import type { Contact, EmailFlow } from "../schema";

export function generateEmailsForNewContact(
  isSelf: boolean,
  isCreatedByAuthorisedParty: boolean,
  isTenant: boolean,
  contactAuthorised: boolean
): EmailFlow[] {
  if (isSelf) {
    return [
      { id: Date.now() + '1', type: 'Strata Welcome', status: 'Not Sent' },
      { id: Date.now() + '2', type: 'Taylr Intro', status: 'Not Sent' },
      { id: Date.now() + '3', type: 'Resvu Sync', status: contactAuthorised ? 'Pending' : 'Not Sent' },
      { id: Date.now() + '4', type: 'Resvu Intro', status: 'Not Sent' }
    ];
  }

  if (isCreatedByAuthorisedParty && !isTenant) {
    return [
      { id: Date.now() + '1', type: 'Strata Welcome', status: 'Pending' },
      { id: Date.now() + '2', type: 'Taylr Intro', status: 'Not Sent' },
      { id: Date.now() + '3', type: 'Resvu Sync', status: 'Not Sent' },
      { id: Date.now() + '4', type: 'Resvu Intro', status: 'Not Sent' }
    ];
  }

  if (isTenant && contactAuthorised) {
    return [
      { id: Date.now() + '2', type: 'Taylr Intro', status: 'Pending' },
      { id: Date.now() + '3', type: 'Resvu Sync', status: 'Not Sent' },
      { id: Date.now() + '4', type: 'Resvu Intro', status: 'Not Sent' }
    ];
  }

  return [];
}

export function processEmailSend(
  contact: Contact,
  type: EmailFlow['type'],
  method: 'manual' | 'automatic' | 'na' = 'manual'
): { emails: EmailFlow[]; historyMsg: string; onboarded: boolean } {
  const now = new Date();
  const newEmail: EmailFlow = {
    id: Date.now().toString(),
    type,
    status: method === 'na' ? 'N/A' : 'Sent',
    sentAt: now
  };

  let nextEmails = [newEmail, ...contact.emails.filter(e => e.type !== type)];

  let methodText = method === 'manual' ? 'manually by Taylr Admin' : method === 'na' ? 'as N/A' : 'automatically';
  if (method === 'automatic' && type === 'Strata Welcome') {
    methodText = 'automatically on contact creation by Strata';
  }

  const formattedDate = now.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });
  const formattedTime = now.toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit' }).toLowerCase();
  let historyMsg = method === 'na'
    ? `${type} disabled on ${formattedDate} at ${formattedTime}.`
    : `${type} email sent ${methodText} on ${formattedDate} at ${formattedTime}.`;

  let isNowOnboarded = contact.onboarded;

  if (type === 'Strata Welcome') {
    ['Taylr Intro', 'Resvu Sync'].forEach(t => {
      if (!nextEmails.some(e => e.type === t)) {
        nextEmails.push({ id: Date.now().toString() + Math.random(), type: t as any, status: 'Pending' });
      } else {
        nextEmails = nextEmails.map(e => e.type === t && e.status !== 'Sent' ? { ...e, status: 'Pending' } : e);
      }
    });
    historyMsg += ' Taylr Intro and Resvu Sync queued automatically.';
  } else if (type === 'Taylr Intro') {
    isNowOnboarded = true;
  } else if (type === 'Resvu Sync') {
    if (method !== 'na') {
      if (!nextEmails.some(e => e.type === 'Resvu Intro')) {
        nextEmails.push({ id: Date.now().toString() + Math.random(), type: 'Resvu Intro', status: 'Pending' });
      } else {
        nextEmails = nextEmails.map(e => e.type === 'Resvu Intro' && e.status !== 'Sent' ? { ...e, status: 'Pending' } : e);
      }

      const taylrRole = contact.role.toLowerCase();
      let resvuRole = 'Other';
      if (taylrRole === 'unassigned') resvuRole = 'Owner Occupier';
      else if (taylrRole.includes('occupier')) resvuRole = 'Owner Occupier';
      else if (taylrRole.includes('investor')) resvuRole = 'Owner Investor';
      else if (taylrRole.includes('owner')) resvuRole = 'Owner Occupier';
      else if (taylrRole.includes('tenant')) resvuRole = 'Tenant';
      else if (taylrRole.includes('agent')) resvuRole = 'Property Manager';

      historyMsg = `Resvu Sync completed ${methodText}. Synced as "${resvuRole}". Resvu Intro queued automatically.`;
    } else {
      if (!nextEmails.some(e => e.type === 'Resvu Intro')) {
        nextEmails.push({ id: Date.now().toString() + Math.random(), type: 'Resvu Intro', status: 'N/A' });
      } else {
        nextEmails = nextEmails.map(e => e.type === 'Resvu Intro' && e.status !== 'Sent' ? { ...e, status: 'N/A' } : e);
      }
    }
  }

  return { emails: nextEmails, historyMsg, onboarded: isNowOnboarded };
}
