import type { Contact, TenancyState, S119Service, HealthStatus } from "../schema";

type ContactLike = {
  role: string;
  verified?: boolean;
  authorised?: boolean;
  isArchived?: boolean;
};

/**
 * An OC is "confirmed owner-occupied" when there is at least one Owner Occupier
 * contact that is both verified and authorised (auth in card), and there are
 * no competing roles (agent, tenant, offsite investor) on the card. When this
 * is true, an S119 Rental Certificate is not required and tenancy is not
 * applicable for this unit.
 */
export function hasConfirmedOwnerOccupier(contacts: ContactLike[]): boolean {
  const active = contacts.filter(c => !c.isArchived);
  if (active.length === 0) return false;
  const hasVerifiedAuthOO = active.some(c => {
    const role = c.role.toLowerCase();
    const isOO = role === 'owner occupier' || role === 'director (owner occupier)';
    const authorised = c.authorised !== false; // undefined => implicitly authorised
    return isOO && c.verified === true && authorised;
  });
  const hasAgent = active.some(c => {
    const r = c.role.toLowerCase();
    return r.includes('agent') || r === 'property manager';
  });
  const hasTenant = active.some(c => c.role.toLowerCase().includes('tenant'));
  const hasOffsiteInvestor = active.some(c => c.role.toLowerCase() === 'offsite investor');
  return hasVerifiedAuthOO && !hasAgent && !hasTenant && !hasOffsiteInvestor;
}

export function deriveEffectiveTenancyStatus(raw: string, contacts: ContactLike[]): string {
  if (hasConfirmedOwnerOccupier(contacts)) return 'Not Applicable';
  return raw;
}

/**
 * Parses S119 date strings in the seed format (e.g. "19 Jun 2025"). Returns
 * null if the string can't be parsed.
 */
export function parseS119Date(s?: string): Date | null {
  if (!s) return null;
  const d = new Date(s);
  if (isNaN(d.getTime())) return null;
  return d;
}

/**
 * Computes the S119 expiry date for a given issue date. S119 Rental
 * Certificates are valid for 5 years from issue. Returns a string formatted
 * like the seeds ("DD MMM YYYY") or null if the issue date is invalid.
 */
export function computeS119Expiry(issueDate: string): string | null {
  const d = parseS119Date(issueDate);
  if (!d) return null;
  const exp = new Date(d);
  exp.setFullYear(exp.getFullYear() + 5);
  const day = String(exp.getDate()).padStart(2, '0');
  const month = exp.toLocaleString('en-GB', { month: 'short' });
  const year = exp.getFullYear();
  return `${day} ${month} ${year}`;
}

export function deriveEffectiveS119Status(
  raw: string,
  contacts: ContactLike[],
  opts?: { expiryDate?: string; isArchived?: boolean; now?: Date }
): string {
  // Archived OCs keep their recorded status frozen — a new active OC starts
  // fresh and needs its own certificate.
  if (opts?.isArchived) return raw;
  if (hasConfirmedOwnerOccupier(contacts)) return 'Not Applicable';
  // Auto-derive Expired when an Issued certificate's expiry has passed.
  if (raw === 'Issued' && opts?.expiryDate) {
    const exp = parseS119Date(opts.expiryDate);
    const now = opts.now ?? new Date();
    if (exp && exp.getTime() < now.getTime()) return 'Expired';
  }
  return raw;
}

export interface HealthResult {
  healthStatus: HealthStatus;
  conflictsCount: number;
  pendingCount: number;
  missingRolesCount: number;
  shouldSetTenancyNotApplicable: boolean;
  shouldSetMissingTenancy: boolean;
}

export function calculateHealth(
  contacts: Contact[],
  tenancy: TenancyState,
  _s119Rental?: S119Service
): HealthResult {
  const activeContacts = contacts.filter(c => !c.isArchived);

  let conflicts = activeContacts.filter(c => c.hasConflict).length;

  const fullAgents = activeContacts.filter(
    c => c.role.toLowerCase().includes('agent') && c.access === 'Active (Full portal)'
  );
  if (fullAgents.length > 1) {
    conflicts += (fullAgents.length - 1);
  }

  const pendingAgents = activeContacts.filter(
    c => c.role.toLowerCase().includes('agent') && !c.authorised && c.access !== 'Not applicable'
  );
  if (fullAgents.length > 0 && pendingAgents.length > 0) {
    conflicts += 1;
  }

  const pending = activeContacts.filter(c => !c.authorised && c.access !== 'Not applicable' && !(c.role.toLowerCase() === 'household member' && c.access === 'Pending onboarding')).length;
  const incompleteOnboarding = activeContacts.filter(
    c => c.role.toLowerCase() === 'owner' && !c.onboarded
  ).length;

  const hasAgent = activeContacts.some(c => c.role.toLowerCase().includes('agent'));
  const hasOwnerWithEmail = activeContacts.some(
    c => c.role.toLowerCase().includes('owner') && !!c.email
  );
  const missingRoles = (!hasAgent && !hasOwnerWithEmail) ? 1 : 0;

  const hasTenant = activeContacts.some(c => c.role.toLowerCase().includes('tenant'));
  const hasOffsiteInvestor = activeContacts.some(c => c.role.toLowerCase() === 'offsite investor');
  const isMissingTenantsForInvestor = !hasTenant && hasOffsiteInvestor && hasAgent;

  const owners = activeContacts.filter(c => c.role.toLowerCase().includes('owner'));
  const allOwnersAreOccupiers = owners.length > 0 && owners.every(
    c => c.role.toLowerCase() === 'owner occupier'
  );
  const hasOwnerOccupier = activeContacts.some(c => c.role.toLowerCase() === 'owner occupier');
  const ownerTypeConflict = hasOwnerOccupier && (hasTenant || hasAgent || hasOffsiteInvestor);
  const shouldSetTenancyNotApplicable =
    allOwnersAreOccupiers && !hasAgent && !hasTenant && tenancy.status !== 'Not Applicable';

  const isTenantedUnit = hasOffsiteInvestor || hasAgent;
  const missingLeaseDetails = isTenantedUnit && !hasTenant &&
    tenancy.status !== 'Active' && tenancy.status !== 'Expired' && tenancy.status !== 'Ended';
  const shouldSetMissingTenancy = missingLeaseDetails &&
    tenancy.status !== 'Missing Tenancy' && tenancy.status !== 'Not Applicable';

  const tenantsNotOnLease = activeContacts.filter(c =>
    c.notOnLease && c.role.toLowerCase().includes('tenant') && !c.role.toLowerCase().includes('household')
  );

  let isWarning = pending > 0 || incompleteOnboarding > 0 || tenantsNotOnLease.length > 0;

  if (tenancy.status === 'Expired' || tenancy.status === 'Ended' || tenancy.status === 'Missing Tenancy') {
    isWarning = true;
  }

  let healthStatus: HealthStatus = 'Healthy';

  if (conflicts > 0 || missingRoles > 0 || isMissingTenantsForInvestor || ownerTypeConflict) {
    healthStatus = 'Critical';
  } else if (isWarning) {
    healthStatus = 'Warning';
  }

  return {
    healthStatus,
    conflictsCount: conflicts,
    pendingCount: pending,
    missingRolesCount: missingRoles,
    shouldSetTenancyNotApplicable,
    shouldSetMissingTenancy,
  };
}
