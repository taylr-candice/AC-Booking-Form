import type { Contact, TenancyState, UserRole, AccessLevel } from "../schema";

interface TenancyActionResult {
  contacts: Contact[];
  tenancy: TenancyState;
}

function getVerifierName(contacts: Contact[], currentUserRole: UserRole): string {
  if (currentUserRole === 'Admin') return 'Taylr Admin';
  const authAgent = contacts.find(c => c.role.toLowerCase().includes('agent') && c.authorised);
  return authAgent?.name || 'Authorised Agent';
}

function today(): string {
  return new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function verifyLeaseExtended(
  contacts: Contact[],
  tenancy: TenancyState,
  currentUserRole: UserRole,
  endDate?: string
): TenancyActionResult {
  const verifierName = getVerifierName(contacts, currentUserRole);
  const todayStr = today();

  const nextContacts = contacts.map(c => {
    if (c.role.toLowerCase() === 'tenant') {
      if (!c.isArchived && c.access === 'Suspended (tenancy expired)') {
        const newAccess: AccessLevel = c.onboarded ? 'Active' : 'Pending onboarding';
        return {
          ...c,
          authorised: true,
          notOnLease: undefined,
          access: newAccess,
          history: [`Lease extended — re-authorised and access restored to ${newAccess}.`, ...c.history]
        };
      } else if (!c.isArchived && c.access !== 'Suspended (tenancy expired)') {
        return {
          ...c,
          isArchived: true,
          access: 'Suspended (tenancy ended)' as const,
          authorised: false,
          history: ['Archived — not part of the extended lease.', ...c.history]
        };
      }
    }
    return c;
  });

  return {
    contacts: nextContacts,
    tenancy: {
      ...tenancy,
      status: 'Active',
      leaseEnd: endDate || tenancy.leaseEnd,
      version: tenancy.version + 1,
      lastVerifiedBy: verifierName,
      lastVerifiedAt: todayStr,
      history: [`Lease extended to ${endDate || 'new date'}.`, ...tenancy.history]
    }
  };
}

export function confirmLeaseEnded(
  contacts: Contact[],
  tenancy: TenancyState,
  currentUserRole: UserRole,
  endDate?: string
): TenancyActionResult {
  const verifierName = getVerifierName(contacts, currentUserRole);
  const todayStr = today();

  const nextContacts = contacts.map(c => {
    if (c.role.toLowerCase().includes('tenant') && !c.isArchived) {
      return {
        ...c,
        isArchived: true,
        access: 'Suspended (tenancy ended)' as const,
        authorised: false,
        history: ['Archived — lease terminated early (lease break). Resvu API removal signal sent.', ...c.history]
      };
    }
    return c;
  });

  return {
    contacts: nextContacts,
    tenancy: {
      ...tenancy,
      status: 'Ended',
      leaseEnd: endDate || tenancy.leaseEnd,
      version: tenancy.version + 1,
      lastVerifiedBy: verifierName,
      lastVerifiedAt: todayStr,
      history: [`Lease ended confirmed on ${endDate || 'current date'}. Tenants archived.`, ...tenancy.history]
    }
  };
}

export function confirmNewLease(
  contacts: Contact[],
  tenancy: TenancyState,
  currentUserRole: UserRole,
  startDate: string,
  endDate: string,
  selectedTenantIds?: string[]
): TenancyActionResult {
  const verifierName = getVerifierName(contacts, currentUserRole);
  const todayStr = today();

  const nextContacts = contacts.map(c => {
    if (c.role.toLowerCase().includes('tenant')) {
      if (selectedTenantIds?.includes(c.id)) {
        return {
          ...c,
          isArchived: false,
          notOnLease: undefined,
          access: (c.authorised ? (c.onboarded ? 'Active' : 'Pending onboarding') : 'Pending approval') as AccessLevel,
          history: [`Assigned to new lease (Commencement: ${startDate}).`, ...c.history]
        };
      } else if (!c.isArchived) {
        return {
          ...c,
          isArchived: true,
          access: 'Suspended (tenancy ended)' as const,
          authorised: false,
          history: ['Archived — not assigned to new lease.', ...c.history]
        };
      }
    }
    return c;
  });

  return {
    contacts: nextContacts,
    tenancy: {
      ...tenancy,
      status: 'Active',
      leaseStart: startDate,
      leaseEnd: endDate,
      version: tenancy.version + 1,
      lastVerifiedBy: verifierName,
      lastVerifiedAt: todayStr,
      tenantIds: selectedTenantIds,
      history: [`New lease created (Commencement: ${startDate}, End: ${endDate}). Previous tenants not selected were archived.`, ...tenancy.history]
    }
  };
}

export function confirmOwnerOccupied(
  contacts: Contact[],
  tenancy: TenancyState,
  currentUserRole: UserRole
): TenancyActionResult {
  const verifierName = getVerifierName(contacts, currentUserRole);
  const todayStr = today();

  const nextContacts = contacts.map(c => {
    if (c.role.toLowerCase().includes('tenant') && !c.isArchived) {
      return {
        ...c,
        isArchived: true,
        access: 'Suspended (tenancy ended)' as const,
        authorised: false,
        history: ['Archived — unit marked as Owner Occupied.', ...c.history]
      };
    }
    if (c.role.toLowerCase().includes('agent') && !c.isArchived) {
      return {
        ...c,
        isArchived: true,
        role: 'Managing Agent (Previous)',
        access: 'Not applicable' as const,
        authorised: false,
        history: ['Archived — unit marked as Owner Occupied, agent no longer required.', ...c.history]
      };
    }

    if (c.role.toLowerCase().includes('owner') && !c.isArchived) {
      if (c.role.includes('Offsite Investor')) {
        return {
          ...c,
          role: 'Owner Occupier',
          history: ['Role automatically updated from Offsite Investor to Owner Occupier due to property status change.', ...c.history]
        };
      }
    }
    return c;
  });

  return {
    contacts: nextContacts,
    tenancy: {
      ...tenancy,
      status: 'Not Applicable',
      leaseStart: undefined,
      leaseEnd: undefined,
      version: tenancy.version + 1,
      lastVerifiedBy: verifierName,
      lastVerifiedAt: todayStr,
      history: ['Unit marked as Owner Occupied.', ...tenancy.history]
    }
  };
}

export interface TenantLeaseInput {
  name: string;
  email: string;
  phone?: string;
}

export function confirmMissingTenancyLease(
  contacts: Contact[],
  tenancy: TenancyState,
  currentUserRole: UserRole,
  startDate: string,
  endDate: string,
  tenantInputs: TenantLeaseInput[]
): TenancyActionResult & { newContacts: Contact[] } {
  const verifierName = getVerifierName(contacts, currentUserRole);
  const todayStr = today();
  const source = currentUserRole === 'Admin' ? 'Taylr' : currentUserRole === 'Agent' ? 'Agent' : 'Owner';

  const newContacts: Contact[] = tenantInputs.map((t, i) => ({
    id: `tenant-new-${Date.now()}-${i}`,
    name: t.name,
    email: t.email,
    phone: t.phone || '',
    role: 'Tenant',
    sources: [source] as Contact['sources'],
    authorised: true,
    access: 'Active' as AccessLevel,
    onboarded: false,
    verified: false,
    isArchived: false,
    history: [
      `Tenant authorised — created from lease details submitted by ${verifierName}.`,
      `Contact created via lease entry on ${todayStr}.`,
    ],
    emails: [],
  }));

  const newTenantIds = newContacts.map(c => c.id);

  return {
    contacts: [...contacts, ...newContacts],
    newContacts,
    tenancy: {
      ...tenancy,
      status: 'Active',
      leaseStart: startDate,
      leaseEnd: endDate,
      version: tenancy.version + 1,
      lastVerifiedBy: verifierName,
      lastVerifiedAt: todayStr,
      tenantIds: newTenantIds,
      history: [`Lease created from missing tenancy (Start: ${startDate}, End: ${endDate}). ${newContacts.length} tenant(s) added and authorised.`, ...tenancy.history],
    },
  };
}

export function updateTenancy(
  tenancy: TenancyState,
  updates: Partial<TenancyState>
): TenancyState {
  return { ...tenancy, ...updates };
}
