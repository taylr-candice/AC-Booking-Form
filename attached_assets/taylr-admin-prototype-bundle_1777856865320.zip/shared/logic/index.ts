export { calculateHealth } from "./health";
export type { HealthResult } from "./health";

export {
  addContact,
  archiveContact,
  deleteContact,
  processAgentHandover,
  updateContact,
  isContactVerified,
  isOCVerified,
  isOCFullyVerified,
  isS119Required,
} from "./contacts";
export type { NewContactInput, AddContactResult } from "./contacts";
export { isStrictTenantRole } from "./contacts";

export {
  generateEmailsForNewContact,
  processEmailSend,
} from "./emails";

export {
  verifyLeaseExtended,
  confirmLeaseEnded,
  confirmNewLease,
  confirmOwnerOccupied,
  confirmMissingTenancyLease,
  updateTenancy,
} from "./tenancy";
export type { TenantLeaseInput } from "./tenancy";

export { updateOwnershipCard } from "./ownership";
