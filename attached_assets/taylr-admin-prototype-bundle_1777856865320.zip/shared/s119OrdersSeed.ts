import { computeS119Expiry, parseS119Date } from './logic/health';
import { isUpStrataLost } from './portfolioSeed';

export type S119PaymentStatus = 'Paid' | 'Pending';
export type S119CertStatus = 'Completed and Issued' | 'Pending (Unpaid)';
export type S119VantageStatus = 'Remitted' | 'Pending';

/**
 * Lifecycle of an S119 certificate, evaluated against the OC it was issued
 * under (NOT the unit). S119 certs are valid for 5 years from issue, **per
 * active OC**. If the OC is archived (e.g. unit sold, ownership transferred)
 * mid-validity, the cert is auto-archived too — the new OC, if deemed an
 * investment, must order a fresh certificate.
 */
export type S119Lifecycle =
  | 'Pending Payment'
  | 'Pending Issue'
  | 'Active'
  | 'Expired'
  | 'Archived (OC closed)'
  | 'Voided';

export type S119OcStatus = 'Active' | 'Archived';

export interface S119Order {
  certUploadId: string | null;
  orderDate: string;
  paymentStatus: S119PaymentStatus;
  paymentDate: string | null;
  /**
   * Date the S119 certificate was actually issued. If not explicitly set on
   * the seed, the detail view falls back to paymentDate when the cert has
   * been issued.
   */
  issueDate?: string | null;
  certStatus: S119CertStatus;
  orderId: string;
  salesRef: string;
  upNumber: number;
  buildingName: string;
  propertyAddress: string;
  orderedBy: 'Agent' | 'Owner';
  managingAgent: string | null;
  ownerDetails: string;
  email: string;
  amountIncGst: number;
  transFee: number | null;
  collectedForVantage: number | null;
  paidToVantage: number | null;
  refundAmount: number | null;
  balanceOwing: number;
  vantagePaymentStatus: S119VantageStatus;
  vantageRemittance: string | null;
  /**
   * S119 certs attach to the **Ownership Card**, not the unit. When the OC
   * turns over, the prior OC archives and any in-flight cert under it does
   * too. The new OC starts fresh.
   */
  ocId: string;
  ocOwnerLabel: string;
  ocStatus: S119OcStatus;
  /** Date the OC was archived, only set when ocStatus === 'Archived'. */
  ocArchivedAt?: string;
}

type S119OrderBase = Omit<S119Order, 'ocId' | 'ocOwnerLabel' | 'ocStatus' | 'ocArchivedAt'>;

function ownerSlug(owner: string): string {
  return owner.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
}

/**
 * Synthesises a stable OC id from the unit + owner. In the prototype this is
 * good enough: same unit + same owner = same OC. Real production code would
 * read this off the OC record directly.
 */
function deriveOcId(o: S119OrderBase): string {
  return `oc-up${o.upNumber}-${ownerSlug(o.propertyAddress)}-${ownerSlug(o.ownerDetails)}`;
}

const baseOrders: S119OrderBase[] = [
  {
    certUploadId: '6796ca901d3dc25a6d79f234',
    orderDate: '16 Dec 2024',
    paymentStatus: 'Paid',
    paymentDate: '23 Dec 2024',
    certStatus: 'Completed and Issued',
    orderId: '675f577ef3',
    salesRef: '855638',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '14 / 4 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Carter and Co',
    ownerDetails: 'Millar McCowan & Heidi McCowan',
    email: 'emma@carterandcoagents.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 4',
  },
  {
    certUploadId: '6809b840df99f1c07e12815b',
    orderDate: '02 Apr 2025',
    paymentStatus: 'Paid',
    paymentDate: '11 Apr 2025',
    certStatus: 'Completed and Issued',
    orderId: '239be97b8b',
    salesRef: '725896-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '11 / 4 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Archer Canberra',
    ownerDetails: 'Hilary Clare MCGEACHY',
    email: 'pm9@archercbr.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 10',
  },
  {
    certUploadId: '67f5f1c123e0edc2e901e11c',
    orderDate: '08 Apr 2025',
    paymentStatus: 'Paid',
    paymentDate: '08 Apr 2025',
    certStatus: 'Completed and Issued',
    orderId: '3c1b9bdd2c',
    salesRef: '228047-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '34 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Purnell Real Estate',
    ownerDetails: 'Joshn Pty Limited',
    email: 'accounts@purnellcitywide.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 10',
  },
  {
    certUploadId: '681d7e9a74d7ace833564569',
    orderDate: '29 Apr 2025',
    paymentStatus: 'Paid',
    paymentDate: '01 May 2025',
    certStatus: 'Completed and Issued',
    orderId: '064d9dd3f1',
    salesRef: '353559-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '3 / 4 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'VERV Property',
    ownerDetails: 'Yasith Ruberu',
    email: 'tristan@vervproperty.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 12',
  },
  {
    certUploadId: '6850c58dc2b5c9925eec633b',
    orderDate: '16 Jun 2025',
    paymentStatus: 'Paid',
    paymentDate: '16 Jun 2025',
    certStatus: 'Completed and Issued',
    orderId: '684f92dbe0',
    salesRef: 'pi_3RaTx6AW8ovpvEqp12IIMYo5',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '12 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Boris Property',
    ownerDetails: 'Julie Padanyi-Ryan',
    email: 'sharon@borisproperty.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 13',
  },
  {
    certUploadId: '6854a29613d594ac4941f881',
    orderDate: '19 Jun 2025',
    paymentStatus: 'Paid',
    paymentDate: '19 Jun 2025',
    certStatus: 'Completed and Issued',
    orderId: '5dfa603a54',
    salesRef: '922011-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '5 / 2 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Fuse Property',
    ownerDetails: 'Elvira Garcia & Manuel Garcia',
    email: 'fuseproperty@email.propertyme.com',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 13',
  },
  {
    certUploadId: '685e185957108611408322ad',
    orderDate: '19 Jun 2025',
    paymentStatus: 'Paid',
    paymentDate: '19 Jun 2025',
    certStatus: 'Completed and Issued',
    orderId: '05e4f5d39d',
    salesRef: '209816-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '15 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'HIVE Property',
    ownerDetails: 'Shaeyen M Mackay',
    email: 'jade@hiveproperty.co',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 13',
  },
  {
    certUploadId: '6881b06dfd14a56d83e21c51',
    orderDate: '24 Jun 2025',
    paymentStatus: 'Paid',
    paymentDate: '25 Jun 2025',
    certStatus: 'Completed and Issued',
    orderId: 'bed0d0930f',
    salesRef: '923683-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '5 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'LJ Hooker Belconnen',
    ownerDetails: 'Rhonda M Carpenter & Wayne G Carpenter',
    email: 'akatsibiris@ljhbelconnen.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 14',
  },
  {
    certUploadId: '686ecc4e762e73aac3e53703',
    orderDate: '28 Jun 2025',
    paymentStatus: 'Paid',
    paymentDate: '30 Jun 2025',
    certStatus: 'Completed and Issued',
    orderId: 'e860e74b0b',
    salesRef: '600046-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '9 / 4 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Boris Property',
    ownerDetails: 'Thivakaran Nagaratnam',
    email: 'sharon@borisproperty.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 14',
  },
  {
    certUploadId: '687f0dac754a78d943074074',
    orderDate: '18 Jul 2025',
    paymentStatus: 'Paid',
    paymentDate: '18 Jul 2025',
    certStatus: 'Completed and Issued',
    orderId: 'fdcbd715c1',
    salesRef: '581474-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '2 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Ray White Canberra',
    ownerDetails: 'John P Fisher & Nuno Manuel P Ferreira',
    email: 'lisa.donnellan@raywhite.com',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 14',
  },
  {
    certUploadId: '689d63ed6ea5e1af49af9cd5',
    orderDate: '03 Aug 2025',
    paymentStatus: 'Paid',
    paymentDate: '08 Aug 2025',
    certStatus: 'Completed and Issued',
    orderId: '1d3e031cde',
    salesRef: '931866-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '10 / 4 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Boris Property',
    ownerDetails: 'Thivakaran Nagaratnam',
    email: 'sharon@borisproperty.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 15',
  },
  {
    certUploadId: '68fafab4142e6985f7079272',
    orderDate: '20 Oct 2025',
    paymentStatus: 'Paid',
    paymentDate: '20 Oct 2025',
    certStatus: 'Completed and Issued',
    orderId: '5e8fb1ca13',
    salesRef: '581065-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '21 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Belle Property Canberra',
    ownerDetails: 'Elizabeth Hanbidge',
    email: 'rachel.hooper@belleproperty.com',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 17',
  },
  {
    certUploadId: '69267c507e6efa3003a50b54',
    orderDate: '25 Oct 2025',
    paymentStatus: 'Paid',
    paymentDate: '19 Nov 2025',
    certStatus: 'Completed and Issued',
    orderId: 'b3b1c7c8a1',
    salesRef: '572601-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '7 / 2 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Boris Property',
    ownerDetails: 'Dianne E Cornell',
    email: 'sharon@borisproperty.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 18',
  },
  {
    certUploadId: null,
    orderDate: '31 Oct 2025',
    paymentStatus: 'Pending',
    paymentDate: null,
    certStatus: 'Pending (Unpaid)',
    orderId: '7b615ac9b6',
    salesRef: '246739-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '17 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Ray White Canberra',
    ownerDetails: 'Lucy & Paul Kopec',
    email: 'lisa_donnellan@yahoo.com.au',
    amountIncGst: 342,
    transFee: null,
    collectedForVantage: null,
    paidToVantage: null,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Pending',
    vantageRemittance: null,
  },
  {
    certUploadId: '692913f333dffa6f48fad2b3',
    orderDate: '19 Nov 2025',
    paymentStatus: 'Paid',
    paymentDate: '21 Nov 2025',
    certStatus: 'Completed and Issued',
    orderId: 'b4a26eb4af',
    salesRef: '969350-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '2 / 4 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'ACT Rentals',
    ownerDetails: 'Andrew Dollimore',
    email: 'lexi@actrentals.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 18',
  },
  {
    certUploadId: '693b948e95799960f5ac3806',
    orderDate: '11 Dec 2025',
    paymentStatus: 'Paid',
    paymentDate: '11 Dec 2025',
    certStatus: 'Completed and Issued',
    orderId: '693a10c111',
    salesRef: 'pi_3ScxmPAW8ovpvEqp1r6jc6ns',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '13 / 4 Lady Nelson Place',
    orderedBy: 'Owner',
    managingAgent: null,
    ownerDetails: 'Kurt B Mather',
    email: 'mather.b.kurt@gmail.com',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 19',
  },
  {
    certUploadId: '699e75952eb1044f605acf28',
    orderDate: '18 Feb 2026',
    paymentStatus: 'Paid',
    paymentDate: '18 Feb 2026',
    certStatus: 'Completed and Issued',
    orderId: '6ed53a83e8',
    salesRef: '367236-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '33 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Boris Property',
    ownerDetails: 'Taubenschlag Investments Pty Ltd Taubenschlag Investment Trust',
    email: 'sharon@borisproperty.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 21',
  },
  {
    certUploadId: '69cb48945d4b808f878b45c0',
    orderDate: '24 Mar 2026',
    paymentStatus: 'Paid',
    paymentDate: '24 Mar 2026',
    certStatus: 'Completed and Issued',
    orderId: '8b6c26dd48',
    salesRef: '747314-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '20 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Little Bird Properties',
    ownerDetails: 'Alison C & Martin J Leonard',
    email: 'heidi@littlebirdproperties.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 22',
  },
  {
    certUploadId: null,
    orderDate: '26 Mar 2026',
    paymentStatus: 'Pending',
    paymentDate: null,
    certStatus: 'Pending (Unpaid)',
    orderId: 'cd51b20e5d',
    salesRef: '894565-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '20 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Little Bird Properties',
    ownerDetails: 'Alison C & Martin J Leonard',
    email: 'lauryn@littlebirdproperties.com.au',
    amountIncGst: 342,
    transFee: null,
    collectedForVantage: null,
    paidToVantage: null,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Pending',
    vantageRemittance: null,
  },
];

// ---------------------------------------------------------------------------
// OC binding & cascade demo data
// ---------------------------------------------------------------------------
// Every base order maps 1:1 to a synthesised OC id via (unit + owner). The
// list below is hand-curated to show the cascade behaviour the user wants
// visible across Sales Orders + the OC health card:
//
//   • OCs that have been archived since their cert was issued — the cert is
//     auto-archived even though the 5y term hasn't elapsed.
//   • A fresh OC on the same unit that ordered its own new cert post-turnover.
//
// The OC-archived flag below overrides the synthesised default of 'Active'.
// ---------------------------------------------------------------------------
const archivedOcOverrides: Record<string, { archivedAt: string }> = {
  // Carpenters sold 5/6 Lady Nelson in late 2025; their cert (issued Jun 2025)
  // is now archived along with the OC even though the 5y term runs to 2030.
  'oc-up15853-5-6-lady-nelson-place-rhonda-m-carpenter-wayne-g-carpenter': { archivedAt: '14 Nov 2025' },
};

// Demo "Pending Issue" entries — paid orders whose certificate has not yet
// been issued by the strata manager. These never appear in production seed
// because the historical data is fully closed-out, but they're essential for
// the Certificates Register to show the operational backlog.
const pendingIssueDemoOrders: S119Order[] = [
  {
    certUploadId: null,
    orderDate: '08 Apr 2026',
    paymentStatus: 'Paid',
    paymentDate: '08 Apr 2026',
    issueDate: null,
    certStatus: 'Pending (Unpaid)', // Production state: stays 'Pending (Unpaid)' until promoted to Issued.
    orderId: 'pi5sue001',
    salesRef: '992108-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '21 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'Independent Property Group',
    ownerDetails: 'Daniel & Anita Thompson',
    email: 'admin@ipgcanberra.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: null,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Pending',
    vantageRemittance: null,
    ocId: 'oc-up15853-21-6-lady-nelson-place-daniel-anita-thompson',
    ocOwnerLabel: 'Daniel & Anita Thompson',
    ocStatus: 'Active',
  },
  {
    certUploadId: null,
    orderDate: '14 Apr 2026',
    paymentStatus: 'Paid',
    paymentDate: '14 Apr 2026',
    issueDate: null,
    certStatus: 'Pending (Unpaid)',
    orderId: 'pi5sue002',
    salesRef: '992140-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '8 / 4 Lady Nelson Place',
    orderedBy: 'Owner',
    managingAgent: null,
    ownerDetails: 'Robert J Whitlam',
    email: 'r.whitlam@gmail.com',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: null,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Pending',
    vantageRemittance: null,
    ocId: 'oc-up15853-8-4-lady-nelson-place-robert-j-whitlam',
    ocOwnerLabel: 'Robert J Whitlam',
    ocStatus: 'Active',
  },
];

// Demo entry — a pending-payment S119 order for a unit at Civic Quarter
// (UP14520). Civic Quarter's `relationshipStatus` is 'Expired Lost' on the
// portfolio seed (Vantage's appointment ended 15 Feb 2026), so this order
// voids automatically via the building-level cascade in
// deriveCertificateStatus / getDisplayPaymentStatus. The OC isn't seeded in
// ocListData on purpose — strata-lost buildings don't surface OCs.
const strataLostDemoOrders: S119Order[] = [
  {
    certUploadId: null,
    orderDate: '11 Feb 2026',
    paymentStatus: 'Pending',
    paymentDate: null,
    certStatus: 'Pending (Unpaid)',
    orderId: 'lo5tstr001',
    salesRef: '871422-1',
    upNumber: 14520,
    buildingName: 'Civic Quarter',
    propertyAddress: '12 / 8 Constitution Avenue',
    orderedBy: 'Agent',
    managingAgent: 'Independent Property Group',
    ownerDetails: 'Helen & Ross Whitcombe',
    email: 'admin@ipgcanberra.com.au',
    amountIncGst: 342,
    transFee: null,
    collectedForVantage: null,
    paidToVantage: null,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Pending',
    vantageRemittance: null,
    ocId: 'oc-up14520-12-8-constitution-avenue-helen-ross-whitcombe',
    ocOwnerLabel: 'Helen & Ross Whitcombe',
    ocStatus: 'Active',
  },
  // Three issued certs from before the appointment ended — these survive
  // the strata-loss cascade (paid + issued certs stay valid until their
  // 5-year expiry) so the strata-portal handover assistant has real data
  // to work with.
  {
    certUploadId: '68a11d3b22aa01c4f1100021',
    orderDate: '14 Aug 2025',
    paymentStatus: 'Paid',
    paymentDate: '14 Aug 2025',
    issueDate: '15 Aug 2025',
    certStatus: 'Completed and Issued',
    orderId: 'lo5tstr101',
    salesRef: '901144-1',
    upNumber: 14520,
    buildingName: 'Civic Quarter',
    propertyAddress: '4 / 8 Constitution Avenue',
    orderedBy: 'Agent',
    managingAgent: 'Independent Property Group',
    ownerDetails: 'Marcus & Lena Foulis',
    email: 'admin@ipgcanberra.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 14',
    ocId: 'oc-up14520-4-8-constitution-avenue-marcus-lena-foulis',
    ocOwnerLabel: 'Marcus & Lena Foulis',
    ocStatus: 'Active',
  },
  {
    certUploadId: '68f4cd1455bb02d501100022',
    orderDate: '03 Nov 2025',
    paymentStatus: 'Paid',
    paymentDate: '03 Nov 2025',
    issueDate: '04 Nov 2025',
    certStatus: 'Completed and Issued',
    orderId: 'lo5tstr102',
    salesRef: '901188-1',
    upNumber: 14520,
    buildingName: 'Civic Quarter',
    propertyAddress: '22 / 8 Constitution Avenue',
    orderedBy: 'Agent',
    managingAgent: 'LJ Hooker Canberra City',
    ownerDetails: 'Daniel Cho',
    email: 'leasing@ljhcity.com.au',
    amountIncGst: 332,
    transFee: 5.94,
    collectedForVantage: 326.06,
    paidToVantage: 326.06,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 17',
    ocId: 'oc-up14520-22-8-constitution-avenue-daniel-cho',
    ocOwnerLabel: 'Daniel Cho',
    ocStatus: 'Active',
  },
  {
    certUploadId: '69021abc77cc03d602100023',
    orderDate: '20 Jan 2026',
    paymentStatus: 'Paid',
    paymentDate: '20 Jan 2026',
    issueDate: '21 Jan 2026',
    certStatus: 'Completed and Issued',
    orderId: 'lo5tstr103',
    salesRef: '901244-1',
    upNumber: 14520,
    buildingName: 'Civic Quarter',
    propertyAddress: '37 / 8 Constitution Avenue',
    orderedBy: 'Agent',
    managingAgent: 'Independent Property Group',
    ownerDetails: 'Sarah & James Whitfield',
    email: 'admin@ipgcanberra.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 19',
    ocId: 'oc-up14520-37-8-constitution-avenue-sarah-james-whitfield',
    ocOwnerLabel: 'Sarah & James Whitfield',
    ocStatus: 'Active',
  },
];

// Demo cascade entries — appended after the historical orders so they show
// the new OC's fresh certificate on the same unit.
const cascadeDemoOrders: S119Order[] = [
  {
    certUploadId: '69e21cabf17a7c1a4b001234',
    orderDate: '02 Dec 2025',
    paymentStatus: 'Paid',
    paymentDate: '02 Dec 2025',
    issueDate: '02 Dec 2025',
    certStatus: 'Completed and Issued',
    orderId: 'ca5cade001',
    salesRef: '988201-1',
    upNumber: 15853,
    buildingName: 'The Parks - Stage 2',
    propertyAddress: '5 / 6 Lady Nelson Place',
    orderedBy: 'Agent',
    managingAgent: 'LJ Hooker Belconnen',
    ownerDetails: 'Priya & Sanjay Mehta',
    email: 'akatsibiris@ljhbelconnen.com.au',
    amountIncGst: 342,
    transFee: 6.11,
    collectedForVantage: 335.89,
    paidToVantage: 335.89,
    refundAmount: null,
    balanceOwing: 0,
    vantagePaymentStatus: 'Remitted',
    vantageRemittance: 'Remittance # 19',
    ocId: 'oc-up15853-5-6-lady-nelson-place-priya-sanjay-mehta',
    ocOwnerLabel: 'Priya & Sanjay Mehta',
    ocStatus: 'Active',
  },
];

export const s119Orders: S119Order[] = [
  ...baseOrders.map<S119Order>(o => {
    const ocId = deriveOcId(o);
    const archived = archivedOcOverrides[ocId];
    return {
      ...o,
      ocId,
      ocOwnerLabel: o.ownerDetails,
      ocStatus: archived ? 'Archived' : 'Active',
      ...(archived ? { ocArchivedAt: archived.archivedAt } : {}),
    };
  }),
  ...cascadeDemoOrders,
  ...pendingIssueDemoOrders,
  ...strataLostDemoOrders,
];

// ---------------------------------------------------------------------------
// Lifecycle helpers
// ---------------------------------------------------------------------------

export interface S119LifecycleResult {
  state: S119Lifecycle;
  issueDate: string | null;
  expiryDate: string | null;
  daysRemaining: number | null;
  /** Set when state === 'Archived (OC closed)'. */
  ocArchivedAt?: string;
}

/**
 * Computes the runtime lifecycle of an S119 cert. OC archival cascades — a
 * still-valid cert under an archived OC is reported as Archived (OC closed)
 * regardless of the 5y term.
 */
export function deriveS119OrderLifecycle(order: S119Order, now: Date = new Date()): S119LifecycleResult {
  const issueDate = order.issueDate
    ?? (order.certStatus === 'Completed and Issued' ? order.paymentDate : null)
    ?? null;
  const expiryDate = issueDate ? computeS119Expiry(issueDate) : null;

  // Money not in yet. Cascade-void if the OC archived or the building's
  // strata appointment ended (single source of truth: portfolioSeed).
  if (order.paymentStatus === 'Pending') {
    if (order.ocStatus === 'Archived' || isUpStrataLost(order.upNumber)) {
      return {
        state: 'Voided',
        issueDate,
        expiryDate,
        daysRemaining: null,
        ocArchivedAt: order.ocArchivedAt,
      };
    }
    return { state: 'Pending Payment', issueDate, expiryDate, daysRemaining: null };
  }
  // Paid but the strata manager hasn't issued the cert yet.
  if (order.certStatus !== 'Completed and Issued') {
    return { state: 'Pending Issue', issueDate, expiryDate, daysRemaining: null };
  }

  // OC archival cascades to cert.
  if (order.ocStatus === 'Archived') {
    return {
      state: 'Archived (OC closed)',
      issueDate,
      expiryDate,
      daysRemaining: null,
      ocArchivedAt: order.ocArchivedAt,
    };
  }

  // Otherwise compare expiry vs now.
  const exp = parseS119Date(expiryDate ?? undefined);
  if (!exp) return { state: 'Active', issueDate, expiryDate, daysRemaining: null };
  const ms = exp.getTime() - now.getTime();
  const daysRemaining = Math.round(ms / (1000 * 60 * 60 * 24));
  return {
    state: ms < 0 ? 'Expired' : 'Active',
    issueDate,
    expiryDate,
    daysRemaining,
  };
}

export function getS119OrdersForUnit(propertyAddress: string): S119Order[] {
  return s119Orders.filter(o => o.propertyAddress === propertyAddress);
}

export function getS119OrdersForOC(ocId: string): S119Order[] {
  return s119Orders.filter(o => o.ocId === ocId);
}

/**
 * Returns the most recent issued S119 order for the given unit. When
 * `currentOcId` is supplied, only orders attached to that OC count — this is
 * how the OC health card surfaces a cert as "valid under this OC" vs "from a
 * prior OC, no longer applicable".
 */
export function getLatestS119ForUnit(propertyAddress: string, currentOcId?: string): S119Order | null {
  let orders = getS119OrdersForUnit(propertyAddress);
  if (currentOcId) orders = orders.filter(o => o.ocId === currentOcId);
  if (orders.length === 0) return null;
  const issued = orders.filter(o => o.certStatus === 'Completed and Issued');
  if (issued.length > 0) return issued[issued.length - 1];
  return orders[orders.length - 1];
}

/**
 * Returns the active (not OC-archived, not expired) issued S119 cert for an
 * OC, if any. Used by the OC health card.
 */
export function getActiveS119ForOC(ocId: string, now: Date = new Date()): S119Order | null {
  const orders = getS119OrdersForOC(ocId).filter(o => o.certStatus === 'Completed and Issued');
  for (let i = orders.length - 1; i >= 0; i--) {
    const lc = deriveS119OrderLifecycle(orders[i], now);
    if (lc.state === 'Active') return orders[i];
  }
  return null;
}

export function getS119OrdersByRemittance(): Record<string, S119Order[]> {
  const groups: Record<string, S119Order[]> = {};
  for (const o of s119Orders) {
    const key = o.vantageRemittance || 'Pending';
    if (!groups[key]) groups[key] = [];
    groups[key].push(o);
  }
  return groups;
}
