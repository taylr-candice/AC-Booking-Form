/**
 * Email-template seed for the Communications module. Strata partners appoint
 * Taylr to send templated, sequenced communications to members of the
 * buildings they manage. Templates are configured per partner (admin) and
 * surfaced read-only in the strata view.
 *
 * The data model captures the three things strata partners care about:
 *   1. WHEN the email fires (trigger + delay + sequence position).
 *   2. WHO receives it (audience scope + optional dynamic filters).
 *   3. WHAT dynamic content gets included (rules conditioned on building
 *      features or member context — e.g. only include the waste-chute
 *      section if the building has a waste chute).
 *
 * Activity entries record sends so the strata can see "what went out, to
 * how many recipients, when".
 */

export type EmailTriggerKey =
  | 'building:registered'
  | 'building:established'
  | 'member:invited'
  | 'member:onboarded'
  | 'member:moved-in'
  | 'member:settlement'
  | 'member:tenancy-started';

export interface EmailTriggerMeta {
  key: EmailTriggerKey;
  /** Short human label used in pills and tables. */
  label: string;
  /** One-line plain-English description for the row tooltip / shelf. */
  description: string;
}

export const EMAIL_TRIGGERS: Record<EmailTriggerKey, EmailTriggerMeta> = {
  'building:registered': {
    key: 'building:registered',
    label: 'Building registered',
    description: 'Fires when a building is registered with the relevant authority.',
  },
  'building:established': {
    key: 'building:established',
    label: 'Building established',
    description: 'Fires once the building reaches Established stage (post-handover).',
  },
  'member:invited': {
    key: 'member:invited',
    label: 'Member invited',
    description: 'Fires when a member is added to the strata roll for the first time.',
  },
  'member:onboarded': {
    key: 'member:onboarded',
    label: 'Member onboarded',
    description: 'Fires after a member completes identity verification and joins the portal.',
  },
  'member:moved-in': {
    key: 'member:moved-in',
    label: 'Member moved in',
    description: 'Fires when a resident records their move-in date.',
  },
  'member:settlement': {
    key: 'member:settlement',
    label: 'Settlement',
    description: 'Fires on the recorded settlement date for a new owner.',
  },
  'member:tenancy-started': {
    key: 'member:tenancy-started',
    label: 'Tenancy started',
    description: 'Fires when a new tenancy is recorded against a unit.',
  },
};

export type EmailAudienceScope =
  | 'all-members'
  | 'all-owners'
  | 'residents'
  | 'offsite-owners'
  | 'tenants'
  | 'committee';

export interface EmailAudienceMeta {
  scope: EmailAudienceScope;
  label: string;
  /** Short qualifier e.g. 'Owners who live in the building'. */
  qualifier: string;
}

export const EMAIL_AUDIENCES: Record<EmailAudienceScope, EmailAudienceMeta> = {
  'all-members':    { scope: 'all-members',    label: 'All members',    qualifier: 'Owners and tenants on the strata roll.' },
  'all-owners':     { scope: 'all-owners',     label: 'All owners',     qualifier: 'Lot owners regardless of where they live.' },
  'residents':      { scope: 'residents',      label: 'Residents',      qualifier: 'People who live in the building (owner-occupiers + tenants).' },
  'offsite-owners': { scope: 'offsite-owners', label: 'Offsite owners', qualifier: 'Owners who do not live in the building.' },
  'tenants':        { scope: 'tenants',        label: 'Tenants',        qualifier: 'People renting a unit in the building.' },
  'committee':      { scope: 'committee',      label: 'Committee',      qualifier: 'Members of the OC executive committee.' },
};

/**
 * Dynamic rule — a conditional block of content that's included or excluded
 * based on building or member context. Strata partners need to see these so
 * they understand why a given recipient gets a particular block.
 */
export interface EmailDynamicRule {
  id: string;
  /** Plain-English condition, e.g. "Building has waste chute". */
  condition: string;
  /** Plain-English effect, e.g. "Include garbage waste section". */
  effect: string;
}

export interface EmailTemplate {
  id: string;
  strataId: string;
  /** Sequence this template belongs to — groups templates that fire from
   *  the same trigger together (e.g. the post-settlement onboarding flow). */
  sequenceKey: string;
  sequenceLabel: string;
  /** Position within the sequence, 1-indexed. */
  sequenceOrder: number;
  trigger: EmailTriggerKey;
  /** Days after the trigger that the email fires. 0 = same day. */
  delayDays: number;
  name: string;
  subject: string;
  /** Short plain-text preview of the body (3-5 sentences). The full HTML
   *  body lives elsewhere; the preview is what strata see in the shelf. */
  bodyPreview: string;
  audience: EmailAudienceScope;
  /** Optional building-feature gate — only sent for buildings that have
   *  the listed feature(s). */
  requiresBuildingFeature?: string[];
  dynamicRules: EmailDynamicRule[];
  active: boolean;
  /** Date the template was last modified by Taylr admin. */
  updatedAt: string;
}

export type EmailActivityStatus = 'sent' | 'queued' | 'failed';

export interface EmailActivityEntry {
  id: string;
  strataId: string;
  templateId: string;
  buildingId: string;
  buildingName: string;
  recipientCount: number;
  sentAt: string;
  status: EmailActivityStatus;
}

// ---------------------------------------------------------------------------
// Seed data — Vantage Strata (strata-001)
// ---------------------------------------------------------------------------

export const emailTemplates: EmailTemplate[] = [
  {
    id: 'tpl-vantage-welcome',
    strataId: 'strata-001',
    sequenceKey: 'onboarding',
    sequenceLabel: 'Member onboarding',
    sequenceOrder: 1,
    trigger: 'member:invited',
    delayDays: 0,
    name: 'Welcome to your building',
    subject: 'Welcome to {{buildingName}} — a quick intro',
    bodyPreview:
      'Welcomes the new member to the building, introduces Vantage Strata as the managing agent, and links to the resident portal so they can verify their identity. Includes a short "what to expect from us" section.',
    audience: 'all-members',
    dynamicRules: [
      { id: 'r1', condition: 'Building has concierge', effect: 'Includes concierge contact card.' },
      { id: 'r2', condition: 'Member is a tenant', effect: 'Replaces "ownership" wording with "tenancy" wording.' },
    ],
    active: true,
    updatedAt: '02 Apr 2026',
  },
  {
    id: 'tpl-vantage-id-verify',
    strataId: 'strata-001',
    sequenceKey: 'onboarding',
    sequenceLabel: 'Member onboarding',
    sequenceOrder: 2,
    trigger: 'member:invited',
    delayDays: 3,
    name: 'Reminder: verify your identity',
    subject: 'A quick step to finish setting up your portal access',
    bodyPreview:
      'Sent if the member has not completed identity verification within 3 days of being invited. Links to the verification flow and explains why ID is required (NSW strata regulation).',
    audience: 'all-members',
    dynamicRules: [
      { id: 'r1', condition: 'Member already verified', effect: 'Email is skipped.' },
    ],
    active: true,
    updatedAt: '14 Mar 2026',
  },
  {
    id: 'tpl-vantage-resident-induction',
    strataId: 'strata-001',
    sequenceKey: 'resident-induction',
    sequenceLabel: 'Resident induction',
    sequenceOrder: 1,
    trigger: 'member:moved-in',
    delayDays: 1,
    name: 'Living in the building — your essentials',
    subject: 'Settling into {{buildingName}}',
    bodyPreview:
      'Sent the day after move-in. Covers building access (FOBs / intercom), parking spot (if any), bin locations, lift bookings for moves, and the resident WhatsApp group if one exists.',
    audience: 'residents',
    dynamicRules: [
      { id: 'r1', condition: 'Building has waste chute',  effect: 'Includes the waste-chute do/don\'t section.' },
      { id: 'r2', condition: 'Building has parking',     effect: 'Includes parking allocation + visitor parking notes.' },
      { id: 'r3', condition: 'Building has lifts',       effect: 'Includes the moving-day lift booking instructions.' },
    ],
    active: true,
    updatedAt: '28 Mar 2026',
  },
  {
    id: 'tpl-vantage-amenities',
    strataId: 'strata-001',
    sequenceKey: 'resident-induction',
    sequenceLabel: 'Resident induction',
    sequenceOrder: 2,
    trigger: 'member:moved-in',
    delayDays: 7,
    name: 'Amenities & house rules',
    subject: 'Pool, gym, BBQ — how to book and the house rules',
    bodyPreview:
      'A week after move-in. Walks residents through the bookable amenities and links to the by-laws PDF. Only sent if the building has at least one bookable amenity.',
    audience: 'residents',
    requiresBuildingFeature: ['pool', 'gym', 'bbq'],
    dynamicRules: [
      { id: 'r1', condition: 'Building has pool', effect: 'Includes pool hours + child-supervision rule.' },
      { id: 'r2', condition: 'Building has gym',  effect: 'Includes gym access hours + equipment etiquette.' },
      { id: 'r3', condition: 'Building has BBQ',  effect: 'Includes BBQ booking link + cleaning rule.' },
    ],
    active: true,
    updatedAt: '11 Apr 2026',
  },
  {
    id: 'tpl-vantage-s119-issued',
    strataId: 'strata-001',
    sequenceKey: 'settlement',
    sequenceLabel: 'Settlement & S119',
    sequenceOrder: 1,
    trigger: 'member:settlement',
    delayDays: 0,
    name: 'Your S119 certificate is ready',
    subject: 'S119 Rental Certificate — {{buildingName}}',
    bodyPreview:
      'Sent on settlement day to the new owner. Confirms the S119 has been issued, attaches the PDF, and links to the portal where the certificate is also stored.',
    audience: 'all-owners',
    dynamicRules: [
      { id: 'r1', condition: 'Building is in ACT',        effect: 'Email is sent (S119 only applies in ACT).' },
      { id: 'r2', condition: 'Member is an offsite owner', effect: 'Adds line about lodging the certificate with their tenancy agent.' },
    ],
    active: true,
    updatedAt: '20 Mar 2026',
  },
  {
    id: 'tpl-vantage-offsite-quarterly',
    strataId: 'strata-001',
    sequenceKey: 'offsite-owners',
    sequenceLabel: 'Offsite owner cadence',
    sequenceOrder: 1,
    trigger: 'building:established',
    delayDays: 90,
    name: 'Quarterly building update',
    subject: '{{buildingName}} — your Q{{quarter}} update',
    bodyPreview:
      'Quarterly summary for owners who live elsewhere: works completed, works planned, next AGM date, and a one-line financial position. Excludes any operational notices that only matter to residents.',
    audience: 'offsite-owners',
    dynamicRules: [
      { id: 'r1', condition: 'Levy notice is overdue', effect: 'Adds an "Outstanding levies" section at the top.' },
    ],
    active: false,
    updatedAt: '06 Apr 2026',
  },
];

export const emailActivity: EmailActivityEntry[] = [
  { id: 'act-001', strataId: 'strata-001', templateId: 'tpl-vantage-welcome',             buildingId: 'b-the-parks-stage-2',  buildingName: 'The Parks - Stage 2',  recipientCount: 4, sentAt: '17 Apr 2026', status: 'sent' },
  { id: 'act-002', strataId: 'strata-001', templateId: 'tpl-vantage-resident-induction',  buildingId: 'b-the-parks-stage-2',  buildingName: 'The Parks - Stage 2',  recipientCount: 3, sentAt: '17 Apr 2026', status: 'sent' },
  { id: 'act-003', strataId: 'strata-001', templateId: 'tpl-vantage-s119-issued',         buildingId: 'b-the-parks-stage-2',  buildingName: 'The Parks - Stage 2',  recipientCount: 1, sentAt: '15 Apr 2026', status: 'sent' },
  { id: 'act-004', strataId: 'strata-001', templateId: 'tpl-vantage-amenities',           buildingId: 'b-the-parks-stage-2',  buildingName: 'The Parks - Stage 2',  recipientCount: 3, sentAt: '14 Apr 2026', status: 'sent' },
  { id: 'act-005', strataId: 'strata-001', templateId: 'tpl-vantage-id-verify',           buildingId: 'b-the-parks-stage-2',  buildingName: 'The Parks - Stage 2',  recipientCount: 1, sentAt: '12 Apr 2026', status: 'sent' },
  { id: 'act-006', strataId: 'strata-001', templateId: 'tpl-vantage-welcome',             buildingId: 'b-park-avenue',        buildingName: 'Park Avenue',          recipientCount: 6, sentAt: '10 Apr 2026', status: 'sent' },
  { id: 'act-007', strataId: 'strata-001', templateId: 'tpl-vantage-resident-induction',  buildingId: 'b-park-avenue',        buildingName: 'Park Avenue',          recipientCount: 5, sentAt: '11 Apr 2026', status: 'sent' },
  { id: 'act-008', strataId: 'strata-001', templateId: 'tpl-vantage-offsite-quarterly',   buildingId: 'b-park-avenue',        buildingName: 'Park Avenue',          recipientCount: 0, sentAt: '06 Apr 2026', status: 'failed' },
  { id: 'act-009', strataId: 'strata-001', templateId: 'tpl-vantage-welcome',             buildingId: 'b-skyline-towers',     buildingName: 'Skyline Towers',       recipientCount: 2, sentAt: '03 Apr 2026', status: 'sent' },
  { id: 'act-010', strataId: 'strata-001', templateId: 'tpl-vantage-amenities',           buildingId: 'b-skyline-towers',     buildingName: 'Skyline Towers',       recipientCount: 2, sentAt: '10 Apr 2026', status: 'sent' },
];

export function getEmailTemplatesForStrata(strataId: string): EmailTemplate[] {
  return emailTemplates.filter(t => t.strataId === strataId);
}

export function getEmailActivityForStrata(strataId: string): EmailActivityEntry[] {
  return emailActivity.filter(a => a.strataId === strataId);
}

export function getEmailTemplateById(id: string): EmailTemplate | undefined {
  return emailTemplates.find(t => t.id === id);
}
