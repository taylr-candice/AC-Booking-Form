/** White-label branding a partner strata can apply to their Taylr portal. The
 *  strata view (and admin's "View as strata" preview) reads from here so the
 *  brand mark and accents reflect the partner, not Taylr. Editable in the
 *  admin → Strata → Branding card; persisted via StrataBrandingContext. */
export interface StrataBranding {
  /** Primary brand colour as a hex string (e.g. '#F47B20'). Used for the
   *  brand-mark circle in the sidebar and any partner-coloured accents. */
  primaryColor: string;
  /** Two-letter wordmark shown inside the brand-mark circle. Falls back to
   *  the first two initials of the company name when undefined. */
  initials?: string;
  /** Short display name for the wordmark (e.g. "Vantage" instead of the
   *  legal "Vantage Strata Pty Ltd"). Falls back to `name`. */
  displayName?: string;
  /** Optional logo URL. Reserved for an upcoming "use logo image instead of
   *  initials" upgrade — wired through the context now so the upgrade is a
   *  one-line render change later. */
  logoUrl?: string;
}

export interface StrataCompany {
  id: string;
  name: string;
  abn: string;
  isPartner: boolean;
  address: string;
  phone: string;
  email: string;
  agreementStart: string;
  agreementTerm: string;
  piqSyncEnabled: boolean;
  lastPiqSync: string;
  servicesEnabled: string[];
  buildingIds: string[];
  contacts: StrataContact[];
  /** Internal users at the strata company who can own a referral/lead. The
   *  strata-portal "My Referrals" view assigns each lead to one of these so
   *  someone inside the company is accountable for the OC-side cycle. Distinct
   *  from `leadInfo.owner` which is the Taylr-side BD/admin owner. */
  users: StrataUser[];
  /** White-label branding override. Editable per-strata in the admin module. */
  brand?: StrataBranding;
}

export interface StrataContact {
  name: string;
  role: string;
  email: string;
  buildings: string[];
}

/** A user inside a strata partner company — the person who owns a referral
 *  on the strata side (e.g. the senior strata manager handling that OC). */
export interface StrataUser {
  id: string;
  name: string;
  role: string;
  email: string;
}

export interface AgentCompany {
  id: string;
  name: string;
  email: string;
  phone: string;
}

export interface BuildingContact {
  name: string;
  role: string;
  email: string;
  phone: string;
  availability?: string;
  daysOnSite?: string[];
  hours?: string;
}

export type AppointmentType = 'Full-time' | 'Part-time' | 'On-call' | 'Casual';

export interface OnSitePersonnel {
  name: string;
  organisation?: string;
  appointedBy: string;
  phone: string;
  email?: string;
  appointmentType: AppointmentType;
  daysOnSite: string[];
  hoursFrom: string;
  hoursTo: string;
  notes?: string;
}

export interface BuildingAgreement {
  startDate: string;
  durationYears: number;
  expiryDate: string;
  status: 'Active' | 'Expired';
  renewalActivity?: LeadActivityEntry[];
}

export type BuildingStage = 'Development' | 'Pre-Settlement' | 'Registered' | 'Established';

export type RelationshipStatus = 'New Lead' | 'Preparing Proposal' | 'Proposal Out' | 'Strata Prospect' | 'Taylr Prospect' | 'Prospect Lost' | 'Contracts Out' | 'Won' | 'Unassigned' | 'Expired Lost' | 'Agreement Expired';

export function isProspect(status: RelationshipStatus): boolean {
  return status === 'New Lead' || status === 'Preparing Proposal' || status === 'Proposal Out' || status === 'Strata Prospect' || status === 'Taylr Prospect';
}

export function isLead(status: RelationshipStatus): boolean {
  return status === 'New Lead' || status === 'Preparing Proposal' || status === 'Proposal Out' || status === 'Strata Prospect' || status === 'Taylr Prospect' || status === 'Contracts Out' || status === 'Prospect Lost';
}

export function getRelationshipBadgeClasses(status: RelationshipStatus): string {
  switch (status) {
    case 'New Lead': return 'bg-purple-100 text-purple-800 border border-purple-300';
    case 'Preparing Proposal': return 'bg-amber-50 text-amber-700 border border-amber-200';
    case 'Proposal Out': return 'bg-orange-50 text-orange-700 border border-orange-200';
    case 'Strata Prospect': return 'bg-slate-100 text-slate-700 border border-slate-300';
    case 'Taylr Prospect': return 'bg-slate-100 text-slate-700 border border-slate-300';
    case 'Prospect Lost': return 'bg-red-100 text-red-700 border border-red-200';
    case 'Contracts Out': return 'bg-amber-50 text-amber-700 border border-amber-200';
    case 'Won': return 'bg-emerald-50 text-emerald-700 border border-emerald-200';
    case 'Unassigned': return 'bg-orange-50 text-orange-700 border border-orange-200';
    case 'Expired Lost': return 'bg-gray-900 text-white border border-gray-800';
    case 'Agreement Expired': return 'bg-white text-gray-500 border border-gray-300';
  }
}

export function getStrataPillClasses(building: Building, strata: StrataCompany | undefined): { label: string; classes: string } {
  // Unassigned: partner strata lost a direct Taylr building — admin must add new strata
  if (building.relationshipStatus === 'Unassigned') {
    return { label: 'Unassigned', classes: 'bg-purple-100 text-purple-800 border border-purple-200' };
  }
  // Partner strata — green pill
  if (strata?.isPartner) {
    return { label: strata.name, classes: 'bg-emerald-50 text-emerald-700 border border-emerald-200' };
  }
  // Non-partner strata — neutral pill
  if (strata) {
    return { label: strata.name, classes: 'bg-white text-gray-700 border border-gray-300' };
  }
  // No strata attached (Taylr Prospect with no strata yet)
  return { label: '—', classes: 'bg-transparent text-gray-400 border-0 px-0' };
}

export interface DeveloperContact {
  name: string;
  title?: string;
  email: string;
  phone?: string;
}

export type ServiceCategory = 'Pre-Settlement Services' | 'Onboarding Services' | 'Utility Connection Services' | 'All Taylr Services';

export interface RevenueSharingParty {
  name: string;
  partyType: 'Developer' | 'Third Party';
  percent: number;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
}

export interface RevenueSharing {
  agreementInPlace: boolean;
  sharePercent?: number;
  parties?: RevenueSharingParty[];
  serviceCategories?: ServiceCategory[];
  appliesFrom?: string;
  termMonths?: number;
  notes?: string;
}

export interface Developer {
  companyName: string;
  abn?: string;
  website?: string;
  address?: string;
  primaryContact: DeveloperContact;
  revenueSharing: RevenueSharing;
}

export type CreationMethod = 'PIQ Sync' | 'Strata Manual' | 'Taylr Manual' | 'Developer Import';

export type LeadActivityType = 'Call' | 'Email' | 'Meeting' | 'Note' | 'Reminder';

export interface LeadActivityEntry {
  id: string;
  date: string;
  type: LeadActivityType;
  author: string;
  content: string;
}

export interface LeadInfo {
  estimatedConversionDate?: string;
  probability: number;
  nextAction?: string;
  nextActionDate?: string;
  /** Taylr-side owner — id of a `TaylrTeamMember` (the BDM/admin running this
   *  lead inside Taylr). Always a Taylr person — never a strata partner.
   *  Resolved via `getTaylrUserById`. */
  taylrOwnerId?: string;
  /** Optional free-text owner label, kept only for legacy seed fallbacks
   *  (e.g. "Unassigned"). When `taylrOwnerId` is set, the resolved Taylr
   *  team member takes precedence. Never use this to put a strata person
   *  into the Taylr-admin owner slot. */
  owner?: string;
  /** Strata-side owner — id of a `StrataUser` within the partner strata
   *  company who's accountable for the OC-side cycle. Set when a strata
   *  partner assigns one of their team members to drive the referral. Only
   *  meaningful for partner-sourced leads. */
  strataOwnerId?: string;
  /** Anticipated annual strata management fee per unit (in AUD), set by the
   *  strata partner when they create the proposal request. The opportunity
   *  size is `feePerUnitPerAnnum × totalUnits`. Once the building converts
   *  and an agreement is signed, the contracted figure is captured on the
   *  building as `agreedFeePerUnitPerAnnum`. */
  feePerUnitPerAnnum?: number;
  activity: LeadActivityEntry[];
}

// ---------------------------------------------------------------------------
// Taylr Proposal Lifecycle
// ---------------------------------------------------------------------------
// A "Taylr proposal" is the parcel-locker proposal pack Taylr produces and
// the strata company presents to the OC as part of *their* sales cycle.
//
// Apr 2026 — proposals are no longer mandatory. A lead either *qualifies*
// for one (size threshold or strata-requested) or it doesn't. When it
// qualifies and one hasn't been provided yet, we put a clear prompt on the
// lead to upload one. Once uploaded we prompt to send; once sent we prompt
// to record the OC's outcome so the opportunity can be closed cleanly.
//
//   • Buildings >= PROPOSAL_QUALIFY_UNIT_THRESHOLD (50) units → qualifies.
//   • Strata-referred buildings (any size) → qualifies.
//   • Everything else → Not Applicable (Taylr can still upload one manually).
//
// Status flow: 'Not Started' → 'Drafted' → 'Sent' → 'Accepted' | 'Declined'.
// Decline still captures decliner + reason for audit, but it no longer
// blocks the lead from being closed.
// ---------------------------------------------------------------------------

export type TaylrProposalStatus = 'Not Started' | 'Drafted' | 'Sent' | 'Accepted' | 'Declined';
export type TaylrProposalRequirement = 'Qualifies' | 'Not Applicable';

export interface ProposalFollowUp {
  id: string;
  date: string;
  channel: 'Email' | 'Call' | 'Portal';
  sender: string;        // e.g. 'System (auto)' or strata lead name
  outcome: string;       // free-text — what happened on this chase
}

export interface ProposalDecliner {
  name: string;
  role: string;          // e.g. 'Developer (Brookswood Properties)' or 'OC Treasurer'
}

export interface ProposalPricingSnapshot {
  lockerCount: number;
  monthlyPerLocker: number;
  installPerUnit: number;
  setupFee: number;
  monthlyTotal: number;
  installTotal: number;
  contractMonths: number;
}

export interface TaylrProposal {
  status: TaylrProposalStatus;
  requirement: TaylrProposalRequirement;
  generatedDate?: string;
  generatedBy?: string;
  sentDate?: string;
  sentBy?: string;
  decisionDate?: string;
  declinedBy?: ProposalDecliner;
  declineReason?: string;
  followUps: ProposalFollowUp[];
  notes?: string;
  /** Pricing snapshot captured when the proposal was uploaded (or, for legacy
   *  seed records, generated). Frozen — backend rate-card changes later don't
   *  rewrite history. */
  pricingSnapshot?: ProposalPricingSnapshot;
  /** Filename of the proposal document Taylr admin uploaded. Prototype-only —
   *  there's no real file storage; we just display it on the lead/building. */
  uploadedFileName?: string;
  /** Strata-side request marker. Set when a strata partner clicks "Request a
   *  Taylr proposal" from the lead detail. Independent of `status` — strata
   *  can request before Taylr admin has uploaded anything. Used to show the
   *  "Awaiting Taylr proposal" pending state on the strata side. */
  requestedDate?: string;
  requestedBy?: string;
}

export interface TaylrProposalPricingParams {
  monthlyFeePerLocker: number;
  installFeePerUnit: number;
  setupFee: number;
  defaultLockerRatio: number;     // lockers per unit
  defaultContractMonths: number;
}

/** Backend-configured pricing parameters used by the auto-generator. Taylr
 *  admin edits these via Finance → Pricing → "Taylr Proposal Generator".
 *
 *  In the prototype this is a module-level mutable record so the PricingTab
 *  edits actually take effect across subsequent proposal generations within
 *  the same session. Use {@link getProposalParams} / {@link setProposalParams}
 *  rather than mutating the constant directly. */
export const TAYLR_PROPOSAL_PRICING: TaylrProposalPricingParams = {
  monthlyFeePerLocker: 14.5,
  installFeePerUnit: 18,
  setupFee: 1450,
  defaultLockerRatio: 0.6,
  defaultContractMonths: 36,
};

let _currentProposalParams: TaylrProposalPricingParams = { ...TAYLR_PROPOSAL_PRICING };
export function getProposalParams(): TaylrProposalPricingParams { return _currentProposalParams; }
export function setProposalParams(p: TaylrProposalPricingParams): void { _currentProposalParams = { ...p }; }

/** Session-only override map for proposal lifecycle updates made in the UI
 *  (e.g. LeadDetail's "Generate proposal", "Mark sent", "Record decision").
 *  Lookups via {@link getEffectiveProposal} consult this map first, falling
 *  back to the building's seeded `taylrProposal`. This lets cross-module
 *  surfaces (Leads alert, etc.) react to lifecycle changes without a real DB. */
const _proposalOverrides: Map<string, TaylrProposal> = new Map();
export function setProposalOverride(buildingId: string, proposal: TaylrProposal): void {
  _proposalOverrides.set(buildingId, proposal);
}
export function getEffectiveProposal(b: Building): TaylrProposal | undefined {
  return _proposalOverrides.get(b.id) ?? b.taylrProposal;
}

export const PROPOSAL_QUALIFY_UNIT_THRESHOLD = 50;
/** @deprecated kept as alias during the rename — use PROPOSAL_QUALIFY_UNIT_THRESHOLD. */
export const MANDATORY_PROPOSAL_UNIT_THRESHOLD = PROPOSAL_QUALIFY_UNIT_THRESHOLD;

export function getProposalRequirement(b: Building): TaylrProposalRequirement {
  if ((b.totalUnits || 0) >= PROPOSAL_QUALIFY_UNIT_THRESHOLD) return 'Qualifies';
  if (b.leadSource === 'Strata Referral') return 'Qualifies';
  return 'Not Applicable';
}

/** True when the lead qualifies for a Taylr proposal. */
export function qualifiesForProposal(b: Building): boolean {
  return getProposalRequirement(b) === 'Qualifies';
}

/** Computes the proposal pricing preview for a building using current params.
 *  Used by the auto-generator; result is captured into pricingSnapshot. */
export function computeProposalPricing(b: Building, p: TaylrProposalPricingParams = getProposalParams()): ProposalPricingSnapshot {
  const units = b.totalUnits || 0;
  const lockerCount = Math.max(1, Math.round(units * p.defaultLockerRatio));
  const monthlyTotal = +(lockerCount * p.monthlyFeePerLocker).toFixed(2);
  const installTotal = +(units * p.installFeePerUnit + p.setupFee).toFixed(2);
  return {
    lockerCount,
    monthlyPerLocker: p.monthlyFeePerLocker,
    installPerUnit: p.installFeePerUnit,
    setupFee: p.setupFee,
    monthlyTotal,
    installTotal,
    contractMonths: p.defaultContractMonths,
  };
}

/** A lead has an "open proposal prompt" when it qualifies for a Taylr
 *  proposal but none has been started yet. Used to surface the gentle
 *  upload nudge on the Leads module (no longer a hard alert — Apr 2026). */
export function hasOpenProposalPrompt(b: Building): boolean {
  if (!isLead(b.relationshipStatus)) return false;
  if (b.relationshipStatus === 'Prospect Lost') return false;
  if (!qualifiesForProposal(b)) return false;
  const status = getEffectiveProposal(b)?.status ?? 'Not Started';
  return status === 'Not Started';
}
/** @deprecated renamed to hasOpenProposalPrompt. */
export const hasMissingProposalOpportunity = hasOpenProposalPrompt;

// ---------------------------------------------------------------------------
// Admin action queue (notification bell)
// ---------------------------------------------------------------------------
// Computes the set of "action required" items for Taylr admin across the lead
// pipeline. One action per lead — the most urgent one outstanding — so the
// queue stays focussed on the next actual move. Items disappear automatically
// once their underlying state changes (proposal uploaded, lead status moved,
// decision recorded, etc.) — i.e. "stays until actioned" comes for free since
// it's all derived from the building/proposal state.
// ---------------------------------------------------------------------------
export type AdminActionUrgency = 'critical' | 'high' | 'normal';
export type AdminActionKind =
  | 'pickup-new-lead'
  | 'upload-qualified-proposal'
  | 'issue-drafted-proposal'
  | 'awaiting-decision';

export interface AdminAction {
  id: string;
  buildingId: string;
  buildingSlug: string;
  buildingName: string;
  strataName?: string;
  totalUnits: number;
  urgency: AdminActionUrgency;
  kind: AdminActionKind;
  label: string;
  reason: string;
}

export function getAdminActionUrgencyLabel(u: AdminActionUrgency): string {
  return u === 'critical' ? 'Critical' : u === 'high' ? 'High' : 'Normal';
}

/** Compute the single most-urgent outstanding action for one lead, or null
 *  if nothing is required. Order: critical > high > normal. */
function deriveLeadAction(b: Building): AdminAction | null {
  if (!isLead(b.relationshipStatus)) return null;
  if (b.relationshipStatus === 'Prospect Lost') return null;

  const strata = b.strataId ? strataCompanies.find(s => s.id === b.strataId) : undefined;
  const baseFields = {
    buildingId: b.id,
    buildingSlug: b.slug,
    buildingName: b.name,
    strataName: strata?.name,
    totalUnits: b.totalUnits || 0,
  };

  const proposal = getEffectiveProposal(b);
  const proposalStatus: TaylrProposalStatus = proposal?.status ?? 'Not Started';
  const requirement = getProposalRequirement(b);

  // HIGH (wins over Critical here because admin can't upload without first
  // picking up the lead) — Lead has just landed in the New Lead inbox.
  if (b.relationshipStatus === 'New Lead') {
    return {
      ...baseFields,
      id: `${b.id}-pickup-new-lead`,
      urgency: 'high',
      kind: 'pickup-new-lead',
      label: 'Pick up new lead',
      reason: `${strata?.name ?? 'New referral'} request awaiting Taylr triage`,
    };
  }

  // NORMAL — Lead qualifies for a Taylr proposal but none has been started.
  // No longer flagged as critical (Apr 2026 — proposals aren't mandatory);
  // it's just a prompt for admin to consider uploading one.
  if (requirement === 'Qualifies' && proposalStatus === 'Not Started') {
    return {
      ...baseFields,
      id: `${b.id}-upload-qualified`,
      urgency: 'normal',
      kind: 'upload-qualified-proposal',
      label: 'Upload Taylr proposal',
      reason: `${b.totalUnits} units · ${strata?.name ?? 'No strata'} — qualifies for a proposal`,
    };
  }

  // HIGH — Proposal drafted internally but not yet issued.
  if (proposalStatus === 'Drafted') {
    return {
      ...baseFields,
      id: `${b.id}-issue-drafted`,
      urgency: 'high',
      kind: 'issue-drafted-proposal',
      label: 'Issue drafted proposal',
      reason: proposal?.generatedDate
        ? `Drafted ${proposal.generatedDate} — push to ${strata?.name ?? 'lead'}`
        : `Drafted — push to ${strata?.name ?? 'lead'}`,
    };
  }

  // NORMAL — Sent proposal awaiting decision (cadence is auto-running).
  if (proposalStatus === 'Sent') {
    return {
      ...baseFields,
      id: `${b.id}-awaiting-decision`,
      urgency: 'normal',
      kind: 'awaiting-decision',
      label: 'Awaiting decision',
      reason: proposal?.sentDate
        ? `Sent ${proposal.sentDate} — auto follow-ups in flight`
        : 'Auto follow-ups in flight',
    };
  }

  return null;
}

/** All outstanding admin actions across the lead portfolio, sorted by urgency
 *  (critical → high → normal) then by building name. */
export function getAdminActions(): AdminAction[] {
  const urgencyRank: Record<AdminActionUrgency, number> = { critical: 0, high: 1, normal: 2 };
  const actions = buildings
    .map(deriveLeadAction)
    .filter((a): a is AdminAction => a !== null);
  return actions.sort((a, b) => {
    const ur = urgencyRank[a.urgency] - urgencyRank[b.urgency];
    if (ur !== 0) return ur;
    return a.buildingName.localeCompare(b.buildingName);
  });
}

export function getProposalStatusClasses(s: TaylrProposalStatus): string {
  // Cleaner palette (Apr 2026) — neutral slate for in-flight states, a single
  // soft green for the positive terminal and a single soft slate for closed.
  switch (s) {
    case 'Not Started': return 'bg-slate-50 text-slate-600 border-slate-200';
    case 'Drafted':     return 'bg-slate-50 text-slate-700 border-slate-200';
    case 'Sent':        return 'bg-slate-100 text-slate-800 border-slate-200';
    case 'Accepted':    return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'Declined':    return 'bg-slate-50 text-slate-500 border-slate-200';
  }
}

export function getProposalRequirementClasses(r: TaylrProposalRequirement): string {
  switch (r) {
    case 'Qualifies':      return 'bg-slate-50 text-slate-700 border-slate-200';
    case 'Not Applicable': return 'bg-slate-50 text-slate-400 border-slate-200';
  }
}

/**
 * Origin / provenance of a building in the Taylr CRM.
 * Distinct from `creationMethod` (which is *how* the record was technically
 * inserted — PIQ Sync, Strata Manual, etc.). Origin captures the *story* of
 * how the building came to be in the CRM and is the anchor for all CRM
 * history (lead activity, partner referral notes, inbound enquiry threads).
 */
export type BuildingOriginSource =
  | 'Lead Conversion'           // came through the leads pipeline (preserved leadInfo.activity)
  | 'Strata Partner Onboarding' // brought to Taylr by a partner strata (no lead phase)
  | 'Developer Handover'        // direct handover from developer (no lead phase)
  | 'Inbound Enquiry'           // building / strata / OC reached out to Taylr
  | 'Direct Outreach'           // Taylr BD signed without a partner-led pursuit
  | 'PIQ Import'                // bulk imported via partner sync
  | 'Other';

export interface BuildingOrigin {
  source: BuildingOriginSource;
  date: string;        // when the building entered the CRM (e.g. "17 May 2025")
  addedBy: string;     // person / system that added it
  notes?: string;      // free-text "how it came about" story (recommended)
}

export function getOriginSourceClasses(source: BuildingOriginSource): string {
  switch (source) {
    case 'Lead Conversion':           return 'bg-pink-50 text-pink-700 border-pink-200';
    case 'Strata Partner Onboarding': return 'bg-purple-50 text-purple-700 border-purple-200';
    case 'Developer Handover':        return 'bg-orange-50 text-orange-700 border-orange-200';
    case 'Inbound Enquiry':           return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'Direct Outreach':           return 'bg-blue-50 text-blue-700 border-blue-200';
    case 'PIQ Import':                return 'bg-slate-100 text-slate-700 border-slate-200';
    case 'Other':                     return 'bg-gray-100 text-gray-700 border-gray-200';
  }
}

export const BUILDING_ORIGIN_SOURCES: BuildingOriginSource[] = [
  'Lead Conversion',
  'Strata Partner Onboarding',
  'Developer Handover',
  'Inbound Enquiry',
  'Direct Outreach',
  'PIQ Import',
  'Other',
];

// ---------------------------------------------------------------------------
// Building lead source
// ---------------------------------------------------------------------------
// Where a lead came from. `Strata Referral` paired with `New Lead` / `Preparing Proposal`
// represents a strata company asking Taylr to prepare a parcel-locker
// proposal on behalf of an OC. Delivery of the proposal depends on whether
// the requesting strata is a Taylr partner:
//   • Partner strata → load the proposal directly into the partner's
//     Vantage-style portal so it surfaces in their managed pipeline.
//   • Non-partner strata → email the proposal pack to the strata contact
//     for them to forward to the OC.
// Once delivered, the lead advances to `Strata Prospect`.
// ---------------------------------------------------------------------------

export type BuildingLeadSource =
  | 'Strata Referral'           // strata company (partner or not) asked Taylr for a proposal
  | 'Developer'                 // developer engaged Taylr directly (typically pre-settlement)
  | 'Inbound Enquiry'           // OC / building / public reached out directly
  | 'Direct Outreach'           // Taylr BD identified and pursued
  | 'Referral'                  // referred by another building / contact
  | 'PIQ Pipeline'              // surfaced by partner sync as a candidate
  | 'Other';

export const BUILDING_LEAD_SOURCES: BuildingLeadSource[] = [
  'Strata Referral',
  'Developer',
  'Inbound Enquiry',
  'Direct Outreach',
  'Referral',
  'PIQ Pipeline',
  'Other',
];

/**
 * Strata-portal lead source — how the *strata* came across this building or
 * decided to refer it to Taylr. From the strata's POV, "Strata Referral" is
 * meaningless (they ARE the strata), so they see their own intake funnel
 * instead: developer hand-overs, web form sign-ups, campaign responses, etc.
 */
export type StrataLeadSource =
  | 'Developer'              // developer engaged the strata at handover
  | 'Inbound webform'        // strata sales site form
  | 'Campaign'               // marketing / outreach campaign
  | 'Direct outreach'        // strata BD pursued directly
  | 'Existing client'        // already managing for the OC
  | 'Referral'               // referred by another building / contact
  | 'Other';

export const STRATA_LEAD_SOURCES: StrataLeadSource[] = [
  'Developer',
  'Inbound webform',
  'Campaign',
  'Direct outreach',
  'Existing client',
  'Referral',
  'Other',
];

export function getBuildingLeadSourceClasses(source: BuildingLeadSource): string {
  switch (source) {
    case 'Strata Referral': return 'bg-purple-50 text-purple-700 border-purple-200';
    case 'Developer':              return 'bg-orange-50 text-orange-700 border-orange-200';
    case 'Inbound Enquiry':        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'Direct Outreach':        return 'bg-blue-50 text-blue-700 border-blue-200';
    case 'Referral':               return 'bg-amber-50 text-amber-700 border-amber-200';
    case 'PIQ Pipeline':           return 'bg-slate-100 text-slate-700 border-slate-200';
    case 'Other':                  return 'bg-gray-100 text-gray-700 border-gray-200';
  }
}

/**
 * Standard lost-reason categories surfaced in the **Taylr admin** Leads UI.
 * Buildings don't *need* Taylr — adopting the platform is a discretionary
 * choice — so the admin loss vocabulary covers "decided not to proceed"
 * cases on top of the obvious competitive ones. Free-text notes still sit
 * alongside this category so reps can explain the nuance. */
export const TAYLR_LOST_REASON_CATEGORIES = [
  'Decided not to use Taylr',
  'Price / budget',
  'Timing — deferred',
  'Lost to competitor',
  'No response after follow-ups',
  'Out of scope / wrong fit',
  'Decision-maker change',
  'Other',
] as const;
export type TaylrLostReasonCategory = typeof TAYLR_LOST_REASON_CATEGORIES[number];

/**
 * Standard lost-reason categories surfaced in the **strata-portal** Leads
 * UI. Strata almost always lose to another strata company so the vocab is
 * tilted toward *why* the OC picked the rival (price, incumbent inertia,
 * developer ties, etc.) — used in addition to "lost to <competitor>" and
 * free-text notes so the team can spot patterns across losses. */
export const STRATA_LOST_REASON_CATEGORIES = [
  'Price',
  'Incumbent retained',
  'Development relationship',
  'Service offering / scope',
  'Decision-maker preference',
  'Reputation / track record',
  'Timing',
  'Other',
] as const;
export type StrataLostReasonCategory = typeof STRATA_LOST_REASON_CATEGORIES[number];

export interface LostInfo {
  /** Date the lead was marked Prospect Lost (e.g. "02 Apr 2026"). */
  lostDate: string;
  /** Standardised category used for at-a-glance summary chips and any
   *  future loss-pattern reporting. Stored as a string so the same field
   *  can carry either a Taylr or strata category; the consuming UI picks
   *  the appropriate option set. Optional for older records. */
  lostReasonCategory?: TaylrLostReasonCategory | StrataLostReasonCategory;
  /** Free-text reason captured at close — committee vote, declined proposal,
   *  retained incumbent, etc. Sits alongside {@link lostReasonCategory}
   *  to capture the nuance the dropdown can't. */
  lostReason: string;
  /** If lost to another strata company we know about, link to the strata id
   *  so the table can show "lost to <competitor>". */
  lostToStrataId?: string;
  /** Free-text fallback when the competitor isn't a partner strata in the
   *  system (e.g. "self-managed", "Smartlock", an unknown rival). */
  lostToOther?: string;
  /** When the incumbent's management agreement is expected to expire — the
   *  re-engagement window opens a few months before this date. */
  incumbentAgreementExpiry?: string;
  /** Date to surface this lead again for re-pitching. Auto-suggested as ~3
   *  months prior to {@link incumbentAgreementExpiry} but always editable. */
  followUpDate?: string;
  /** Optional notes for the BD/strata picking up the follow-up. */
  followUpNotes?: string;
}

export interface Building {
  id: string;
  slug: string;
  name: string;
  address: string;
  suburb: string;
  upNumber: string;
  stage: BuildingStage;
  registrationDate?: string;
  establishedDate?: string;
  dateCreated: string;
  creationMethod: CreationMethod;
  historyNotes?: string;
  state: string;
  strataId: string;
  services: string[];
  unitIds: string[];
  totalUnits: number;
  manager: { name: string; email: string };
  agreementStart: string;
  agreementTerm: string;
  relationshipStatus: RelationshipStatus;
  enabled: boolean;
  previousStrata?: string;
  taylrAgreement: BuildingAgreement | null;
  contacts: BuildingContact[];
  buildingManager?: OnSitePersonnel;
  concierge?: OnSitePersonnel;
  developer?: Developer;
  leadInfo?: LeadInfo;
  /** Where this lead came from. Set when relationship is in a lead status; may
   *  also be set retrospectively on Won/Lost records to preserve the story. */
  leadSource?: BuildingLeadSource;
  /** Strata-portal lead source — how the strata first got onto this building.
   *  Only shown in the strata portal view. Independent of {@link leadSource}
   *  which is Taylr's internal classification. */
  strataLeadSource?: StrataLeadSource;
  origin?: BuildingOrigin;
  /**
   * When true AND the building also has a partner strata, the building is treated as
   * BOTH partner-sourced and Taylr-direct (overlap). Tab counts in Leads/Buildings
   * may legitimately exceed the All count when these are present.
   */
  taylrDirectAlso?: boolean;
  /** Taylr proposal lifecycle attached to this building's strata sales cycle.
   *  When undefined the proposal is treated as 'Not Started' with the
   *  requirement derived from totalUnits (see getProposalRequirement). */
  taylrProposal?: TaylrProposal;
  /** Closure context when a lead is marked Prospect Lost. Captures *why* the
   *  lead was lost, *who* it was lost to (often a competitor strata), and —
   *  critically — when to re-engage. Strata partners commonly lose tenders
   *  to incumbents whose mgmt agreement still has 12-24 months to run; the
   *  follow-up date lets the team queue a re-pitch a few months before
   *  that incumbent agreement expires. */
  lostInfo?: LostInfo;
  /** Contracted annual strata management fee per unit (AUD) once the building
   *  is under management. Set when the OC signs the strata agreement — by the
   *  time a building reaches the Buildings module the figure should be locked
   *  per the agreement. NOTE: this is the strata company's revenue, not
   *  Taylr's; the strata's annual mgmt fee is `agreedFeePerUnitPerAnnum × totalUnits`. */
  agreedFeePerUnitPerAnnum?: number;
  /** Annual platform licence fee Taylr charges the OC for this building, in
   *  AUD. Optional override — defaults to {@link TAYLR_DEFAULT_ANNUAL_PLATFORM_FEE}. */
  taylrPlatformFeePerAnnum?: number;
  /** Whether the building has (or has been proposed) a Taylr-managed parcel
   *  locker. Drives whether the annual locker service fee is included in
   *  Taylr's opportunity calc. When undefined, presence of a proposal pricing
   *  snapshot is used as a fallback signal. */
  hasParcelLocker?: boolean;
}

// ---------------------------------------------------------------------------
// Taylr agreement helpers — single source of truth for the "t" badge logic.
// The badge is data-driven from the agreement: it shows when there is a
// taylrAgreement record marked Active AND its expiry date has not yet passed.
// ---------------------------------------------------------------------------

const _DATE_MONTHS: Record<string, number> = {
  Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
  Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11,
};

/** Parses "DD MMM YYYY" (e.g., "17 May 2028") to Date. Returns null on failure. */
export function parseAgreementDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  const parts = dateStr.trim().split(/\s+/);
  if (parts.length !== 3) return null;
  const month = _DATE_MONTHS[parts[1]];
  if (month === undefined) return null;
  const day = parseInt(parts[0], 10);
  const year = parseInt(parts[2], 10);
  if (Number.isNaN(day) || Number.isNaN(year)) return null;
  return new Date(year, month, day);
}

/** Returns true if the supplied agreement expiry date has passed. */
export function isAgreementExpired(expiryDate: string): boolean {
  const d = parseAgreementDate(expiryDate);
  if (!d) return false;
  return d.getTime() < Date.now();
}

/**
 * Returns true if the building currently has an active Taylr agreement.
 * Combines the data field (`status === 'Active'`) with a live date check
 * (expiry not yet reached) so the badge updates dynamically as time passes
 * even if seed data was not updated.
 */
export function hasActiveTaylrAgreement(b: Building): boolean {
  const a = b.taylrAgreement;
  if (!a) return false;
  if (a.status !== 'Active') return false;
  return !isAgreementExpired(a.expiryDate);
}

/**
 * Strata Management Agreement state — derived live from `agreementStart`,
 * `agreementTerm`, `relationshipStatus` and `enabled`. Used by the Buildings
 * table, drawer, and BuildingDetail card so all three surfaces show the same
 * dynamic status (no hard-coded "Active").
 *
 * Status meanings:
 *   - `none`        → no agreement on file (`agreementStart` empty)
 *   - `active`      → agreement on file, expiry in the future, building still
 *                     in a live relationship
 *   - `expired`     → agreement's calculated expiry is in the past
 *   - `terminated`  → relationship was ended early (Expired Lost / disabled
 *                     before expiry). We treat a disabled building or one
 *                     whose relationship is `Expired Lost` as no longer under
 *                     management even if the term hasn't run out yet.
 */
export type StrataAgreementStatus = 'none' | 'active' | 'expired' | 'terminated';

export interface StrataAgreementState {
  status: StrataAgreementStatus;
  /** Short label suitable for a badge/pill. */
  label: string;
  /** Calculated expiry date if both start + term parse cleanly. */
  expiryDate: Date | null;
  /** Pre-formatted expiry, e.g. "15 Feb 2026". */
  expiryLabel: string | null;
  /** Hover tooltip describing the full agreement window + state. */
  tooltip: string;
}

const _MONTH_ABBR = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function _formatAgreementDate(d: Date): string {
  return `${d.getDate()} ${_MONTH_ABBR[d.getMonth()]} ${d.getFullYear()}`;
}

export function getStrataAgreementState(b: Building): StrataAgreementState {
  if (!b.agreementStart) {
    return { status: 'none', label: '—', expiryDate: null, expiryLabel: null, tooltip: 'No strata management agreement on file.' };
  }

  const start = parseAgreementDate(b.agreementStart);
  const monthsMatch = b.agreementTerm?.match(/(\d+)\s*(year|month)/i);
  let expiry: Date | null = null;
  let expiryLabel: string | null = null;
  if (start && monthsMatch) {
    const n = parseInt(monthsMatch[1], 10);
    const months = /year/i.test(monthsMatch[2]) ? n * 12 : n;
    expiry = new Date(start.getFullYear(), start.getMonth() + months, start.getDate());
    expiryLabel = _formatAgreementDate(expiry);
  }

  const isOffboarded = b.relationshipStatus === 'Expired Lost' || b.enabled === false;
  const isExpired = expiry ? expiry.getTime() < Date.now() : false;

  // "Terminated" wins over "Expired" only when the relationship was ended
  // BEFORE the natural expiry. Past the expiry date we just call it Expired.
  if (isOffboarded && !isExpired) {
    return {
      status: 'terminated',
      label: 'Terminated',
      expiryDate: expiry,
      expiryLabel,
      tooltip: `Strata management agreement (${b.agreementStart}${b.agreementTerm ? ` · ${b.agreementTerm}` : ''}) terminated early — building offboarded.`,
    };
  }

  if (isExpired) {
    return {
      status: 'expired',
      label: expiryLabel ? `Expired ${expiryLabel}` : 'Expired',
      expiryDate: expiry,
      expiryLabel,
      tooltip: `Strata management agreement expired${expiryLabel ? ` on ${expiryLabel}` : ''}.`,
    };
  }

  return {
    status: 'active',
    label: 'Active',
    expiryDate: expiry,
    expiryLabel,
    tooltip: `Strata management agreement: ${b.agreementStart}${expiryLabel ? ` → ${expiryLabel}` : ''}${b.agreementTerm ? ` (${b.agreementTerm})` : ''}.`,
  };
}

// ---------------------------------------------------------------------------
// Opportunity-size helpers
// ---------------------------------------------------------------------------
// IMPORTANT: "Opportunity" here is **Taylr's** annual revenue from a building,
// NOT the strata company's. The strata charges its own per-unit management
// fee to the OC — that's the strata's revenue, modelled on
// `leadInfo.feePerUnitPerAnnum` / `agreedFeePerUnitPerAnnum` and surfaced
// separately as `strataAnnualMgmtFee` for context only.
//
// Taylr's revenue model is:
//   1. **Platform licence fee** — a flat annual licence Taylr charges the OC
//      for access to the platform itself. Always applies.
//   2. **Parcel locker service fee** — only for buildings that have (or will
//      have) a Taylr-managed parcel locker. Derived from the proposal pricing
//      snapshot's `monthlyTotal × 12` (or computed from current params if no
//      snapshot yet exists).
//
// Annual opportunity = platform fee + (hasLocker ? annual locker fee : 0).
// ---------------------------------------------------------------------------

/** Default annual platform licence fee Taylr charges the OC, in AUD. Per-
 *  building overrides via `building.taylrPlatformFeePerAnnum`. Editable in
 *  Finance → Pricing. */
export const TAYLR_DEFAULT_ANNUAL_PLATFORM_FEE = 1800;

// ---------------------------------------------------------------------------
// Stage-driven win-probability — single source of truth.
// ---------------------------------------------------------------------------
// Probability is *derived from the relationship status* (the pipeline stage)
// using standard B2B sales-funnel benchmarks. Lead records may carry a
// historical `probability` field; that value is now display-deprecated and
// callers should prefer `getStageProbability(b.relationshipStatus)`.
// ---------------------------------------------------------------------------

export function getStageProbability(status: RelationshipStatus): number {
  switch (status) {
    case 'Unassigned':         return 5;   // Raw / not yet triaged
    case 'New Lead':           return 10;  // Qualification
    case 'Taylr Prospect':     return 25;  // Taylr-direct, early discovery
    case 'Preparing Proposal': return 40;  // Needs analysis / proposal in flight
    case 'Strata Prospect':    return 45;  // Strata partner pursuing the OC
    case 'Proposal Out':       return 60;  // Proposal sent, awaiting OC decision
    case 'Contracts Out':      return 85;  // Verbal yes — contracts in negotiation
    case 'Won':                return 100;
    case 'Prospect Lost':
    case 'Expired Lost':
    case 'Agreement Expired':  return 0;
  }
}

export interface ProbabilityClasses {
  /** Tailwind text colour for the percentage value. */
  text: string;
  /** Tailwind background colour for a subtle pill/chip backdrop. */
  pillBg: string;
  /** Tailwind background colour for the progress-bar fill. */
  bar: string;
}

/** Maps a probability (0–100) to a colour band so the value reads as a quick
 *  health signal: red (cold) → amber → blue → green (hot) → emerald (won). */
export function getProbabilityClasses(p: number): ProbabilityClasses {
  if (p >= 100) return { text: 'text-emerald-700', pillBg: 'bg-emerald-50', bar: 'bg-emerald-500' };
  if (p >= 75)  return { text: 'text-emerald-600', pillBg: 'bg-emerald-50', bar: 'bg-emerald-500' };
  if (p >= 50)  return { text: 'text-blue-600',    pillBg: 'bg-blue-50',    bar: 'bg-blue-500' };
  if (p >= 25)  return { text: 'text-amber-600',   pillBg: 'bg-amber-50',   bar: 'bg-amber-500' };
  if (p > 0)    return { text: 'text-orange-600',  pillBg: 'bg-orange-50',  bar: 'bg-orange-500' };
  return         { text: 'text-gray-400',          pillBg: 'bg-gray-50',    bar: 'bg-gray-300' };
}

export interface OpportunitySize {
  // ---- Taylr revenue (the actual "opportunity") -----------------------
  /** Annual platform licence fee Taylr charges the OC. */
  annualPlatformFee: number;
  /** True if the building has (or has proposed) a Taylr parcel locker. */
  hasParcelLocker: boolean;
  /** Annual locker service fee — 0 when `hasParcelLocker` is false. */
  annualLockerServiceFee: number;
  /** AUD per year — `annualPlatformFee + annualLockerServiceFee`. */
  annualValue: number;
  /** True once the underlying figures are locked via signed agreement. */
  isAgreed: boolean;

  // ---- Strata company context (NOT Taylr revenue) --------------------
  totalUnits: number;
  /** Strata's per-unit management fee — what they charge the OC. Context
   *  only; not part of Taylr's opportunity. `null` if not set yet. */
  strataFeePerUnit: number | null;
  /** Strata's annual mgmt fee = strataFeePerUnit × totalUnits. Null if
   *  per-unit fee is not set. */
  strataAnnualMgmtFee: number | null;

  /** @deprecated Kept as an alias for `strataFeePerUnit` during the rename
   *  of "opportunity" semantics — call sites still using this for context
   *  display continue to work. */
  feePerUnitPerAnnum: number | null;
}

export function getOpportunitySize(b: Building): OpportunitySize {
  // ---- Strata's per-unit fee (context) -------------------------------
  // Lifecycle-aware: while the building is still in the lead pipeline the
  // anticipated figure on `leadInfo.feePerUnitPerAnnum` is canonical. Once
  // the building has converted (Won, Expired Lost, etc.) the contracted
  // figure on `agreedFeePerUnitPerAnnum` is canonical and we don't fall
  // back to the anticipated number.
  const agreed = typeof b.agreedFeePerUnitPerAnnum === 'number' ? b.agreedFeePerUnitPerAnnum : null;
  const anticipated = typeof b.leadInfo?.feePerUnitPerAnnum === 'number' ? b.leadInfo!.feePerUnitPerAnnum : null;
  const inLeadPipeline = isLead(b.relationshipStatus);
  const strataFeePerUnit = inLeadPipeline ? anticipated : agreed;

  // ---- Taylr revenue --------------------------------------------------
  const annualPlatformFee = typeof b.taylrPlatformFeePerAnnum === 'number'
    ? b.taylrPlatformFeePerAnnum
    : TAYLR_DEFAULT_ANNUAL_PLATFORM_FEE;

  // Locker presence: explicit flag wins; otherwise infer from any proposal
  // pricing snapshot (the upload itself implies the OC is being offered a
  // locker). Falls through to `false` for buildings with no locker context.
  const hasParcelLocker = typeof b.hasParcelLocker === 'boolean'
    ? b.hasParcelLocker
    : !!getEffectiveProposal(b)?.pricingSnapshot;

  // Annual locker fee: prefer the frozen proposal snapshot so the figure
  // matches what's been quoted; otherwise compute a live estimate from
  // current pricing params. Uses the effective proposal so in-session
  // uploads/edits via setProposalOverride are reflected immediately.
  let annualLockerServiceFee = 0;
  if (hasParcelLocker) {
    const eff = getEffectiveProposal(b);
    if (eff?.pricingSnapshot) {
      annualLockerServiceFee = +(eff.pricingSnapshot.monthlyTotal * 12).toFixed(2);
    } else {
      const live = computeProposalPricing(b);
      annualLockerServiceFee = +(live.monthlyTotal * 12).toFixed(2);
    }
  }

  const annualValue = +(annualPlatformFee + annualLockerServiceFee).toFixed(2);

  return {
    annualPlatformFee,
    hasParcelLocker,
    annualLockerServiceFee,
    annualValue,
    isAgreed: !inLeadPipeline && agreed !== null,
    totalUnits: b.totalUnits,
    strataFeePerUnit,
    strataAnnualMgmtFee: strataFeePerUnit !== null ? strataFeePerUnit * b.totalUnits : null,
    feePerUnitPerAnnum: strataFeePerUnit,
  };
}

/** Compact AUD formatter — "$48,000". For larger figures uses "k"/"m" suffixes
 *  so dashboard tiles stay readable. */
export function formatAud(amount: number | null | undefined, opts: { compact?: boolean } = {}): string {
  if (amount === null || amount === undefined) return '—';
  if (opts.compact) {
    if (amount >= 1_000_000) return `$${(amount / 1_000_000).toFixed(amount >= 10_000_000 ? 0 : 1)}m`;
    if (amount >= 1_000) return `$${(amount / 1_000).toFixed(amount >= 10_000 ? 0 : 1)}k`;
    return `$${amount.toFixed(0)}`;
  }
  return `$${amount.toLocaleString('en-AU', { maximumFractionDigits: 0 })}`;
}

/** Look up a strata-side user (for `leadInfo.strataOwnerId`). */
export function getStrataUserById(strataId: string | undefined, userId: string | undefined): StrataUser | undefined {
  if (!strataId || !userId) return undefined;
  const s = strataCompanies.find(sc => sc.id === strataId);
  return s?.users.find(u => u.id === userId);
}

// ---------------------------------------------------------------------------
// Taylr team (Taylr-side admin / BD users)
// ---------------------------------------------------------------------------
// These are the only people who can legitimately appear as the "Taylr Owner"
// of a lead inside the Taylr admin app. Strata partner staff (e.g. Vantage,
// Bridges) must NEVER be surfaced as a Taylr Owner — they have their own
// `strataOwnerId` slot for that.

export interface TaylrTeamMember {
  id: string;
  name: string;
  role: string;
  email: string;
}

export const taylrTeam: TaylrTeamMember[] = [
  { id: 't-bd-001',    name: 'Sam Weiland',    role: 'Senior BD Manager', email: 'sam.weiland@taylr.com.au' },
  { id: 't-bd-002',    name: 'Priya Naidu',    role: 'BD Manager',        email: 'priya.naidu@taylr.com.au' },
  { id: 't-admin-001', name: 'Jordan Kim',     role: 'Onboarding Lead',   email: 'jordan.kim@taylr.com.au' },
];

/** Look up a Taylr team member (for `leadInfo.taylrOwnerId`). */
export function getTaylrUserById(userId: string | undefined): TaylrTeamMember | undefined {
  if (!userId) return undefined;
  return taylrTeam.find(u => u.id === userId);
}

/** A building is partner-sourced if its strata is a Taylr partner. */
export function isBuildingPartnerSourced(b: Building): boolean {
  const s = strataCompanies.find(sc => sc.id === b.strataId);
  return s?.isPartner === true;
}

/**
 * A building is Taylr-direct if it has no partner strata (so Taylr is the only
 * party pursuing) OR it is explicitly flagged as also being pursued direct
 * alongside a partner relationship.
 */
export function isBuildingTaylrDirect(b: Building): boolean {
  if (!isBuildingPartnerSourced(b)) return true;
  return b.taylrDirectAlso === true;
}

export function getStageBadgeClasses(stage: BuildingStage): string {
  switch (stage) {
    case 'Development': return 'bg-orange-50 text-orange-700 border border-orange-200';
    case 'Pre-Settlement': return 'bg-amber-50 text-amber-700 border border-amber-200';
    case 'Registered': return 'bg-blue-50 text-blue-700 border border-blue-200';
    case 'Established': return 'bg-emerald-50 text-emerald-700 border border-emerald-200';
  }
}

export interface Unit {
  id: string;
  name: string;
  lot: string;
  floor: number;
  buildingId: string;
  tenancyStatus: 'Active' | 'Owner Occupied' | 'Vacant' | 'Expired' | 'Ended' | 'Missing Tenancy' | 'Unknown' | 'Not Applicable';
  leaseStart?: string;
  leaseEnd?: string;
  ownerGroupId?: string;
  agentCompanyId?: string;
  s119Status: string;
  unitAddress?: string;
  doorNumber?: number;
  streetNumber?: number;
  streetName?: string;
  hasAC?: boolean;
  acType?: string;
  acManufacturer?: string;
}

export interface UnitStatus {
  unitId: string;
  role: string;
  confirmed: boolean;
  authorisedInCard: boolean;
  hasMovedIn?: boolean;
  archived?: boolean;
  archivedDate?: string;
  archivedReason?: string;
  archivedOcId?: string;
}

export interface Member {
  id: string;
  name: string;
  email: string;
  phone?: string;
  verified: boolean;
  taylrActive: boolean;
  leadSource?: LeadSource;
  units: UnitStatus[];
}

export type LeadSource =
  | 'Strata Onboarding'
  | 'FYU Link'
  | 'Parcel QR'
  | 'Agent Intro'
  | 'Owner Intro'
  | 'Tenant Intro'
  | 'Unassigned Intro'
  | 'External'
  | 'Manual';

export const LEAD_SOURCES_BY_ROLE: Record<string, LeadSource[]> = {
  'Owner Occupier':    ['Strata Onboarding', 'FYU Link', 'Parcel QR', 'Owner Intro', 'Unassigned Intro', 'External'],
  'Offsite Investor':  ['Strata Onboarding', 'FYU Link', 'Parcel QR', 'Owner Intro', 'Unassigned Intro', 'External'],
  'Owner':             ['Strata Onboarding', 'FYU Link', 'Parcel QR', 'Owner Intro', 'Unassigned Intro', 'External'],
  'Tenant':            ['Strata Onboarding', 'FYU Link', 'Parcel QR', 'Agent Intro', 'Owner Intro', 'External'],
  'Household Member':  ['FYU Link', 'Parcel QR', 'Tenant Intro', 'Owner Intro', 'External'],
};

const MEMBER_ROLES = ['Owner', 'Owner Occupier', 'Offsite Investor', 'Offsite Owner', 'Tenant', 'Household Member'];

export function isMemberRole(role: string): boolean {
  return MEMBER_ROLES.some(r => role.includes(r));
}

export const strataCompanies: StrataCompany[] = [
  {
    id: 'strata-001',
    name: 'Vantage Strata',
    abn: '61 004 206 120',
    isPartner: true,
    address: '12 Moore St, Canberra ACT 2601',
    phone: '02 6100 3200',
    email: 'admin@vantagestrata.com.au',
    agreementStart: '17 May 2025',
    agreementTerm: '36 months',
    piqSyncEnabled: true,
    lastPiqSync: '24 Mar 2026 08:15am',
    servicesEnabled: ['S119 Rental', 'Communications'],
    buildingIds: ['building-001', 'building-003', 'building-007', 'building-008'],
    contacts: [
      {
        name: 'Alyssa Monaghan',
        role: 'Strata Manager',
        email: 'alyssa.monaghan@vantagestrata.com.au',
        buildings: ['The Parks - Stage 2'],
      },
    ],
    users: [
      { id: 'su-001-alyssa', name: 'Alyssa Monaghan', role: 'Senior Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au' },
      { id: 'su-001-jordan', name: 'Jordan Pereira',  role: 'Business Development',  email: 'jordan.pereira@vantagestrata.com.au' },
      { id: 'su-001-marie',  name: 'Marie Tan',       role: 'Strata Manager',        email: 'marie.tan@vantagestrata.com.au' },
    ],
    // Vantage Strata brand colour — sampled from vantagestrata.com.au.
    // Editable in the admin → Strata → Branding card; persisted via
    // StrataBrandingContext (localStorage-backed for the prototype).
    brand: {
      primaryColor: '#F47B20',
      initials: 'VS',
      displayName: 'Vantage',
    },
  },
  {
    id: 'strata-002',
    name: 'Bridges Strata Group',
    abn: '82 114 321 908',
    isPartner: false,
    address: '44 Northbourne Ave, Canberra ACT 2600',
    phone: '02 6234 1100',
    email: 'admin@bridgesstrata.com.au',
    agreementStart: '',
    agreementTerm: '',
    piqSyncEnabled: false,
    lastPiqSync: '',
    servicesEnabled: [],
    buildingIds: ['building-005'],
    contacts: [],
    users: [
      { id: 'su-002-rachel', name: 'Rachel Ng',     role: 'Strata Manager',        email: 'rachel.ng@bridgesstrata.com.au' },
      { id: 'su-002-sam',    name: 'Sam Whitfield', role: 'Senior Strata Manager', email: 'sam.whitfield@bridgesstrata.com.au' },
    ],
  },
];

export const agentCompanies: AgentCompany[] = [
  {
    id: 'agent-001',
    name: 'Ray White Canberra',
    email: 'hello@raywhite-cbr.com.au',
    phone: '02 6100 9400',
  },
];

export const buildings: Building[] = [
  {
    id: 'building-001',
    slug: 'the-parks-stage-2',
    name: 'The Parks - Stage 2',
    address: '2-6 Lady Nelson Place, Red Hill ACT 2603',
    suburb: 'Red Hill',
    upNumber: 'UP15853',
    stage: 'Established',
    registrationDate: '17 May 2023',
    establishedDate: '15 Apr 2024',
    dateCreated: '15 Nov 2025',
    creationMethod: 'PIQ Sync',
    agreedFeePerUnitPerAnnum: 540,
    hasParcelLocker: true,
    historyNotes: 'Imported via Vantage Strata PIQ integration.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding', 'S119 Rental'],
    unitIds: Array.from({ length: 68 }, (_, i) => `unit-${String(i + 1).padStart(3, '0')}`),
    totalUnits: 68,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '17 May 2025',
    agreementTerm: '36 months',
    relationshipStatus: 'Won',
    enabled: true,
    taylrDirectAlso: true,
    taylrAgreement: { startDate: '17 May 2025', durationYears: 3, expiryDate: '17 May 2028', status: 'Active' },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '15 Nov 2025',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Brought to Taylr by Vantage Strata via the PIQ sync. Following onboarding, the Owners Corporation also signed a parallel direct Taylr agreement on 17 May 2025 — making this both partner-sourced and Taylr-direct.',
    },
  },
  {
    id: 'building-002',
    slug: 'kingston-foreshore-lead',
    name: 'Kingston Foreshore Residences',
    address: '12 Trevillian Quay, Kingston ACT 2604',
    suburb: 'Kingston',
    upNumber: 'UP12470',
    stage: 'Established',
    registrationDate: '04 Mar 2019',
    establishedDate: '04 Jun 2019',
    dateCreated: '02 Apr 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Added by Vantage Strata as a prospect lead — incumbent strata currently servicing building.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 142,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'New Lead',
    enabled: false,
    taylrAgreement: null,
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    leadInfo: {
      estimatedConversionDate: 'Aug 2026',
      probability: 60,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 450,
      nextAction: 'Follow up with committee chair re: Q3 AGM proposal',
      nextActionDate: '24 Apr 2026',
      activity: [
        { id: 'la-002-1', date: '02 Apr 2026', type: 'Note', author: 'Alyssa Monaghan', content: 'Lead created. Vantage flagged building as a target — incumbent strata contract up for review at next AGM (Q3 2026).' },
        { id: 'la-002-2', date: '08 Apr 2026', type: 'Email', author: 'Alyssa Monaghan', content: 'Sent intro pack to OC chair. Awaiting response.' },
        { id: 'la-002-3', date: '14 Apr 2026', type: 'Call', author: 'Taylr BD', content: 'Spoke with chair. Interested in Taylr platform demo. Booked for 18 Apr.' },
        { id: 'la-002-4', date: '18 Apr 2026', type: 'Meeting', author: 'Taylr BD', content: 'Demo well received. Committee wants written proposal before AGM.' },
        { id: 'la-002-5', date: '24 Apr 2026', type: 'Reminder', author: 'Alyssa Monaghan', content: 'Follow up with committee chair re: Q3 AGM proposal.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Inbound webform',
    origin: {
      source: 'Lead Conversion',
      date: '02 Apr 2026',
      addedBy: 'Alyssa Monaghan (Vantage Strata)',
      notes: 'Vantage Strata requested a Taylr proposal on behalf of the OC ahead of the Q3 2026 AGM — pending Taylr drafting. Once loaded, the proposal will be available to Vantage via their partner portal.',
    },
  },
  {
    // Pending Proposal lead with Taylr-direct overlap: Vantage requested a
    // proposal on behalf of the OC, AND Taylr BD has been independently
    // engaging the developer. Surfaces in BOTH Partner-Leads and Taylr-Leads.
    id: 'building-010',
    slug: 'altitude-greenway-lead',
    name: 'Altitude Apartments',
    address: '28 Anketell St, Greenway ACT 2900',
    suburb: 'Greenway',
    upNumber: 'UP14782',
    stage: 'Established',
    registrationDate: '18 Sep 2020',
    establishedDate: '18 Dec 2020',
    dateCreated: '11 Apr 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Vantage requested a Taylr proposal on behalf of the OC; Taylr BD already in early conversations with the building.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 186,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Preparing Proposal',
    enabled: false,
    taylrAgreement: null,
    taylrDirectAlso: true,
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
      { name: 'Daniel Pham', role: 'OC Chair', email: 'd.pham@altitudegreenway.org.au', phone: '0411 220 884' },
    ],
    leadInfo: {
      estimatedConversionDate: 'Sep 2026',
      probability: 70,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 450,
      nextAction: 'Draft proposal pack and send to Vantage for OC distribution',
      nextActionDate: '22 Apr 2026',
      activity: [
        { id: 'la-010-1', date: '24 Mar 2026', type: 'Call', author: 'Taylr BD', content: 'Cold-called OC chair Daniel Pham. Building has had ongoing parcel-theft issues; chair receptive to a demo.' },
        { id: 'la-010-2', date: '02 Apr 2026', type: 'Meeting', author: 'Taylr BD', content: 'On-site walk-through with chair. Identified loading-bay alcove as candidate locker location. Chair asked us to coordinate via Vantage.' },
        { id: 'la-010-3', date: '11 Apr 2026', type: 'Email', author: 'Alyssa Monaghan', content: 'Vantage formally requested a Taylr proposal on behalf of Altitude OC — referenced our prior site visit. Lead landed at New Lead and Taylr BD has now picked it up — status moved to Preparing Proposal.' },
        { id: 'la-010-4', date: '22 Apr 2026', type: 'Reminder', author: 'Taylr BD', content: 'Finish proposal pack (pricing + locker layout) and load to portal for Vantage to forward to OC.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Developer',
    origin: {
      source: 'Lead Conversion',
      date: '24 Mar 2026',
      addedBy: 'Taylr BD',
      notes: 'Originally a Taylr-direct outreach to the OC chair following parcel-theft incidents reported in the building Facebook group. After a productive on-site visit on 02 Apr, the chair asked us to formalise via Vantage Strata; Vantage submitted a proposal request on 11 Apr. Now jointly pursued — Taylr to draft, Vantage to distribute to the OC.',
    },
    taylrProposal: {
      status: 'Not Started',
      requirement: 'Qualifies',
      followUps: [],
      notes: '186 units — qualifies for a proposal. Drafting kicked off after Vantage formalised the request 11 Apr. Use the auto-generator once locker layout is locked.',
    },
  },
  {
    // Proposal Out demo: partner-referred lead where Taylr has already drafted
    // and loaded the proposal into Vantage's partner portal. Status now sits at
    // 'Proposal Out', triggering the follow-up cadence (3-day, 7-day, 14-day
    // chases). Useful for showcasing how triggers/reminders fire after issue.
    id: 'building-011',
    slug: 'mort-and-co-braddon-lead',
    name: 'Mort & Co Apartments',
    address: '19 Mort St, Braddon ACT 2612',
    suburb: 'Braddon',
    upNumber: 'UP14210',
    stage: 'Established',
    registrationDate: '12 Jul 2018',
    establishedDate: '04 Oct 2018',
    dateCreated: '20 Mar 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Vantage requested a proposal on behalf of OC; Taylr drafted and loaded to portal on 09 Apr. Awaiting OC response — automated follow-up cadence active.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 96,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Proposal Out',
    enabled: false,
    taylrAgreement: null,
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
      { name: 'Hannah Voss', role: 'OC Chair', email: 'h.voss@mortandco.org.au', phone: '0422 110 763' },
    ],
    leadInfo: {
      estimatedConversionDate: 'Jul 2026',
      probability: 55,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 450,
      nextAction: 'Auto follow-up #2 fires — chase OC chair for proposal response',
      nextActionDate: '23 Apr 2026',
      activity: [
        { id: 'la-011-1', date: '20 Mar 2026', type: 'Note',     author: 'Alyssa Monaghan', content: 'Lead created. Vantage requested a Taylr proposal on behalf of Mort & Co OC ahead of the May 2026 committee meeting. Status: New Lead.' },
        { id: 'la-011-2', date: '24 Mar 2026', type: 'Email',    author: 'Taylr BD',         content: 'Drafting kicked off — locker layout confirmed for ground-floor mailroom. ETA proposal pack within 2 weeks.' },
        { id: 'la-011-3', date: '07 Apr 2026', type: 'Meeting',  author: 'Taylr BD',         content: 'Internal review of proposal pack with pricing team. Approved for issue.' },
        { id: 'la-011-4', date: '09 Apr 2026', type: 'Note',     author: 'Taylr BD',         content: 'Proposal pack loaded into Vantage partner portal — visible to Alyssa for OC distribution. Lead status moved to Proposal Out. Auto follow-up cadence enabled (T+3, T+7, T+14 days).' },
        { id: 'la-011-5', date: '12 Apr 2026', type: 'Email',    author: 'System (auto)',    content: 'Auto follow-up #1 sent (T+3) — reminder to Alyssa Monaghan that the Mort & Co proposal is awaiting OC response. No response logged yet.' },
        { id: 'la-011-6', date: '16 Apr 2026', type: 'Email',    author: 'System (auto)',    content: 'Auto follow-up #2 sent (T+7) — escalation reminder to Alyssa, with cc to OC chair Hannah Voss. Proposal viewed in portal but not actioned.' },
        { id: 'la-011-7', date: '23 Apr 2026', type: 'Reminder', author: 'System (auto)',    content: 'Scheduled: Auto follow-up #3 (T+14) — final automated chase. After this, lead is flagged for manual BD intervention.' },
        { id: 'la-011-8', date: '07 May 2026', type: 'Reminder', author: 'System (auto)',    content: 'Scheduled: Manual escalation to Taylr BD if no response by this date. Suggested action: direct call to OC chair.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Campaign',
    origin: {
      source: 'Lead Conversion',
      date: '20 Mar 2026',
      addedBy: 'Alyssa Monaghan (Vantage Strata)',
      notes: 'Vantage Strata requested a Taylr proposal for the Mort & Co OC ahead of the May 2026 committee meeting. Taylr drafted, internally approved, and uploaded the proposal on 09 Apr 2026 — auto-pushed to Vantage via the strata-lead/portal. The lead moved through New Lead → Preparing Proposal → Proposal Out and the automated follow-up cadence (T+3 / T+7 / T+14) began.',
    },
    taylrProposal: {
      status: 'Sent',
      requirement: 'Qualifies',
      generatedDate: '07 Apr 2026',
      generatedBy: 'Taylr BD (auto-generator)',
      sentDate: '09 Apr 2026',
      sentBy: 'Taylr BD',
      followUps: [
        { id: 'fu-011-1', date: '12 Apr 2026', channel: 'Email',  sender: 'System (auto)',     outcome: 'T+3 reminder sent to Alyssa. No response logged.' },
        { id: 'fu-011-2', date: '16 Apr 2026', channel: 'Email',  sender: 'System (auto)',     outcome: 'T+7 escalation sent (cc OC chair Hannah Voss). Proposal viewed in portal but not actioned.' },
        { id: 'fu-011-3', date: '23 Apr 2026', channel: 'Email',  sender: 'System (auto)',     outcome: 'Scheduled — T+14 final automated chase. Lead flips to manual BD intervention after this if no decision recorded.' },
      ],
      pricingSnapshot: {
        lockerCount: 58,
        monthlyPerLocker: 14.5,
        installPerUnit: 18,
        setupFee: 1450,
        monthlyTotal: 841,
        installTotal: 3178,
        contractMonths: 36,
      },
      notes: 'Awaiting OC decision. Once Hannah responds, record outcome via "Record Decision" — auto follow-ups stop and lifecycle closes.',
    },
  },
  {
    // Pending Proposal demo, partner-portal initiated. Vantage (a Taylr partner)
    // raised the proposal request from inside their portal as part of their own
    // sales cycle — Taylr is now drafting. Flagged taylrDirectAlso so the lead
    // also appears on the Taylr-Leads tab (any in-flight proposal is Taylr work,
    // regardless of who triggered it).
    id: 'building-012',
    slug: 'lakeshore-apartments-belconnen-lead',
    name: 'Lakeshore Apartments',
    address: '5 Emu Bank, Belconnen ACT 2617',
    suburb: 'Belconnen',
    upNumber: 'UP14998',
    stage: 'Established',
    registrationDate: '04 Mar 2017',
    establishedDate: '22 May 2017',
    dateCreated: '13 Apr 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Vantage raised a proposal request from their partner portal on 13 Apr — Taylr drafting in response.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 142,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Preparing Proposal',
    enabled: false,
    taylrAgreement: null,
    taylrDirectAlso: true,
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
      { name: 'Marcus Liang', role: 'OC Chair', email: 'm.liang@lakeshore-belconnen.org.au', phone: '0438 552 117' },
    ],
    leadInfo: {
      estimatedConversionDate: 'Aug 2026',
      probability: 65,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 450,
      nextAction: 'Draft proposal pack (locker layout + pricing) and load to Vantage portal',
      nextActionDate: '24 Apr 2026',
      activity: [
        { id: 'la-012-1', date: '13 Apr 2026', type: 'Note',    author: 'Alyssa Monaghan', content: 'Proposal requested via Vantage partner portal as part of Vantage\'s own building services review for the Lakeshore OC. Lead auto-created on Taylr side at New Lead; Taylr BD picked it up the same day and moved it to Preparing Proposal.' },
        { id: 'la-012-2', date: '14 Apr 2026', type: 'Email',   author: 'Taylr BD',         content: 'Acknowledged request to Alyssa. Requested floor plans + parcel-volume estimate to size locker bank.' },
        { id: 'la-012-3', date: '17 Apr 2026', type: 'Email',   author: 'Alyssa Monaghan', content: 'Floor plans + 12-month parcel intercom logs forwarded. Mailroom is the preferred install location.' },
        { id: 'la-012-4', date: '24 Apr 2026', type: 'Reminder',author: 'Taylr BD',         content: 'Finish proposal pack and load to Vantage partner portal. On issue, status auto-advances to Proposal Out and follow-up cadence (T+3 / T+7 / T+14) begins.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Direct outreach',
    origin: {
      source: 'Partner Portal Request',
      date: '13 Apr 2026',
      addedBy: 'Alyssa Monaghan (Vantage Strata)',
      notes: 'Vantage Strata raised a proposal request for Lakeshore Apartments from their partner portal as part of their own sales cycle with the OC. Lead is currently with Taylr to draft and issue the proposal pack — appears on both Partner-Leads (sourced by Vantage) and Taylr-Leads (Taylr is doing the proposal work) tabs.',
    },
    taylrProposal: {
      status: 'Drafted',
      requirement: 'Qualifies',
      generatedDate: '20 Apr 2026',
      generatedBy: 'Taylr BD (auto-generator)',
      followUps: [],
      notes: 'Generated 20 Apr using current pricing parameters. Held for internal QA before issuing to Vantage portal — once issued, status moves to Sent and follow-up cadence (T+3 / T+7 / T+14) starts automatically.',
      pricingSnapshot: {
        lockerCount: 85,
        monthlyPerLocker: 14.5,
        installPerUnit: 18,
        setupFee: 1450,
        monthlyTotal: 1232.5,
        installTotal: 4006,
        contractMonths: 36,
      },
    },
  },
  {
    // Small-building (<50 units) demo: strata initiated a Taylr proposal request
    // (so the OPTIONAL lifecycle kicked in), Taylr generated and issued it, the
    // OC-developer formally declined, and the strata-lead recorded both the
    // decliner and the reason. Lead status now Prospect Lost; proposal status
    // Declined with full audit trail. Useful for showing lifecycle closure
    // (decision recorded → follow-ups stop) and the developer-decline pattern.
    id: 'building-013',
    slug: 'amaroo-court-tuggeranong-lead',
    name: 'Amaroo Court',
    address: '7 Pitman St, Tuggeranong ACT 2900',
    suburb: 'Tuggeranong',
    upNumber: 'UP12044',
    stage: 'Established',
    registrationDate: '03 Aug 2014',
    establishedDate: '19 Nov 2014',
    dateCreated: '14 Feb 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Bridges Strata requested a Taylr proposal for Amaroo Court (32 units) — issued 28 Feb. OC-developer declined 19 Mar citing existing parcel-management contract.',
    state: 'ACT',
    strataId: 'strata-002',
    services: [],
    unitIds: [],
    totalUnits: 32,
    manager: { name: 'Daniel Hughes', email: 'dhughes@bridgesstrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Prospect Lost',
    enabled: false,
    taylrAgreement: null,
    contacts: [
      { name: 'Daniel Hughes', role: 'Strata Manager', email: 'dhughes@bridgesstrata.com.au', phone: '02 6234 1100' },
      { name: 'Helena Brooks', role: 'Developer (Brookswood Properties)', email: 'h.brooks@brookswood.com.au', phone: '0411 720 998' },
    ],
    leadInfo: {
      estimatedConversionDate: '',
      probability: 0,
      taylrOwnerId: 't-bd-002',
      strataOwnerId: 'su-002-rachel',
      feePerUnitPerAnnum: 380,
      nextAction: '',
      nextActionDate: '',
      activity: [
        { id: 'la-013-1', date: '14 Feb 2026', type: 'Email',   author: 'Daniel Hughes', content: 'Bridges requested a Taylr proposal on behalf of the Amaroo Court OC. Building has 32 units — proposal optional but the partner asked for one.' },
        { id: 'la-013-2', date: '28 Feb 2026', type: 'Email',   author: 'Taylr BD',       content: 'Proposal generated via auto-generator and emailed to Daniel for OC distribution. Status: Sent. Auto follow-up cadence enabled.' },
        { id: 'la-013-3', date: '03 Mar 2026', type: 'Email',   author: 'System (auto)',  content: 'T+3 reminder sent to Daniel. No response logged.' },
        { id: 'la-013-4', date: '07 Mar 2026', type: 'Email',   author: 'System (auto)',  content: 'T+7 escalation sent to Daniel + cc Helena Brooks (developer).' },
        { id: 'la-013-5', date: '19 Mar 2026', type: 'Note',    author: 'Daniel Hughes', content: 'Decision recorded: DECLINED by Helena Brooks (Developer, Brookswood Properties). Reason: Brookswood holds an existing parcel-management contract with Smartlock until Apr 2027 — declined to switch providers mid-term. Will revisit at contract renewal.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Inbound webform',
    origin: {
      source: 'Lead Conversion',
      date: '14 Feb 2026',
      addedBy: 'Daniel Hughes (Bridges Strata)',
      notes: 'Bridges Strata requested a Taylr proposal for Amaroo Court as part of their building-services review (32 units, sub-threshold but partner-asked). Proposal issued 28 Feb, declined 19 Mar by the OC-developer. Decline reason recorded — lead moved to Prospect Lost. Diary set to revisit at developer contract renewal (Apr 2027).',
    },
    lostInfo: {
      lostDate: '19 Mar 2026',
      lostReasonCategory: 'Lost to competitor',
      lostReason: 'Developer declined — OC retained existing parcel-management contract with Smartlock (in-term until Apr 2027).',
      lostToOther: 'Smartlock (incumbent parcel provider)',
      incumbentAgreementExpiry: '01 Apr 2027',
      followUpDate: '01 Jan 2027',
      followUpNotes: 'Re-pitch ~3 months before Smartlock contract renewal. Loop in Helena Brooks (Brookswood Properties) early.',
    },
    taylrProposal: {
      status: 'Declined',
      requirement: 'Qualifies',
      generatedDate: '27 Feb 2026',
      generatedBy: 'Taylr BD (auto-generator)',
      sentDate: '28 Feb 2026',
      sentBy: 'Daniel Hughes (Bridges Strata)',
      decisionDate: '19 Mar 2026',
      declinedBy: { name: 'Helena Brooks', role: 'Developer (Brookswood Properties)' },
      declineReason: 'Brookswood Properties (the OC developer) holds an existing parcel-management contract with Smartlock until Apr 2027. Declined to switch providers mid-term. Diary set to revisit at contract renewal.',
      followUps: [
        { id: 'fu-013-1', date: '03 Mar 2026', channel: 'Email', sender: 'System (auto)', outcome: 'T+3 reminder to Daniel — no response.' },
        { id: 'fu-013-2', date: '07 Mar 2026', channel: 'Email', sender: 'System (auto)', outcome: 'T+7 escalation, cc Helena Brooks — opened, not actioned.' },
        { id: 'fu-013-3', date: '14 Mar 2026', channel: 'Call',  sender: 'Daniel Hughes (Bridges)', outcome: 'Daniel called Helena directly — flagged the existing Smartlock contract; promised written response within 5 days.' },
      ],
      pricingSnapshot: {
        lockerCount: 19,
        monthlyPerLocker: 14.5,
        installPerUnit: 18,
        setupFee: 1450,
        monthlyTotal: 275.5,
        installTotal: 2026,
        contractMonths: 36,
      },
      notes: 'Lifecycle closed 19 Mar 2026 — decision recorded with decliner + reason. Auto follow-ups stopped. Marked for revisit at Apr 2027 developer contract renewal.',
    },
  },
  {
    id: 'building-003',
    slug: 'braddon-commons',
    name: 'Braddon Commons',
    address: '88 Lonsdale St, Braddon ACT 2612',
    suburb: 'Braddon',
    upNumber: '',
    stage: 'Pre-Settlement',
    registrationDate: '12 Feb 2026',
    dateCreated: '20 Mar 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Vantage has won the CRM contract — final Taylr agreement out for execution.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding'],
    unitIds: [],
    totalUnits: 96,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Contracts Out',
    enabled: false,
    taylrDirectAlso: true,
    taylrAgreement: null,
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    leadInfo: {
      estimatedConversionDate: 'May 2026',
      probability: 90,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 450,
      nextAction: 'Chase signed agreement from developer solicitor',
      nextActionDate: '22 Apr 2026',
      activity: [
        { id: 'la-003-1', date: '20 Mar 2026', type: 'Note', author: 'Alyssa Monaghan', content: 'Vantage won CRM contract. Lead handed to Taylr for onboarding agreement.' },
        { id: 'la-003-2', date: '28 Mar 2026', type: 'Email', author: 'Taylr BD', content: 'Taylr agreement sent to developer solicitor for execution.' },
        { id: 'la-003-3', date: '10 Apr 2026', type: 'Call', author: 'Taylr BD', content: 'Solicitor confirmed receipt — minor redlines expected back this week.' },
        { id: 'la-003-4', date: '15 Apr 2026', type: 'Email', author: 'Taylr BD', content: 'Redlines received and accepted. Awaiting countersigned copy.' },
        { id: 'la-003-5', date: '22 Apr 2026', type: 'Reminder', author: 'Alyssa Monaghan', content: 'Chase signed agreement from developer solicitor.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Referral',
    origin: {
      source: 'Lead Conversion',
      date: '20 Mar 2026',
      addedBy: 'Alyssa Monaghan (Vantage Strata)',
      notes: 'Vantage won the strata management contract for this Pre-Settlement building and handed the lead to Taylr to negotiate the platform agreement directly with the developer.',
    },
  },
  {
    id: 'building-004',
    slug: 'acton-waterfront',
    name: 'Acton Waterfront Stage 1',
    address: '5 Edinburgh Ave, Acton ACT 2601',
    suburb: 'Acton',
    upNumber: '',
    stage: 'Pre-Settlement',
    dateCreated: '05 Mar 2026',
    creationMethod: 'Taylr Manual',
    historyNotes: 'Developer lead — Taylr chasing directly, no strata partner attached yet.',
    state: 'ACT',
    strataId: '',
    services: [],
    unitIds: [],
    totalUnits: 210,
    manager: { name: '', email: '' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Taylr Prospect',
    enabled: false,
    taylrAgreement: null,
    contacts: [
      { name: 'Marcus Bligh', role: 'Developer (Edinburgh Capital Partners)', email: 'm.bligh@edinburghcap.com.au', phone: '02 6109 4400' },
    ],
    developer: {
      companyName: 'Edinburgh Capital Partners',
      abn: '47 612 884 220',
      website: 'https://edinburghcap.com.au',
      address: 'L18, 1 Constitution Ave, Canberra ACT 2601',
      primaryContact: {
        name: 'Marcus Bligh',
        title: 'Head of Operations',
        email: 'm.bligh@edinburghcap.com.au',
        phone: '02 6109 4400',
      },
      revenueSharing: { agreementInPlace: false },
    },
    leadInfo: {
      estimatedConversionDate: 'Q4 2026',
      probability: 35,
      taylrOwnerId: 't-bd-001',
      nextAction: 'Re-engage developer after design phase wraps',
      nextActionDate: '15 May 2026',
      activity: [
        { id: 'la-004-1', date: '05 Mar 2026', type: 'Note', author: 'Taylr BD', content: 'Lead created via developer outreach. No strata partner attached — Taylr pursuing direct.' },
        { id: 'la-004-2', date: '12 Mar 2026', type: 'Email', author: 'Taylr BD', content: 'Sent Taylr capability deck to developer head of operations.' },
        { id: 'la-004-3', date: '02 Apr 2026', type: 'Meeting', author: 'Taylr BD', content: 'Discovery call — developer interested but settlement not until late 2026. Will revisit closer to handover.' },
        { id: 'la-004-4', date: '15 May 2026', type: 'Reminder', author: 'Taylr BD', content: 'Re-engage developer after design phase wraps.' },
      ],
    },
    leadSource: 'Developer',
    origin: {
      source: 'Lead Conversion',
      date: '05 Mar 2026',
      addedBy: 'Taylr BD',
      notes: 'Developer-sourced lead — Edinburgh Capital Partners engaged Taylr directly during the design phase. No strata partner attached (Pre-Settlement, no OC appointed yet). Long-tail lead pending settlement in late 2026; if a strata partner is later appointed we can flip this to a joint pursuit.',
    },
  },
  {
    // Taylr-direct New Lead — inbound enquiry from an OC chair who found
    // Taylr via search and emailed in. Sits in the New Lead inbox waiting
    // for Taylr admin to pick up + triage. 38 units → proposal requirement
    // is Optional (sub-50, not strata-referred), so no mandatory-proposal
    // alert fires; the bell surfaces it only as a "Pick up new lead" item.
    id: 'building-015',
    slug: 'forrest-mews',
    name: 'Forrest Mews',
    address: '24 Hopetoun Cct, Forrest ACT 2603',
    suburb: 'Forrest',
    upNumber: 'UP11203',
    stage: 'Established',
    registrationDate: '03 Jun 2018',
    establishedDate: '03 Sep 2018',
    dateCreated: '15 Apr 2026',
    creationMethod: 'Taylr Manual',
    historyNotes: 'Inbound enquiry from OC chair — found Taylr via search, no strata partner attached. Awaiting Taylr triage.',
    state: 'ACT',
    strataId: '',
    services: [],
    unitIds: [],
    totalUnits: 38,
    manager: { name: '', email: '' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'New Lead',
    enabled: false,
    taylrAgreement: null,
    contacts: [
      { name: 'Marcus Wei', role: 'OC Chair', email: 'mwei@forrestmews.org.au', phone: '0412 884 217' },
    ],
    leadInfo: {
      estimatedConversionDate: 'Q3 2026',
      probability: 35,
      owner: 'Unassigned',
      nextAction: 'Triage inbound enquiry — confirm scope, assign Taylr BD, schedule discovery call',
      nextActionDate: '20 Apr 2026',
      activity: [
        { id: 'la-015-1', date: '15 Apr 2026', type: 'Email', author: 'Marcus Wei (OC Chair)', content: 'Inbound enquiry via taylr.com.au contact form: "Our committee is exploring smart-locker options for our 38-unit building in Forrest. Could you send pricing and a demo time?" — landed in shared inbox.' },
        { id: 'la-015-2', date: '15 Apr 2026', type: 'Note',  author: 'System (auto)',         content: 'Lead created at status New Lead — awaiting Taylr admin pickup.' },
        { id: 'la-015-3', date: '20 Apr 2026', type: 'Reminder', author: 'System (auto)',     content: 'Pick up this lead and assign a Taylr BD owner.' },
      ],
    },
    leadSource: 'Inbound Enquiry',
    origin: {
      source: 'Lead Conversion',
      date: '15 Apr 2026',
      addedBy: 'System (inbound)',
      notes: 'Pure Taylr-direct inbound — OC chair self-served via the public website contact form. No strata partner attached. Sub-50 units so a Taylr proposal is optional unless the building grows or a strata partner refers it.',
    },
  },
  {
    id: 'building-005',
    slug: 'manuka-green',
    name: 'Manuka Green',
    address: '19 Franklin St, Manuka ACT 2603',
    suburb: 'Manuka',
    upNumber: 'UP09421',
    stage: 'Established',
    registrationDate: '11 Aug 2016',
    establishedDate: '11 Nov 2016',
    dateCreated: '14 Feb 2026',
    creationMethod: 'Taylr Manual',
    agreedFeePerUnitPerAnnum: 380,
    hasParcelLocker: true,
    historyNotes: 'Taylr-direct agreement; building is serviced by Bridges Strata Group (non-partner).',
    state: 'ACT',
    strataId: 'strata-002',
    services: ['Onboarding'],
    unitIds: [],
    totalUnits: 48,
    manager: { name: 'Daniel Hughes', email: 'dhughes@bridgesstrata.com.au' },
    agreementStart: '14 Feb 2026',
    agreementTerm: '24 months',
    relationshipStatus: 'Won',
    enabled: true,
    taylrAgreement: { startDate: '14 Feb 2026', durationYears: 2, expiryDate: '14 Feb 2028', status: 'Active' },
    contacts: [
      { name: 'Daniel Hughes', role: 'Strata Manager', email: 'dhughes@bridgesstrata.com.au', phone: '02 6234 1100' },
    ],
    origin: {
      source: 'Inbound Enquiry',
      date: '14 Feb 2026',
      addedBy: 'Taylr BD',
      notes: 'Owners Corporation chair reached out after seeing Taylr present at a strata industry forum. Taylr signed direct agreement with the OC even though Bridges Strata Group (non-partner) provides management.',
    },
  },
  {
    id: 'building-006',
    slug: 'gungahlin-heights',
    name: 'Gungahlin Heights',
    address: '30 Hibberson St, Gungahlin ACT 2912',
    suburb: 'Gungahlin',
    upNumber: 'UP11088',
    stage: 'Established',
    registrationDate: '22 Jul 2018',
    establishedDate: '22 Oct 2018',
    dateCreated: '10 Jan 2026',
    creationMethod: 'Taylr Manual',
    historyNotes: 'Vantage lost the CRM contract for this building on 28 Mar 2026 — awaiting new strata details.',
    state: 'ACT',
    strataId: '',
    previousStrata: 'Vantage Strata',
    services: ['Onboarding', 'S119 Rental'],
    unitIds: [],
    totalUnits: 74,
    manager: { name: '', email: '' },
    agreementStart: '10 Jan 2026',
    agreementTerm: '24 months',
    relationshipStatus: 'Unassigned',
    enabled: true,
    taylrAgreement: { startDate: '10 Jan 2026', durationYears: 2, expiryDate: '10 Jan 2028', status: 'Active' },
    contacts: [],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '10 Jan 2026',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Originally onboarded via Vantage Strata. Vantage subsequently lost the strata management contract on 28 Mar 2026 — direct Taylr agreement remains valid; awaiting new strata assignment.',
    },
  },
  {
    id: 'building-007',
    slug: 'belconnen-views',
    name: 'Belconnen Views',
    address: '6 Chandler St, Belconnen ACT 2617',
    suburb: 'Belconnen',
    upNumber: 'UP13902',
    stage: 'Established',
    registrationDate: '03 May 2020',
    establishedDate: '03 Aug 2020',
    dateCreated: '18 Jan 2026',
    creationMethod: 'Strata Manual',
    historyNotes: 'Vantage pursued this building but lost the CRM contract to an incumbent on 02 Apr 2026.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 120,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Prospect Lost',
    enabled: false,
    taylrAgreement: null,
    contacts: [],
    leadInfo: {
      probability: 0,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 450,
      activity: [
        { id: 'la-007-1', date: '18 Jan 2026', type: 'Note', author: 'Alyssa Monaghan', content: 'Lead created. Vantage pitching CRM contract against incumbent.' },
        { id: 'la-007-2', date: '20 Feb 2026', type: 'Meeting', author: 'Alyssa Monaghan', content: 'Committee meeting attended. Mixed reception — incumbent has long history with OC.' },
        { id: 'la-007-3', date: '02 Apr 2026', type: 'Note', author: 'Alyssa Monaghan', content: 'Lost — committee voted to retain incumbent. Marked as Prospect Lost.' },
      ],
    },
    leadSource: 'Strata Referral',
    strataLeadSource: 'Existing client',
    origin: {
      source: 'Lead Conversion',
      date: '18 Jan 2026',
      addedBy: 'Alyssa Monaghan (Vantage Strata)',
      notes: 'Vantage pursued this building against an incumbent strata. Pursuit lost at committee vote on 02 Apr 2026 — kept on file for future re-engagement when incumbent contract next renews.',
    },
    lostInfo: {
      lostDate: '02 Apr 2026',
      lostReasonCategory: 'Incumbent retained',
      lostReason: 'Committee voted to retain the incumbent strata manager. Vantage was a credible challenger but the OC valued continuity.',
      lostToStrataId: 'strata-002',
      incumbentAgreementExpiry: '01 Mar 2027',
      followUpDate: '01 Dec 2026',
      followUpNotes: 'Re-pitch ~3 months before incumbent agreement expiry. Reconnect with the chair (Marcus Bligh) — he was supportive in the committee vote.',
    },
  },
  {
    id: 'building-009',
    slug: 'civic-quarter',
    name: 'Civic Quarter',
    address: '2 Bunda St, Canberra ACT 2601',
    suburb: 'Canberra',
    upNumber: 'UP14520',
    stage: 'Established',
    registrationDate: '15 Nov 2021',
    establishedDate: '15 Feb 2022',
    dateCreated: '28 Nov 2025',
    creationMethod: 'PIQ Sync',
    agreedFeePerUnitPerAnnum: 460,
    historyNotes: 'Agreement terminated 15 Feb 2026 — building offboarded from Taylr.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 88,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '15 Feb 2024',
    agreementTerm: '24 months',
    relationshipStatus: 'Expired Lost',
    enabled: false,
    taylrAgreement: null,
    contacts: [],
    origin: {
      source: 'PIQ Import',
      date: '28 Nov 2025',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Onboarded via Vantage Strata PIQ sync. Taylr agreement was terminated 15 Feb 2026 and the building was offboarded — record retained for historical reference.',
    },
  },
  {
    id: 'building-008',
    slug: 'weston-creek-residences',
    name: 'Weston Creek Residences',
    address: '21 Brierly St, Weston ACT 2611',
    suburb: 'Weston',
    upNumber: 'UP07654',
    stage: 'Established',
    registrationDate: '09 Jun 2014',
    establishedDate: '09 Sep 2014',
    dateCreated: '02 Dec 2025',
    creationMethod: 'PIQ Sync',
    agreedFeePerUnitPerAnnum: 420,
    hasParcelLocker: true,
    historyNotes: 'Taylr agreement expired 30 Mar 2026 — renewal under discussion with Vantage.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding'],
    unitIds: [],
    totalUnits: 56,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '30 Mar 2023',
    agreementTerm: '36 months',
    relationshipStatus: 'Agreement Expired',
    enabled: false,
    taylrAgreement: {
      startDate: '30 Mar 2023',
      durationYears: 3,
      expiryDate: '30 Mar 2026',
      status: 'Expired',
      renewalActivity: [
        { id: 'ra-008-1', date: '02 Jan 2026', type: 'Email', author: 'Sam Weiland', content: 'Opened renewal window — emailed Alyssa flagging the 30 Mar 2026 expiry and proposing a call to discuss a new 3-year term.' },
        { id: 'ra-008-2', date: '14 Jan 2026', type: 'Call', author: 'Sam Weiland', content: 'Follow-up call with Alyssa. Vantage broadly positive but wants to review fee structure before committing — flagged levy pressure on the OC.' },
        { id: 'ra-008-3', date: '05 Feb 2026', type: 'Meeting', author: 'Sam Weiland', content: 'On-site meeting at Weston Creek with Alyssa and the chair. Walked through service performance over the term and discussed renewal scope.' },
        { id: 'ra-008-4', date: '20 Feb 2026', type: 'Note', author: 'Sam Weiland', content: 'New proposal sent — 3-year renewal at $440/unit/annum with parcel locker maintenance bundled. Awaiting committee review.' },
        { id: 'ra-008-5', date: '12 Mar 2026', type: 'Email', author: 'Alyssa Monaghan', content: 'Vantage response: committee wants to hold off signing until after the March AGM. Asked Taylr to keep services running on goodwill into April.' },
        { id: 'ra-008-6', date: '02 Apr 2026', type: 'Call', author: 'Priya Naidu', content: 'Post-expiry check-in. Alyssa confirmed AGM raised renewal but no vote taken — requested a revised proposal with a 2-year option as well.' },
        { id: 'ra-008-7', date: '15 Apr 2026', type: 'Note', author: 'Sam Weiland', content: 'Renewal still under discussion. Revised 2-year and 3-year options drafted internally — sending this week pending Jordan\'s sign-off.' },
      ],
    },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'PIQ Import',
      date: '02 Dec 2025',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Onboarded via Vantage Strata PIQ sync. Taylr agreement expired 30 Mar 2026 and renewal is currently under discussion with Vantage.',
    },
  },

  // ---------------------------------------------------------------------
  // Historical Vantage wins. Lightweight buildings (no unit/contact deep
  // detail) seeded so the strata-view conversion stats reflect a realistic
  // partner pipeline rather than a thin one-deal sample. They show up in
  // the Buildings module and feed the Won tile / win-rate calculation.
  // ---------------------------------------------------------------------
  {
    id: 'building-vantage-won-001',
    slug: 'bellevue-court-forrest',
    name: 'Bellevue Court',
    address: '14 Bellevue Crescent, Forrest ACT 2603',
    suburb: 'Forrest',
    upNumber: 'UP14210',
    stage: 'Established',
    registrationDate: '12 Aug 2020',
    establishedDate: '03 Sep 2020',
    dateCreated: '08 Sep 2025',
    creationMethod: 'PIQ Sync',
    agreedFeePerUnitPerAnnum: 450,
    historyNotes: 'Vantage-managed building onboarded to Taylr in late 2025.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding', 'S119 Rental'],
    unitIds: [],
    totalUnits: 84,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '15 Oct 2025',
    agreementTerm: '36 months',
    relationshipStatus: 'Won',
    enabled: true,
    taylrAgreement: { startDate: '15 Oct 2025', durationYears: 3, expiryDate: '15 Oct 2028', status: 'Active' },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '08 Sep 2025',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Brought to Taylr by Vantage Strata. Signed at Q4 AGM after a successful proposal review.',
    },
  },
  {
    id: 'building-vantage-won-002',
    slug: 'manuka-heights',
    name: 'Manuka Heights',
    address: '7 Franklin Street, Manuka ACT 2603',
    suburb: 'Manuka',
    upNumber: 'UP13042',
    stage: 'Established',
    registrationDate: '21 Feb 2018',
    establishedDate: '14 May 2018',
    dateCreated: '12 Feb 2025',
    creationMethod: 'PIQ Sync',
    agreedFeePerUnitPerAnnum: 450,
    historyNotes: 'Long-standing Vantage building — added to Taylr early 2025 after a portfolio-wide rollout decision.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding'],
    unitIds: [],
    totalUnits: 52,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '01 Mar 2025',
    agreementTerm: '36 months',
    relationshipStatus: 'Won',
    enabled: true,
    taylrAgreement: { startDate: '01 Mar 2025', durationYears: 3, expiryDate: '01 Mar 2028', status: 'Active' },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '12 Feb 2025',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Part of Vantage\'s portfolio-wide Taylr rollout in Q1 2025.',
    },
  },
  {
    id: 'building-vantage-lost-001',
    slug: 'braddon-lofts',
    name: 'Braddon Lofts',
    address: '32 Lonsdale Street, Braddon ACT 2612',
    suburb: 'Braddon',
    upNumber: 'UP15601',
    stage: 'Established',
    registrationDate: '05 Jul 2022',
    establishedDate: '20 Aug 2022',
    dateCreated: '15 Nov 2025',
    creationMethod: 'Strata Manual',
    historyNotes: 'Vantage put forward as a Taylr proposal — committee opted to defer to next AGM and ultimately stayed with their incumbent provider.',
    state: 'ACT',
    strataId: 'strata-001',
    services: [],
    unitIds: [],
    totalUnits: 38,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '',
    agreementTerm: '',
    relationshipStatus: 'Prospect Lost',
    enabled: false,
    taylrAgreement: null,
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    leadInfo: {
      estimatedConversionDate: 'Feb 2026',
      probability: 0,
      taylrOwnerId: 't-bd-001',
      strataOwnerId: 'su-001-alyssa',
      feePerUnitPerAnnum: 480,
      nextAction: 'Re-engage at next AGM (Q1 2027)',
      nextActionDate: '15 Feb 2027',
      activity: [
        { id: 'la-vlost1-1', date: '15 Nov 2025', type: 'Note', author: 'Alyssa Monaghan', content: 'Lead added — Vantage put Braddon Lofts forward for a Taylr proposal.' },
        { id: 'la-vlost1-2', date: '20 Jan 2026', type: 'Meeting', author: 'Taylr BD', content: 'Proposal review meeting with committee. Mixed reception — concerns about migration timing.' },
        { id: 'la-vlost1-3', date: '12 Feb 2026', type: 'Note', author: 'Alyssa Monaghan', content: 'Committee voted to stay with incumbent for now. Will revisit at Q1 2027 AGM.' },
      ],
    },
    lostInfo: {
      lostDate: '12 Feb 2026',
      lostReason: 'Committee preferred to stay with incumbent provider — concerns about migration timing.',
      lostReasonCategory: 'Incumbent retained',
      lostToOther: 'Incumbent provider',
      incumbentAgreementExpiry: '15 May 2027',
      followUpDate: '15 Feb 2027',
      followUpNotes: 'Re-engage at next AGM (Q1 2027).',
    },
  },
  // ------------------------------------------------------------------
  // Stage-coverage seed (strata-001 / Vantage Strata).
  // Adds one Won building per missing lifecycle stage (Development,
  // Pre-Settlement, Registered) so the strata Buildings view — and the
  // admin Buildings module — show the full pipeline rather than just
  // Established. Each is a plausible Vantage off-the-plan project being
  // onboarded to Taylr ahead of registration.
  // ------------------------------------------------------------------
  {
    id: 'building-100',
    slug: 'belconnen-rise-stage-1',
    name: 'Belconnen Rise — Stage 1',
    address: '14 Emu Bank, Belconnen ACT 2617',
    suburb: 'Belconnen',
    upNumber: '',
    stage: 'Development',
    dateCreated: '02 Feb 2026',
    creationMethod: 'Developer Import',
    historyNotes: 'Off-the-plan project loaded ahead of registration; presales in market.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding'],
    unitIds: [],
    totalUnits: 96,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '02 Feb 2026',
    agreementTerm: '36 months',
    relationshipStatus: 'Won',
    enabled: true,
    agreedFeePerUnitPerAnnum: 520,
    taylrAgreement: { startDate: '02 Feb 2026', durationYears: 3, expiryDate: '02 Feb 2029', status: 'Active' },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '02 Feb 2026',
      addedBy: 'Vantage Strata',
      notes: 'Developer-led onboarding via Vantage Strata. Building is still under construction; Taylr in place ready for handover.',
    },
  },
  {
    id: 'building-101',
    slug: 'lake-burley-quarter',
    name: 'Lake Burley Quarter',
    address: '21 Wendouree Drive, Acton ACT 2601',
    suburb: 'Acton',
    upNumber: '',
    stage: 'Pre-Settlement',
    dateCreated: '12 Sep 2025',
    creationMethod: 'Developer Import',
    historyNotes: 'Settlements commencing Q3 2026; OC formation pending registration.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding', 'S119 Rental'],
    unitIds: [],
    totalUnits: 124,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '12 Sep 2025',
    agreementTerm: '36 months',
    relationshipStatus: 'Won',
    enabled: true,
    agreedFeePerUnitPerAnnum: 510,
    taylrAgreement: { startDate: '12 Sep 2025', durationYears: 3, expiryDate: '12 Sep 2028', status: 'Active' },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '12 Sep 2025',
      addedBy: 'Vantage Strata',
      notes: 'Pre-settlement project — Taylr platform ready for resident activation as units settle.',
    },
  },
  {
    id: 'building-102',
    slug: 'manuka-park-residences',
    name: 'Manuka Park Residences',
    address: '35 Flinders Way, Manuka ACT 2603',
    suburb: 'Manuka',
    upNumber: 'UP18204',
    stage: 'Registered',
    registrationDate: '08 Jan 2026',
    dateCreated: '08 Jan 2026',
    creationMethod: 'PIQ Sync',
    historyNotes: 'Recently registered; OC inaugural meeting scheduled — establishment pending.',
    state: 'ACT',
    strataId: 'strata-001',
    services: ['Onboarding'],
    unitIds: [],
    totalUnits: 54,
    manager: { name: 'Alyssa Monaghan', email: 'alyssa.monaghan@vantagestrata.com.au' },
    agreementStart: '08 Jan 2026',
    agreementTerm: '24 months',
    relationshipStatus: 'Won',
    enabled: true,
    agreedFeePerUnitPerAnnum: 495,
    taylrAgreement: { startDate: '08 Jan 2026', durationYears: 2, expiryDate: '08 Jan 2028', status: 'Active' },
    contacts: [
      { name: 'Alyssa Monaghan', role: 'Strata Manager', email: 'alyssa.monaghan@vantagestrata.com.au', phone: '02 6171 9700' },
    ],
    origin: {
      source: 'Strata Partner Onboarding',
      date: '08 Jan 2026',
      addedBy: 'Vantage Strata (PIQ sync)',
      notes: 'Imported from Vantage PIQ following plan registration. Inaugural OC meeting due — building will move to Established once held.',
    },
  },
];

export const units: Unit[] = [
  { id: 'unit-001', name: '1 / 2 Lady Nelson Place', lot: '1', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-001', unitAddress: '1 / 2 Lady Nelson Place', doorNumber: 1, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-002', name: '2 / 2 Lady Nelson Place', lot: '2', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-002', unitAddress: '2 / 2 Lady Nelson Place', doorNumber: 2, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-003', name: '3 / 2 Lady Nelson Place', lot: '3', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-003', unitAddress: '3 / 2 Lady Nelson Place', doorNumber: 3, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-004', name: '4 / 2 Lady Nelson Place', lot: '4', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-004', unitAddress: '4 / 2 Lady Nelson Place', doorNumber: 4, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-005', name: '5 / 2 Lady Nelson Place', lot: '5', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-005', unitAddress: '5 / 2 Lady Nelson Place', doorNumber: 5, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-006', name: '6 / 2 Lady Nelson Place', lot: '6', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-006', unitAddress: '6 / 2 Lady Nelson Place', doorNumber: 6, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-007', name: '7 / 2 Lady Nelson Place', lot: '7', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-007', unitAddress: '7 / 2 Lady Nelson Place', doorNumber: 7, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-008', name: '8 / 2 Lady Nelson Place', lot: '8', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-008', unitAddress: '8 / 2 Lady Nelson Place', doorNumber: 8, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-009', name: '9 / 2 Lady Nelson Place', lot: '9', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-009', unitAddress: '9 / 2 Lady Nelson Place', doorNumber: 9, streetNumber: 2, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-010', name: '1 / 4 Lady Nelson Place', lot: '10', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-010', unitAddress: '1 / 4 Lady Nelson Place', doorNumber: 1, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-011', name: '2 / 4 Lady Nelson Place', lot: '11', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-011', unitAddress: '2 / 4 Lady Nelson Place', doorNumber: 2, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-012', name: '3 / 4 Lady Nelson Place', lot: '12', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-012', unitAddress: '3 / 4 Lady Nelson Place', doorNumber: 3, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-013', name: '4 / 4 Lady Nelson Place', lot: '13', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-013', unitAddress: '4 / 4 Lady Nelson Place', doorNumber: 4, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-014', name: '5 / 4 Lady Nelson Place', lot: '14', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-014', unitAddress: '5 / 4 Lady Nelson Place', doorNumber: 5, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-015', name: '6 / 4 Lady Nelson Place', lot: '15', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-015', unitAddress: '6 / 4 Lady Nelson Place', doorNumber: 6, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-016', name: '7 / 4 Lady Nelson Place', lot: '16', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-016', unitAddress: '7 / 4 Lady Nelson Place', doorNumber: 7, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-017', name: '8 / 4 Lady Nelson Place', lot: '17', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-017', unitAddress: '8 / 4 Lady Nelson Place', doorNumber: 8, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-018', name: '9 / 4 Lady Nelson Place', lot: '18', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-018', unitAddress: '9 / 4 Lady Nelson Place', doorNumber: 9, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-019', name: '10 / 4 Lady Nelson Place', lot: '19', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-019', unitAddress: '10 / 4 Lady Nelson Place', doorNumber: 10, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-020', name: '11 / 4 Lady Nelson Place', lot: '20', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-020', unitAddress: '11 / 4 Lady Nelson Place', doorNumber: 11, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-021', name: '12 / 4 Lady Nelson Place', lot: '21', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-021', unitAddress: '12 / 4 Lady Nelson Place', doorNumber: 12, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-022', name: '13 / 4 Lady Nelson Place', lot: '22', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-022', unitAddress: '13 / 4 Lady Nelson Place', doorNumber: 13, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-023', name: '14 / 4 Lady Nelson Place', lot: '23', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-023', unitAddress: '14 / 4 Lady Nelson Place', doorNumber: 14, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-024', name: '15 / 4 Lady Nelson Place', lot: '24', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-024', unitAddress: '15 / 4 Lady Nelson Place', doorNumber: 15, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-025', name: '16 / 4 Lady Nelson Place', lot: '25', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-025', unitAddress: '16 / 4 Lady Nelson Place', doorNumber: 16, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-026', name: '17 / 4 Lady Nelson Place', lot: '26', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-026', unitAddress: '17 / 4 Lady Nelson Place', doorNumber: 17, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-027', name: '18 / 4 Lady Nelson Place', lot: '27', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-027', unitAddress: '18 / 4 Lady Nelson Place', doorNumber: 18, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-028', name: '19 / 4 Lady Nelson Place', lot: '28', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-028', unitAddress: '19 / 4 Lady Nelson Place', doorNumber: 19, streetNumber: 4, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-029', name: '4 / 6 Lady Nelson Place', lot: '29', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-029', unitAddress: '4 / 6 Lady Nelson Place', doorNumber: 4, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-030', name: '5 / 6 Lady Nelson Place', lot: '30', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-030', unitAddress: '5 / 6 Lady Nelson Place', doorNumber: 5, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-031', name: '6 / 6 Lady Nelson Place', lot: '31', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-031', unitAddress: '6 / 6 Lady Nelson Place', doorNumber: 6, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-032', name: '7 / 6 Lady Nelson Place', lot: '32', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-032', unitAddress: '7 / 6 Lady Nelson Place', doorNumber: 7, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-033', name: '8 / 6 Lady Nelson Place', lot: '33', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-033', unitAddress: '8 / 6 Lady Nelson Place', doorNumber: 8, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-034', name: '1 / 6 Lady Nelson Place', lot: '34', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-034', unitAddress: '1 / 6 Lady Nelson Place', doorNumber: 1, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-035', name: '2 / 6 Lady Nelson Place', lot: '35', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-035', unitAddress: '2 / 6 Lady Nelson Place', doorNumber: 2, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-036', name: '3 / 6 Lady Nelson Place', lot: '36', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-036', unitAddress: '3 / 6 Lady Nelson Place', doorNumber: 3, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-037', name: '12 / 6 Lady Nelson Place', lot: '37', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-037', unitAddress: '12 / 6 Lady Nelson Place', doorNumber: 12, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-038', name: '13 / 6 Lady Nelson Place', lot: '38', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-038', unitAddress: '13 / 6 Lady Nelson Place', doorNumber: 13, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-039', name: '14 / 6 Lady Nelson Place', lot: '39', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-039', unitAddress: '14 / 6 Lady Nelson Place', doorNumber: 14, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-040', name: '15 / 6 Lady Nelson Place', lot: '40', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-040', unitAddress: '15 / 6 Lady Nelson Place', doorNumber: 15, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-041', name: '16 / 6 Lady Nelson Place', lot: '41', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-041', unitAddress: '16 / 6 Lady Nelson Place', doorNumber: 16, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-042', name: '17 / 6 Lady Nelson Place', lot: '42', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-042', unitAddress: '17 / 6 Lady Nelson Place', doorNumber: 17, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-043', name: '9 / 6 Lady Nelson Place', lot: '43', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-043', unitAddress: '9 / 6 Lady Nelson Place', doorNumber: 9, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-044', name: '10 / 6 Lady Nelson Place', lot: '44', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-044', unitAddress: '10 / 6 Lady Nelson Place', doorNumber: 10, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-045', name: '11 / 6 Lady Nelson Place', lot: '45', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-045', unitAddress: '11 / 6 Lady Nelson Place', doorNumber: 11, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-046', name: '21 / 6 Lady Nelson Place', lot: '46', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-046', unitAddress: '21 / 6 Lady Nelson Place', doorNumber: 21, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-047', name: '22 / 6 Lady Nelson Place', lot: '47', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-047', unitAddress: '22 / 6 Lady Nelson Place', doorNumber: 22, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-048', name: '23 / 6 Lady Nelson Place', lot: '48', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-048', unitAddress: '23 / 6 Lady Nelson Place', doorNumber: 23, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-049', name: '24 / 6 Lady Nelson Place', lot: '49', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-049', unitAddress: '24 / 6 Lady Nelson Place', doorNumber: 24, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-050', name: '25 / 6 Lady Nelson Place', lot: '50', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-050', unitAddress: '25 / 6 Lady Nelson Place', doorNumber: 25, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-051', name: '26 / 6 Lady Nelson Place', lot: '51', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-051', unitAddress: '26 / 6 Lady Nelson Place', doorNumber: 26, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-052', name: '18 / 6 Lady Nelson Place', lot: '52', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-052', unitAddress: '18 / 6 Lady Nelson Place', doorNumber: 18, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-053', name: '19 / 6 Lady Nelson Place', lot: '53', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-053', unitAddress: '19 / 6 Lady Nelson Place', doorNumber: 19, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-054', name: '20 / 6 Lady Nelson Place', lot: '54', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-054', unitAddress: '20 / 6 Lady Nelson Place', doorNumber: 20, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-055', name: '30 / 6 Lady Nelson Place', lot: '55', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-055', unitAddress: '30 / 6 Lady Nelson Place', doorNumber: 30, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-056', name: '31 / 6 Lady Nelson Place', lot: '56', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-056', unitAddress: '31 / 6 Lady Nelson Place', doorNumber: 31, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-057', name: '32 / 6 Lady Nelson Place', lot: '57', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-057', unitAddress: '32 / 6 Lady Nelson Place', doorNumber: 32, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-058', name: '33 / 6 Lady Nelson Place', lot: '58', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-058', unitAddress: '33 / 6 Lady Nelson Place', doorNumber: 33, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-059', name: '34 / 6 Lady Nelson Place', lot: '59', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-059', unitAddress: '34 / 6 Lady Nelson Place', doorNumber: 34, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-060', name: '35 / 6 Lady Nelson Place', lot: '60', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-060', unitAddress: '35 / 6 Lady Nelson Place', doorNumber: 35, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-061', name: '27 / 6 Lady Nelson Place', lot: '61', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-061', unitAddress: '27 / 6 Lady Nelson Place', doorNumber: 27, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-062', name: '28 / 6 Lady Nelson Place', lot: '62', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-062', unitAddress: '28 / 6 Lady Nelson Place', doorNumber: 28, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-063', name: '29 / 6 Lady Nelson Place', lot: '63', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-063', unitAddress: '29 / 6 Lady Nelson Place', doorNumber: 29, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-064', name: '38 / 6 Lady Nelson Place', lot: '64', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-064', unitAddress: '38 / 6 Lady Nelson Place', doorNumber: 38, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-065', name: '39 / 6 Lady Nelson Place', lot: '65', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-065', unitAddress: '39 / 6 Lady Nelson Place', doorNumber: 39, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-066', name: '40 / 6 Lady Nelson Place', lot: '66', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-066', unitAddress: '40 / 6 Lady Nelson Place', doorNumber: 40, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-067', name: '36 / 6 Lady Nelson Place', lot: '67', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-067', unitAddress: '36 / 6 Lady Nelson Place', doorNumber: 36, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
  { id: 'unit-068', name: '37 / 6 Lady Nelson Place', lot: '68', floor: 1, buildingId: 'building-001', tenancyStatus: 'Unknown', s119Status: 'Unknown', ownerGroupId: 'oc-068', unitAddress: '37 / 6 Lady Nelson Place', doorNumber: 37, streetNumber: 6, streetName: 'Lady Nelson Place', hasAC: true, acType: 'Duct', acManufacturer: 'Daikin' },
];

export const members: Member[] = [
  {
    id: 'member-caroline-holmes',
    name: 'Caroline Holmes',
    email: 'caroline.holmes@example.com',
    phone: '0400 000 014',
    verified: true,
    taylrActive: false,
    leadSource: 'Manual',
    units: [
      {
        unitId: 'unit-014',
        role: 'Owner Occupier',
        confirmed: false,
        authorisedInCard: true,
        hasMovedIn: false,
      },
    ],
  },
];

export function getBuildingById(id: string) {
  return buildings.find(b => b.id === id);
}

export function getUnitsByBuildingId(buildingId: string) {
  return units.filter(u => u.buildingId === buildingId);
}

export function getMembersByUnitId(unitId: string) {
  return members.filter(m => m.units.some(u => u.unitId === unitId));
}

export function getStrataById(id: string) {
  return strataCompanies.find(s => s.id === id);
}

export function getAgentById(id: string) {
  return agentCompanies.find(a => a.id === id);
}

export function getBuildingsByStrataId(strataId: string) {
  return buildings.filter(b => b.strataId === strataId);
}

/**
 * "Strata lost" = the strata company that was appointed to this building no
 * longer manages it. Drives the void cascade on S119 certificates and the
 * "no longer managed" treatment on Buildings/Units/Strata surfaces.
 *
 * `Expired Lost`  → strata terminated & building offboarded from Taylr.
 * `Unassigned`    → strata replaced; awaiting new appointment.
 * `Agreement Expired` is intentionally NOT lost — it represents a Taylr
 * agreement lapse on goodwill, not a strata-appointment loss.
 */
export function isBuildingStrataLost(b: Building | undefined | null): boolean {
  if (!b) return false;
  return b.relationshipStatus === 'Expired Lost' || b.relationshipStatus === 'Unassigned';
}

function normaliseUp(value: string | number | undefined | null): string {
  if (value == null) return '';
  return String(value).replace(/^UP/i, '').trim();
}

export function getBuildingByUpNumber(upNumber: string | number): Building | undefined {
  const target = normaliseUp(upNumber);
  if (!target) return undefined;
  return buildings.find(b => normaliseUp(b.upNumber) === target);
}

export function isUpStrataLost(upNumber: string | number): boolean {
  return isBuildingStrataLost(getBuildingByUpNumber(upNumber));
}

export function getBuildingBySlug(slug: string) {
  return buildings.find(b => b.slug === slug);
}
