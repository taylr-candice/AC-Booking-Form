// =============================================================================
// shared/pricing.ts
//
// Single source of truth for service pricing, vendor cost, beneficiary
// determination, and remittance cadence across every module (Sales Orders,
// S119 Rentals, Finance/Pricing, Finance/Payments, Finance/Remittance,
// Strata→Services, Building→Services, Vendor module, Coupons).
//
// The previous model (`client/src/lib/pricingSeed.ts`) collapsed price + cost
// into a single per-service config and assumed one vendor per service. That
// can't represent: per-room add-ons, choice-group add-ons (brackets), per-
// building vendor cost variation, multiple vendors for the same service at
// different buildings, building-level add-on suppression, scheduled future
// price changes, or activation-triggered OC coupon expiry. This module is the
// replacement.
//
// Stage 1 ships this module + seed data only. Stage 2 will repoint existing
// consumers to read through `resolvePricing()`. Existing files keep working.
// =============================================================================

// ---------------------------------------------------------------------------
// Core enums
// ---------------------------------------------------------------------------

export type ServiceScope = 'oc' | 'unit' | 'building';

export type PricingAuthority = 'Taylr' | 'Strata' | 'Vendor';

export type RemittanceCadence =
  | 'per-order'
  | 'daily'
  | 'weekly'
  | 'fortnightly'
  | 'monthly'
  | 'manual';

export type GstMode = 'plus-gst' | 'incl-gst' | 'no-gst';

export type SkuType = 'base' | 'addon' | 'choice-option';

export type SkuUnit =
  | 'per-order'
  | 'per-room'
  | 'per-cable'
  | 'per-bracket'
  | 'per-unit';

// Building lifecycle stages relevant to service eligibility (for the future
// "new build offer" service we'll model in a later stage).
export type BuildingStage =
  | 'development'
  | 'pre-settlement'
  | 'registered'
  | 'established';

// ---------------------------------------------------------------------------
// SKU & Choice Group — services are composed of SKUs
// ---------------------------------------------------------------------------

/**
 * A SKU is a sellable line item under a service. Every service has at least
 * one `base` SKU. Add-ons are independent toggles. Choice-options belong to a
 * `ServiceChoiceGroup` and are mutually exclusive (radio).
 *
 * Per-room services (e.g. TV Wall Mount) carry `requiresPerRoom = true` on
 * the base SKU; the order flow then asks the customer to pick add-ons /
 * choice options for each room.
 */
export interface ServiceSku {
  id: string;
  name: string;
  type: SkuType;
  /** Required when type === 'choice-option'. */
  choiceGroupId?: string;
  unit: SkuUnit;
  /** Default customer-facing price. May be 0 (e.g. free Tilt bracket). */
  defaultCustomerPriceExclGst: number;
  defaultGstMode: GstMode;
  /** Default vendor wholesale cost. May be 0 (free options). May be null when
   * Taylr is the provider and there is no external vendor cost. */
  defaultVendorCostExclGst: number | null;
  /** True when the customer must pick at least one of these per room/order
   * (used for per-room bracket choice groups where one must be selected). */
  required?: boolean;
  /** True for the base SKU of a per-room service. */
  requiresPerRoom?: boolean;
  description?: string;
}

export interface ServiceChoiceGroup {
  id: string;
  name: string;
  /** When true, customer must select exactly one option per room/order. */
  isRequired: boolean;
  /** Allow a "bring my own" / "skip" pseudo-choice that resolves to no SKU
   * but is still recorded against the room. */
  allowNoneOption: boolean;
  /** Default option id (used when the customer doesn't actively choose). */
  defaultOptionId?: string;
}

/**
 * A non-pricing question asked per room (or per order, for non-per-room
 * services) at checkout. Answers are captured on `OrderLine.roomAnswers` so
 * the service provider has the info they need to deliver the job. These
 * never affect price or cost.
 *
 * Example: TV Wall Mount asks "Mount TV to wall, or install bracket only
 * (tenant will hang their own TV)?" per room. Investors who only want the
 * bracket prepped pick the second option.
 */
export interface ServiceQuestion {
  id: string;
  label: string;
  /** When true, asked once per room of a per-room service. When false, asked
   * once per order. */
  perRoom: boolean;
  /** When true, the customer must answer before checkout. */
  isRequired: boolean;
  options: { id: string; label: string }[];
  defaultOptionId?: string;
  helpText?: string;
}

// ---------------------------------------------------------------------------
// Service catalog
// ---------------------------------------------------------------------------

export interface Service {
  id: string;
  slug: string;
  name: string;
  /** Where the service record is persisted/inherited. S119 + depreciation =
   * 'oc'; TV Wall Mount = 'unit'; parcel locker = 'building'. */
  scope: ServiceScope;
  pricingAuthority: PricingAuthority;
  /** When pricingAuthority === 'Strata', the strata that owns this pricing.
   * Used so S119 prices can be set on a per-strata basis. */
  strataCompany?: string;
  category: string;
  description?: string;
  skus: ServiceSku[];
  choiceGroups: ServiceChoiceGroup[];
  /** Optional non-pricing questions captured at checkout (per-room or per-
   * order) so the provider has the info they need. */
  questions?: ServiceQuestion[];
  /** Stages a building must be in for this service to be orderable. Empty =
   * available regardless of stage. */
  eligibleBuildingStages?: BuildingStage[];
  status: 'Active' | 'Inactive';
}

// ---------------------------------------------------------------------------
// Vendor (service provider OR strata partner — same shape)
// ---------------------------------------------------------------------------

export interface PiInsurance {
  insurer: string;
  policyNumber: string;
  expiryDate: string;
  coverAmount: number;
  documentRef?: string;
}

export interface Vendor {
  id: string;
  name: string;
  tradingName?: string;
  /** When true, this Vendor record represents a strata company acting as the
   * beneficiary for strata-fulfilled services. UI may render differently. */
  isStrataPartner?: boolean;
  abn: string;
  gstRegistered: boolean;
  email: string;
  phone: string;
  remittanceCadence: RemittanceCadence;
  payoutMethod: 'bank-transfer' | 'manual' | 'stripe-connect';
  bankBsb?: string;
  bankAccount?: string;
  xeroContactId?: string;
  piInsurance?: PiInsurance;
  status: 'Active' | 'Inactive';
  notes?: string;
  addedAt: string;
}

// ---------------------------------------------------------------------------
// SKU overrides — used everywhere overrides apply
// ---------------------------------------------------------------------------

/**
 * Per-SKU overrides. Each field is independently optional so you can override
 * customer price OR vendor cost (or both) at a given level without affecting
 * the other.
 */
export interface SkuOverride {
  skuId: string;
  customerPriceExclGst?: number;
  /** `number` to override the default cost; `null` to explicitly mark "no
   * external vendor cost" (Taylr-direct) at this level even when the service
   * default has a non-null cost. `undefined` means inherit from the level
   * above. */
  vendorCostExclGst?: number | null;
}

/** A scheduled future change that flips into effect on `effectiveFrom`. */
export interface ScheduledPricingChange {
  id: string;
  effectiveFrom: string; // ISO date
  authoredBy: string;
  authoredAt: string;
  skuOverrides: SkuOverride[];
  /** Optional add-on suppression changes that take effect at the same time. */
  suppressedAddOnIds?: string[];
  note?: string;
}

// ---------------------------------------------------------------------------
// ServiceAssignment — service × building × vendor
// ---------------------------------------------------------------------------

/**
 * Binds a service to a building and (optionally) a vendor with their
 * commercial terms for that building. This is the new key concept that
 * replaces the old "one vendor per service" assumption.
 *
 * Vendor may be null when Taylr will allocate a provider per order (used for
 * the future bulk "new build offer" workflow, and as a fallback when the
 * primary vendor can't take a job).
 */
export interface ServiceAssignment {
  id: string;
  serviceId: string;
  buildingName: string;
  /** Primary vendor for this service at this building. Null = Taylr allocates
   * per order. */
  vendorId: string | null;
  /** Fallback vendors if primary cannot take the job (round-robin / overflow). */
  fallbackVendorIds: string[];
  /** Per-SKU price/cost overrides for this assignment. */
  skuOverrides: SkuOverride[];
  /** Add-on SKU ids that are NOT offered at this building (e.g. Swivel
   * bracket suppressed at The Parks because the wall structure can't support). */
  suppressedAddOnIds: string[];
  effectiveFrom: string;
  effectiveTo?: string;
  scheduledChanges: ScheduledPricingChange[];
  status: 'Active' | 'Inactive';
}

// ---------------------------------------------------------------------------
// Per-unit pricing override (rare — for special-case unit-level pricing)
// ---------------------------------------------------------------------------

export interface UnitPricingOverride {
  id: string;
  serviceId: string;
  unitId: string;
  buildingName: string;
  skuOverrides: SkuOverride[];
  scheduledChanges: ScheduledPricingChange[];
  note?: string;
}

// ---------------------------------------------------------------------------
// Coupons — promotion / discount system with OC-aware expiry triggers
// ---------------------------------------------------------------------------

export type CouponScope = 'all' | 'building' | 'unit' | 'oc';

export type CouponDiscountType = 'flat-amount' | 'percentage';

/** What part of an order the coupon applies to.
 *
 * - `all-skus`: discount runs against the whole order subtotal (base + every
 *   chargeable add-on / choice option). Use for "$50 off your TV install".
 * - `base-only`: discount runs only against the base SKU subtotal — useful
 *   for "20% off the mount, add-ons charged at full price".
 * - `specific-skus`: discount runs only against the SKU ids listed in
 *   `appliesToSkuIds`. Use this for "$10 off every HDMI cable" or
 *   "20% off the swivel bracket this month". */
export type CouponAppliesTo = 'all-skus' | 'base-only' | 'specific-skus';

export type CouponExpiryTrigger =
  | 'fixed-date'
  | 'days-from-first-activation'
  | 'never';

export interface Coupon {
  id: string;
  code: string;
  serviceId: string;
  scope: CouponScope;
  /** Target identifier for scoped coupons: building name, unitId, or ocId. */
  targetId?: string;
  discountType: CouponDiscountType;
  discountAmount: number;
  appliesTo: CouponAppliesTo;
  /** Required when `appliesTo === 'specific-skus'`. Each listed SKU id is
   * discounted independently — i.e. a $10 flat discount on a SKU listed here
   * deducts $10 from each unit of that SKU on the order. A 20% discount
   * deducts 20% of that SKU's per-unit price for every unit. */
  appliesToSkuIds?: string[];
  maxDiscountCap: number | null;
  validFrom: string;
  expiryTrigger: CouponExpiryTrigger;
  /** When expiryTrigger === 'fixed-date'. */
  validUntil?: string;
  /** When expiryTrigger === 'days-from-first-activation'. */
  daysFromActivation?: number;
  /** Suppress the coupon for owners whose unit already has this service
   * installed (e.g. don't promote TV mount to a unit that's had one
   * installed by a previous owner). */
  suppressIfUnitHasServiceId?: string;
  /** When set, this coupon auto-attaches to every newly-created OC under the
   * matching building. Used for the "new OC welcome" promotion. */
  autoAttachToNewOcsAtBuilding?: string;
  maxRedemptions: number | null;
  singleUsePerOC: boolean;
  usedCount: number;
  status: 'Active' | 'Expired' | 'Exhausted';
}

// ---------------------------------------------------------------------------
// Order lines & remittance stamps (the per-line model)
// ---------------------------------------------------------------------------

export type RemittanceStampType = 'charge' | 'refund';

export interface RemittanceStamp {
  remittanceId: string;
  type: RemittanceStampType;
  amount: number; // negative for refunds
  stampedAt: string;
}

/**
 * One billable line on an order. Snapshotted at order time so historical
 * orders are immune to future price/cost/vendor changes.
 *
 * `vendorIdSnapshot` may be null when the order was placed before Taylr
 * allocated a provider. The remittance system ignores lines with a null
 * vendor until a vendor is assigned.
 */
export interface OrderLine {
  id: string;
  skuId: string;
  /** Display name snapshot, useful when SKUs are renamed later. */
  skuName: string;
  qty: number;
  /** Per-room services (TV mount) populate this. */
  room?: string;
  /** Per-room (or per-order) answers to `Service.questions`. Keyed by
   * `ServiceQuestion.id` → selected `option.id`. Captured at checkout and
   * passed through to the service provider on the work order. Never affects
   * price or cost. */
  roomAnswers?: Record<string, string>;
  /** What the customer paid per unit, ex-GST. */
  customerPriceExclGstSnapshot: number;
  /** What Taylr owes the vendor per unit, ex-GST. Null = Taylr direct, no
   * vendor cost (e.g. S119 Mode A historically). */
  vendorCostExclGstSnapshot: number | null;
  vendorIdSnapshot: string | null;
  beneficiaryNameSnapshot: string | null;
  /** Coupon discount applied to this line (after appliesTo filtering). */
  discountExclGst: number;
  /** Each charge or refund stamps this line with the remittance # it landed
   * on. The first stamp is the charge; later stamps are refund adjustments
   * landing in subsequent batches. */
  remittanceStamps: RemittanceStamp[];
}

// ---------------------------------------------------------------------------
// Resolution — the dynamic accessor every module reads through
// ---------------------------------------------------------------------------

export interface ResolvedSku {
  sku: ServiceSku;
  customerPriceExclGst: number;
  customerPriceInclGst: number;
  vendorCostExclGst: number | null;
  vendorCostInclGst: number | null;
  /** False when this add-on is suppressed at this building. */
  available: boolean;
}

export interface ResolvedAssignment {
  assignment: ServiceAssignment | null;
  vendor: Vendor | null;
  fallbackVendors: Vendor[];
}

export interface ResolvedPricing {
  service: Service;
  resolution: ResolvedAssignment;
  /** Resolved SKUs in catalog order; suppressed add-ons included with
   * `available = false` so UIs can render them as "not offered here". */
  skus: ResolvedSku[];
}

// ---------------------------------------------------------------------------
// Resolution helpers (pure functions over the seed dictionaries)
// ---------------------------------------------------------------------------

const GST_RATE = 0.1;

function applyGst(value: number, mode: GstMode): number {
  switch (mode) {
    case 'plus-gst':
      return +(value * (1 + GST_RATE)).toFixed(2);
    case 'incl-gst':
    case 'no-gst':
      return +value.toFixed(2);
  }
}

/**
 * Merges `next` SkuOverride on top of `prev`, treating `undefined` as "inherit"
 * and `null` (only meaningful for vendorCostExclGst) as "explicitly clear".
 */
function mergeSkuOverride(prev: SkuOverride, next: SkuOverride): SkuOverride {
  return {
    skuId: prev.skuId,
    customerPriceExclGst:
      next.customerPriceExclGst !== undefined
        ? next.customerPriceExclGst
        : prev.customerPriceExclGst,
    vendorCostExclGst:
      next.vendorCostExclGst !== undefined
        ? next.vendorCostExclGst
        : prev.vendorCostExclGst,
  };
}

/**
 * Applies ALL scheduled changes whose `effectiveFrom` is on or before `asOf`,
 * in chronological order, each one stacking on top of the previous. This way
 * a series of small price bumps over time accumulate correctly rather than
 * only the latest taking effect.
 *
 * `suppressedAddOnIds` reflects the most-recent scheduled change that
 * specified one (since suppression is a state, not a delta).
 */
function applyScheduledChanges(
  base: SkuOverride[],
  scheduled: ScheduledPricingChange[],
  asOf: Date,
): { skuOverrides: SkuOverride[]; suppressedAddOnIds?: string[] } {
  const effective = scheduled
    .filter(c => new Date(c.effectiveFrom) <= asOf)
    .sort((a, b) =>
      new Date(a.effectiveFrom).getTime() - new Date(b.effectiveFrom).getTime(),
    );

  const merged = new Map<string, SkuOverride>();
  for (const o of base) merged.set(o.skuId, o);

  let lastSuppressed: string[] | undefined;
  for (const change of effective) {
    for (const o of change.skuOverrides) {
      const prev = merged.get(o.skuId) ?? { skuId: o.skuId };
      merged.set(o.skuId, mergeSkuOverride(prev, o));
    }
    if (change.suppressedAddOnIds !== undefined) {
      lastSuppressed = change.suppressedAddOnIds;
    }
  }

  return {
    skuOverrides: Array.from(merged.values()),
    suppressedAddOnIds: lastSuppressed,
  };
}

/**
 * Selects the active assignment with the latest `effectiveFrom` (ties broken
 * by id) for deterministic resolution when multiple assignments overlap (e.g.
 * during a vendor cutover when both the outgoing and incoming assignments are
 * briefly active).
 */
function pickAssignment(
  assignments: ServiceAssignment[],
  serviceId: string,
  buildingName: string,
  asOf: Date,
): ServiceAssignment | null {
  const candidates = assignments
    .filter(
      a =>
        a.status === 'Active' &&
        a.serviceId === serviceId &&
        a.buildingName === buildingName &&
        new Date(a.effectiveFrom) <= asOf &&
        (!a.effectiveTo || new Date(a.effectiveTo) >= asOf),
    )
    .sort((a, b) => {
      const t = new Date(b.effectiveFrom).getTime() - new Date(a.effectiveFrom).getTime();
      return t !== 0 ? t : a.id.localeCompare(b.id);
    });
  return candidates[0] ?? null;
}

function pickUnitOverride(
  overrides: UnitPricingOverride[],
  serviceId: string,
  unitId: string,
  buildingName: string,
): UnitPricingOverride | null {
  return (
    overrides.find(
      o =>
        o.serviceId === serviceId &&
        o.unitId === unitId &&
        o.buildingName === buildingName,
    ) ?? null
  );
}

export interface ResolvePricingDeps {
  services: Service[];
  vendors: Vendor[];
  assignments: ServiceAssignment[];
  unitOverrides: UnitPricingOverride[];
}

/**
 * The single accessor every module should use. Composes service defaults +
 * assignment overrides (with scheduled changes) + unit overrides into a
 * resolved view that includes effective per-SKU prices, costs, vendor, and
 * add-on availability.
 */
export function resolvePricing(
  deps: ResolvePricingDeps,
  serviceId: string,
  buildingName: string,
  unitId?: string,
  asOf: Date = new Date(),
): ResolvedPricing | null {
  const service = deps.services.find(s => s.id === serviceId);
  if (!service) return null;

  const assignment = pickAssignment(deps.assignments, serviceId, buildingName, asOf);
  const vendor = assignment?.vendorId
    ? deps.vendors.find(v => v.id === assignment.vendorId) ?? null
    : null;
  const fallbackVendors = (assignment?.fallbackVendorIds ?? [])
    .map(id => deps.vendors.find(v => v.id === id))
    .filter((v): v is Vendor => Boolean(v));

  const assignmentEffective = assignment
    ? applyScheduledChanges(assignment.skuOverrides, assignment.scheduledChanges, asOf)
    : { skuOverrides: [] as SkuOverride[], suppressedAddOnIds: undefined };

  const unitOverride = unitId
    ? pickUnitOverride(deps.unitOverrides, serviceId, unitId, buildingName)
    : null;
  const unitEffective = unitOverride
    ? applyScheduledChanges(unitOverride.skuOverrides, unitOverride.scheduledChanges, asOf)
    : { skuOverrides: [] as SkuOverride[] };

  const suppressedAddOnIds = new Set([
    ...(assignment?.suppressedAddOnIds ?? []),
    ...(assignmentEffective.suppressedAddOnIds ?? []),
  ]);

  const overrideMap = new Map<string, SkuOverride>();
  for (const o of assignmentEffective.skuOverrides) overrideMap.set(o.skuId, o);
  for (const o of unitEffective.skuOverrides) {
    const prev = overrideMap.get(o.skuId) ?? { skuId: o.skuId };
    overrideMap.set(o.skuId, mergeSkuOverride(prev, o));
  }

  const resolvedSkus: ResolvedSku[] = service.skus.map(sku => {
    const ov = overrideMap.get(sku.id);
    const customerExGst =
      ov?.customerPriceExclGst !== undefined
        ? ov.customerPriceExclGst
        : sku.defaultCustomerPriceExclGst;
    // `null` is meaningful here: an explicit clear of vendor cost (Taylr-
    // direct). Only fall back to the service default when override is
    // genuinely `undefined` (not set at this level).
    const vendorExGst: number | null =
      ov?.vendorCostExclGst !== undefined
        ? ov.vendorCostExclGst
        : sku.defaultVendorCostExclGst;
    const available = sku.type === 'base' ? true : !suppressedAddOnIds.has(sku.id);
    return {
      sku,
      customerPriceExclGst: +customerExGst.toFixed(2),
      customerPriceInclGst: applyGst(customerExGst, sku.defaultGstMode),
      vendorCostExclGst: vendorExGst,
      vendorCostInclGst:
        vendorExGst === null ? null : applyGst(vendorExGst, 'plus-gst'),
      available,
    };
  });

  return {
    service,
    resolution: { assignment, vendor, fallbackVendors },
    skus: resolvedSkus,
  };
}

/** Convenience: returns the resolved base SKU price for a service at a
 * location (the most common UI need). */
export function getEffectiveBasePrice(
  deps: ResolvePricingDeps,
  serviceId: string,
  buildingName: string,
  unitId?: string,
  asOf?: Date,
): { exGst: number; incGst: number } | null {
  const r = resolvePricing(deps, serviceId, buildingName, unitId, asOf);
  if (!r) return null;
  const base = r.skus.find(s => s.sku.type === 'base');
  if (!base) return null;
  return { exGst: base.customerPriceExclGst, incGst: base.customerPriceInclGst };
}

/** Convenience: who would be paid for an order placed right now? */
export function getEffectiveBeneficiary(
  deps: ResolvePricingDeps,
  serviceId: string,
  buildingName: string,
  asOf?: Date,
): Vendor | null {
  return resolvePricing(deps, serviceId, buildingName, undefined, asOf)?.resolution.vendor ?? null;
}

// =============================================================================
// SEED DATA
// =============================================================================

// ---------- Vendors -----------------------------------------------------------

export const SEED_VENDORS_V2: Vendor[] = [
  {
    id: 'vendor-vantage-strata',
    name: 'Vantage Strata',
    isStrataPartner: true,
    abn: '49 612 778 209',
    gstRegistered: true,
    email: 'accounts@vantagestrata.com.au',
    phone: '02 6175 0150',
    remittanceCadence: 'monthly',
    payoutMethod: 'bank-transfer',
    bankBsb: '062-902',
    bankAccount: '****4421',
    xeroContactId: 'xc-vantage-strata',
    status: 'Active',
    addedAt: '2024-01-15',
  },
  {
    id: 'vendor-tax-depreciation-australia',
    name: 'Tax Depreciation Australia',
    tradingName: 'TDA',
    abn: '78 154 922 318',
    gstRegistered: true,
    email: 'orders@taxdepreciation.com.au',
    phone: '1300 922 318',
    remittanceCadence: 'daily',
    payoutMethod: 'bank-transfer',
    bankBsb: '082-356',
    bankAccount: '****8810',
    xeroContactId: 'xc-tda',
    piInsurance: {
      insurer: 'Allianz Australia',
      policyNumber: 'PI-AL-44219',
      expiryDate: '2026-09-30',
      coverAmount: 5_000_000,
    },
    status: 'Active',
    addedAt: '2025-08-20',
  },
  {
    id: 'vendor-canberra-antennas',
    name: 'Canberra Antennas',
    abn: '12 345 678 901',
    gstRegistered: true,
    email: 'hello@canberraantennas.com.au',
    phone: '02 6100 9900',
    remittanceCadence: 'fortnightly',
    payoutMethod: 'bank-transfer',
    bankBsb: '062-915',
    bankAccount: '****1192',
    xeroContactId: 'xc-canberra-antennas',
    piInsurance: {
      insurer: 'CGU Insurance',
      policyNumber: 'PI-CGU-77321',
      expiryDate: '2026-06-15',
      coverAmount: 2_000_000,
    },
    status: 'Active',
    addedAt: '2025-09-15',
  },
  {
    id: 'vendor-capital-mounts',
    name: 'Capital Mounts',
    tradingName: 'Capital Mounts & Installs',
    abn: '92 401 877 553',
    gstRegistered: true,
    email: 'jobs@capitalmounts.com.au',
    phone: '02 6100 4477',
    remittanceCadence: 'weekly',
    payoutMethod: 'bank-transfer',
    bankBsb: '012-002',
    bankAccount: '****6633',
    xeroContactId: 'xc-capital-mounts',
    piInsurance: {
      insurer: 'QBE Insurance',
      policyNumber: 'PI-QBE-88112',
      expiryDate: '2027-01-10',
      coverAmount: 2_000_000,
    },
    status: 'Active',
    addedAt: '2026-02-01',
  },
];

// ---------- Services ---------------------------------------------------------

const TVMOUNT_BRACKET_GROUP_ID = 'cg-tvmount-bracket';

export const SEED_SERVICES_V2: Service[] = [
  // S119 Rental Certificate — strata-fulfilled, OC-scoped, single base SKU.
  {
    id: 'svc-s119',
    slug: 's119-rental-certificate',
    name: 'S119 Rental Certificate',
    scope: 'oc',
    pricingAuthority: 'Strata',
    strataCompany: 'Vantage Strata',
    category: 'Compliance',
    description: 'Certificate issued under the Unit Titles (Management) Act 2011 (ACT).',
    skus: [
      {
        id: 'sku-s119-cert',
        name: 'S119 Rental Certificate',
        type: 'base',
        unit: 'per-order',
        defaultCustomerPriceExclGst: 310.91, // $342 incl. GST
        defaultGstMode: 'plus-gst',
        // Taylr collects S119 payments on behalf of Vantage Strata. The
        // entire order amount (less Stripe fees) is remitted to Vantage,
        // so the wholesale cost equals the customer price and Taylr's
        // net margin on each order is $0 by design. The Stripe fee is
        // absorbed by Vantage on settlement, which is reflected in the
        // per-order providerCost in `paymentsSeed.ts` (gross − Stripe).
        defaultVendorCostExclGst: 310.91,
      },
    ],
    choiceGroups: [],
    status: 'Active',
  },

  // Depreciation Report — Taylr-resold, OC-scoped, vendor = TDA.
  {
    id: 'svc-depreciation-report',
    slug: 'depreciation-report',
    name: 'Depreciation Report',
    scope: 'oc',
    pricingAuthority: 'Taylr',
    category: 'Tax & Finance',
    description: 'Tax depreciation report for investment property owners.',
    skus: [
      {
        id: 'sku-depreciation-report',
        name: 'Depreciation Report',
        type: 'base',
        unit: 'per-order',
        defaultCustomerPriceExclGst: 453.64, // $499 incl. GST
        defaultGstMode: 'plus-gst',
        defaultVendorCostExclGst: 220, // $220 + GST = $242 cost to Taylr
      },
    ],
    choiceGroups: [],
    status: 'Active',
  },

  // TV Wall Mount — Taylr-resold, unit-scoped, per-room base + add-ons +
  // bracket choice group. Supports building-level add-on suppression.
  {
    id: 'svc-tv-wall-mount',
    slug: 'tv-wall-mount',
    name: 'TV Wall Mount',
    scope: 'unit',
    pricingAuthority: 'Taylr',
    category: 'Pre-Settlement',
    description: 'Per-room TV wall mounting with bracket choice and optional add-ons.',
    skus: [
      {
        id: 'sku-tvmount-base',
        name: 'TV Wall Mount (per room)',
        type: 'base',
        unit: 'per-room',
        defaultCustomerPriceExclGst: 309.09, // $340 incl. GST
        defaultGstMode: 'plus-gst',
        defaultVendorCostExclGst: 240, // $240 + GST
        requiresPerRoom: true,
        description: 'Mounting service for a single room. Customer must select a bracket.',
      },
      {
        id: 'sku-tvmount-hdmi',
        name: 'HDMI Cable',
        type: 'addon',
        unit: 'per-cable',
        defaultCustomerPriceExclGst: 31.82, // $35 incl. GST
        defaultGstMode: 'plus-gst',
        defaultVendorCostExclGst: 20,
      },
      {
        id: 'sku-tvmount-bracket-tilt',
        name: 'Tilt Bracket',
        type: 'choice-option',
        choiceGroupId: TVMOUNT_BRACKET_GROUP_ID,
        unit: 'per-bracket',
        defaultCustomerPriceExclGst: 0,
        defaultGstMode: 'plus-gst',
        defaultVendorCostExclGst: 0,
      },
      {
        id: 'sku-tvmount-bracket-flat',
        name: 'Flat Bracket',
        type: 'choice-option',
        choiceGroupId: TVMOUNT_BRACKET_GROUP_ID,
        unit: 'per-bracket',
        defaultCustomerPriceExclGst: 0,
        defaultGstMode: 'plus-gst',
        defaultVendorCostExclGst: 0,
      },
      {
        id: 'sku-tvmount-bracket-swivel',
        name: 'Swivel Bracket',
        type: 'choice-option',
        choiceGroupId: TVMOUNT_BRACKET_GROUP_ID,
        unit: 'per-bracket',
        defaultCustomerPriceExclGst: 90.91, // $100 incl. GST
        defaultGstMode: 'plus-gst',
        defaultVendorCostExclGst: 80,
      },
    ],
    choiceGroups: [
      {
        id: TVMOUNT_BRACKET_GROUP_ID,
        name: 'Bracket type',
        isRequired: true,
        allowNoneOption: true, // "I'll bring my own"
        defaultOptionId: 'sku-tvmount-bracket-tilt',
      },
    ],
    questions: [
      {
        id: 'q-tvmount-install-type',
        label: 'Install type for this room',
        perRoom: true,
        isRequired: true,
        defaultOptionId: 'opt-mount-tv-to-bracket',
        options: [
          {
            id: 'opt-mount-tv-to-bracket',
            label: 'Mount my TV to the bracket on the wall',
          },
          {
            id: 'opt-bracket-only',
            label: 'Install bracket only (TV will be hung later by tenant)',
          },
        ],
        helpText:
          'Pick "bracket only" if you are an offsite investor preparing the unit for a tenant who will hang their own TV.',
      },
    ],
    status: 'Active',
  },
];

// ---------- Service Assignments ----------------------------------------------

export const SEED_SERVICE_ASSIGNMENTS_V2: ServiceAssignment[] = [
  // S119 at The Parks — Vantage Strata is beneficiary; no vendor wholesale.
  {
    id: 'asn-s119-parks',
    serviceId: 'svc-s119',
    buildingName: 'The Parks - Stage 2',
    vendorId: 'vendor-vantage-strata',
    fallbackVendorIds: [],
    skuOverrides: [],
    suppressedAddOnIds: [],
    effectiveFrom: '2024-01-15',
    scheduledChanges: [
      // Example future-dated price change (FY27 increase notified by strata).
      {
        id: 'sch-s119-fy27',
        effectiveFrom: '2026-07-01',
        authoredBy: 'Vantage Strata Admin',
        authoredAt: '2026-04-10',
        skuOverrides: [
          { skuId: 'sku-s119-cert', customerPriceExclGst: 327.27 }, // $360 incl
        ],
        note: 'FY27 strata price increase, notified 90 days in advance.',
      },
    ],
    status: 'Active',
  },

  // Depreciation Report at The Parks — TDA fulfils.
  {
    id: 'asn-depreciation-parks',
    serviceId: 'svc-depreciation-report',
    buildingName: 'The Parks - Stage 2',
    vendorId: 'vendor-tax-depreciation-australia',
    fallbackVendorIds: [],
    skuOverrides: [],
    suppressedAddOnIds: [],
    effectiveFrom: '2025-09-01',
    scheduledChanges: [],
    status: 'Active',
  },

  // TV Wall Mount at The Parks — Canberra Antennas, all bracket options
  // available, default pricing.
  {
    id: 'asn-tvmount-parks',
    serviceId: 'svc-tv-wall-mount',
    buildingName: 'The Parks - Stage 2',
    vendorId: 'vendor-canberra-antennas',
    fallbackVendorIds: ['vendor-capital-mounts'],
    skuOverrides: [],
    suppressedAddOnIds: [],
    effectiveFrom: '2025-10-01',
    scheduledChanges: [],
    status: 'Active',
  },

  // TV Wall Mount at Civic Quarter — Capital Mounts, slightly different
  // commercials AND swivel bracket suppressed (wall structure unsuitable).
  {
    id: 'asn-tvmount-civic',
    serviceId: 'svc-tv-wall-mount',
    buildingName: 'Civic Quarter',
    vendorId: 'vendor-capital-mounts',
    fallbackVendorIds: ['vendor-canberra-antennas'],
    skuOverrides: [
      { skuId: 'sku-tvmount-base', customerPriceExclGst: 327.27, vendorCostExclGst: 250 }, // $360 incl, $250 + GST cost
    ],
    suppressedAddOnIds: ['sku-tvmount-bracket-swivel'],
    effectiveFrom: '2026-02-01',
    scheduledChanges: [],
    status: 'Active',
  },
];

// ---------- Per-unit pricing overrides ---------------------------------------

export const SEED_UNIT_PRICING_OVERRIDES_V2: UnitPricingOverride[] = [];

// ---------- Coupons ----------------------------------------------------------

export const SEED_COUPONS_V2: Coupon[] = [
  // The Parks — $50 off S119 for new welcome promo, fixed-date.
  {
    id: 'coupon-welcome-parks-s119',
    code: 'WELCOME-PARKS',
    serviceId: 'svc-s119',
    scope: 'building',
    targetId: 'The Parks - Stage 2',
    discountType: 'flat-amount',
    discountAmount: 50,
    appliesTo: 'all-skus',
    maxDiscountCap: null,
    validFrom: '2026-01-01',
    expiryTrigger: 'fixed-date',
    validUntil: '2026-06-30',
    maxRedemptions: null,
    singleUsePerOC: true,
    usedCount: 0,
    status: 'Active',
  },
  // Depreciation Report — $100 off for newly-established OCs at The Parks,
  // 60 days from first owner activation. Auto-attaches to every new OC at
  // that building.
  {
    id: 'coupon-depreciation-newoc-parks',
    code: 'NEWOC-DEP-PARKS',
    serviceId: 'svc-depreciation-report',
    scope: 'oc',
    discountType: 'flat-amount',
    discountAmount: 100,
    appliesTo: 'all-skus',
    maxDiscountCap: null,
    validFrom: '2026-01-01',
    expiryTrigger: 'days-from-first-activation',
    daysFromActivation: 60,
    autoAttachToNewOcsAtBuilding: 'The Parks - Stage 2',
    maxRedemptions: null,
    singleUsePerOC: true,
    usedCount: 0,
    status: 'Active',
  },
  // TV Wall Mount — 20% off the mount portion (NOT add-ons), targeted at a
  // specific unit, suppressed if the unit already has a TV mount installed.
  {
    id: 'coupon-tvmount-unit-promo',
    code: 'TV-MOUNT-20',
    serviceId: 'svc-tv-wall-mount',
    scope: 'unit',
    targetId: 'unit-parks-14-4-lady-nelson',
    discountType: 'percentage',
    discountAmount: 20,
    appliesTo: 'base-only',
    maxDiscountCap: null,
    validFrom: '2026-03-01',
    expiryTrigger: 'fixed-date',
    validUntil: '2026-09-30',
    suppressIfUnitHasServiceId: 'svc-tv-wall-mount',
    maxRedemptions: 1,
    singleUsePerOC: false,
    usedCount: 0,
    status: 'Active',
  },
];

// ---------------------------------------------------------------------------
// Bundled deps for convenient resolver consumption
// ---------------------------------------------------------------------------

export const PRICING_DEPS: ResolvePricingDeps = {
  services: SEED_SERVICES_V2,
  vendors: SEED_VENDORS_V2,
  assignments: SEED_SERVICE_ASSIGNMENTS_V2,
  unitOverrides: SEED_UNIT_PRICING_OVERRIDES_V2,
};
