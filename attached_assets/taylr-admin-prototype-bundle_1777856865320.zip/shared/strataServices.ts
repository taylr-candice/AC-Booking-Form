export type FulfilmentMode = 'A' | 'B';

export interface StrataCompanyServices {
  strataCompany: string;
  partnered: boolean;
  s119Rental: boolean;
  s119RentalPrice: number;
  s119FulfilmentMode?: FulfilmentMode;
  s119Sales: boolean;
  s115: boolean;
  onboardingFlow: boolean;
  keys: boolean;
}

const strataServicesMap: Record<string, StrataCompanyServices> = {
  'Vantage Strata': {
    strataCompany: 'Vantage Strata',
    partnered: true,
    s119Rental: true,
    s119RentalPrice: 342,
    s119FulfilmentMode: 'A',
    s119Sales: true,
    s115: false,
    onboardingFlow: true,
    keys: false,
  },
};

export function getStrataServices(strataCompany: string): StrataCompanyServices {
  return strataServicesMap[strataCompany] ?? {
    strataCompany,
    partnered: false,
    s119Rental: false,
    s119RentalPrice: 0,
    s119Sales: false,
    s115: false,
    onboardingFlow: false,
    keys: false,
  };
}

// ---------------------------------------------------------------------------
// S119 Rental availability — single source of truth.
//
// S119 Rental is a service Taylr performs *on behalf of* the appointed strata.
// It is therefore only available for a building when ALL of:
//   1. the building has a current strata assigned (`strataId` is set), AND
//   2. that strata is a Taylr partner (`strata.isPartner === true`), AND
//   3. that partner has explicitly enabled S119 Rental in their service config
//      (`strataServicesMap[strataName].s119Rental === true`).
//
// When unavailable, agents/OCs cannot order or pay for an S119 cert — the UI
// must render the service as Unavailable (not "Paused", which implies a
// temporary, recoverable state).
// ---------------------------------------------------------------------------

/**
 * Returns true if a service row's name refers to S119 Rental in any of its
 * known forms across the codebase ("S119", "S119 Rental", "S119 Rental
 * Certificate(s)", etc.). Centralised so callers don't drift.
 */
export function isS119RentalServiceName(name: string | undefined): boolean {
  if (!name) return false;
  return /\bs119\b/i.test(name);
}

export function isS119RentalAvailableForStrata(strataName: string | undefined): boolean {
  if (!strataName) return false;
  const cfg = strataServicesMap[strataName];
  if (!cfg) return false;
  return cfg.partnered === true && cfg.s119Rental === true;
}

export function isS119RentalAvailableForBuilding(
  building: { strataId: string },
  strata: { name: string; isPartner: boolean } | undefined,
): boolean {
  if (!building.strataId || !strata) return false;
  if (!strata.isPartner) return false;
  return isS119RentalAvailableForStrata(strata.name);
}

/** Why is S119 Rental not available? Returns null if it IS available. */
export function s119UnavailableReason(
  building: { strataId: string },
  strata: { name: string; isPartner: boolean } | undefined,
): string | null {
  if (!building.strataId || !strata) return 'No strata is currently assigned to this building.';
  if (!strata.isPartner) return `${strata.name} is not a Taylr partner.`;
  if (!isS119RentalAvailableForStrata(strata.name)) return `${strata.name} has not engaged Taylr to perform S119 Rental.`;
  return null;
}
