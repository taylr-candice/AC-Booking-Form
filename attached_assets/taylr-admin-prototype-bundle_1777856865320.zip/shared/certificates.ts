import { s119Orders, type S119Order } from './s119OrdersSeed';
import { parseS119Date, computeS119Expiry } from './logic/health';
import { isUpStrataLost } from './portfolioSeed';

/**
 * Service-agnostic certificate model. The Sales Orders module is the
 * transactional ledger; this module is the operational register that strata
 * managers use to track certificate state. Today the only producer is the
 * S119 Rental service, but the model deliberately leaves room for additional
 * certificate types (e.g. Section 109/151 disclosure, insurance certificates)
 * to drop in without further table changes.
 */
export type CertificateServiceType = 'S119 Rental';

export type CertificateStatus =
  | 'Pending Payment'      // Order placed, payment not yet received.
  | 'Pending Issue'        // Paid, awaiting certificate issuance.
  | 'Issued'               // Issued and currently valid.
  | 'Expiring Soon'        // Issued, within EXPIRING_SOON_DAYS of expiry.
  | 'Expired'              // Past expiry on a still-active OC.
  | 'Archived (OC closed)' // Cascade: the OC the cert was issued under was archived.
  | 'Voided';              // Cascade: pending-payment order whose OC archived (e.g. strata lost management) before payment landed.

export interface Certificate {
  id: string;
  serviceType: CertificateServiceType;
  // OC / property binding
  ocId: string;
  ocOwnerLabel: string;
  ocStatus: 'Active' | 'Archived';
  ocArchivedAt?: string;
  buildingName: string;
  upNumber: number;
  propertyAddress: string;
  // Customer
  ownerDetails: string;
  orderedBy: 'Agent' | 'Owner';
  managingAgent: string | null;
  email: string;
  // Lifecycle
  orderDate: string;
  paymentDate: string | null;
  issueDate: string | null;
  expiryDate: string | null;
  status: CertificateStatus;
  daysRemaining: number | null;
  // Cross-link to the originating order in the Sales Orders ledger.
  sourceOrderId: string;
}

export const EXPIRING_SOON_DAYS = 30;

interface CertificateLifecycle {
  status: CertificateStatus;
  issueDate: string | null;
  expiryDate: string | null;
  daysRemaining: number | null;
  ocArchivedAt?: string;
}

/**
 * Computes a certificate's runtime status from its source S119 order. Honours:
 *   - payment state (Pending Payment vs Pending Issue vs Issued)
 *   - OC archival cascade (overrides an otherwise-valid cert)
 *   - 5y expiry from issue date, with an Expiring Soon window
 */
export function deriveCertificateStatus(order: S119Order, now: Date = new Date()): CertificateLifecycle {
  if (order.paymentStatus === 'Pending') {
    // Cascade: a pending-payment order voids when the underlying
    // appointment can no longer settle it. Two paths trigger this:
    //   1. The OC itself has archived (e.g. ownership turned over).
    //   2. The strata company appointed to the building is no longer
    //      appointed — derived live from the building's relationshipStatus
    //      so a single source of truth (portfolioSeed) drives the cascade
    //      across Strata / Buildings / Units / Sales Orders / Certificates.
    if (order.ocStatus === 'Archived' || isUpStrataLost(order.upNumber)) {
      return {
        status: 'Voided',
        issueDate: null,
        expiryDate: null,
        daysRemaining: null,
        ocArchivedAt: order.ocArchivedAt,
      };
    }
    return { status: 'Pending Payment', issueDate: null, expiryDate: null, daysRemaining: null };
  }
  if (order.certStatus !== 'Completed and Issued') {
    // Paid but not yet issued by the strata manager.
    return { status: 'Pending Issue', issueDate: null, expiryDate: null, daysRemaining: null };
  }

  const issueDate = order.issueDate ?? order.paymentDate ?? null;
  const expiryDate = issueDate ? computeS119Expiry(issueDate) : null;

  if (order.ocStatus === 'Archived') {
    return {
      status: 'Archived (OC closed)',
      issueDate,
      expiryDate,
      daysRemaining: null,
      ocArchivedAt: order.ocArchivedAt,
    };
  }

  const exp = parseS119Date(expiryDate ?? undefined);
  if (!exp) return { status: 'Issued', issueDate, expiryDate, daysRemaining: null };

  const ms = exp.getTime() - now.getTime();
  const daysRemaining = Math.round(ms / (1000 * 60 * 60 * 24));
  if (ms < 0) return { status: 'Expired', issueDate, expiryDate, daysRemaining };
  if (daysRemaining <= EXPIRING_SOON_DAYS) {
    return { status: 'Expiring Soon', issueDate, expiryDate, daysRemaining };
  }
  return { status: 'Issued', issueDate, expiryDate, daysRemaining };
}

export function buildCertificateFromS119(order: S119Order, now: Date = new Date()): Certificate {
  const d = deriveCertificateStatus(order, now);
  return {
    id: order.orderId,
    serviceType: 'S119 Rental',
    ocId: order.ocId,
    ocOwnerLabel: order.ocOwnerLabel,
    ocStatus: order.ocStatus,
    ocArchivedAt: order.ocArchivedAt ?? d.ocArchivedAt,
    buildingName: order.buildingName,
    upNumber: order.upNumber,
    propertyAddress: order.propertyAddress,
    ownerDetails: order.ownerDetails,
    orderedBy: order.orderedBy,
    managingAgent: order.managingAgent,
    email: order.email,
    orderDate: order.orderDate,
    paymentDate: order.paymentDate,
    issueDate: d.issueDate,
    expiryDate: d.expiryDate,
    status: d.status,
    daysRemaining: d.daysRemaining,
    sourceOrderId: order.orderId,
  };
}

export function getCertificates(now: Date = new Date()): Certificate[] {
  return s119Orders.map(o => buildCertificateFromS119(o, now));
}

export type EffectivePaymentStatus = 'Paid' | 'Pending' | 'Voided';

/**
 * Single source of truth for "what status should a customer / staff member
 * see for this order's payment right now". The raw paymentStatus on the seed
 * stays as 'Pending' for orders that were placed before the cascade — this
 * helper rolls them up to 'Voided' when:
 *   - the OC has been archived (e.g. ownership turned over), or
 *   - the building's strata appointment has ended (Expired Lost / Unassigned).
 *
 * Implication: the payment link for any order returning 'Voided' MUST be
 * refused in any payment surface (admin, customer email link, hosted invoice).
 */
export function getEffectivePaymentStatus(order: S119Order): EffectivePaymentStatus {
  if (order.paymentStatus === 'Pending' && (order.ocStatus === 'Archived' || isUpStrataLost(order.upNumber))) {
    return 'Voided';
  }
  return order.paymentStatus;
}

/**
 * Whether an order can currently progress to payment. Used to gate any
 * "Pay now" / hosted-invoice CTA. Returns false the moment the strata
 * appointment ends or the OC archives, regardless of whether the underlying
 * paymentStatus on the seed has been updated.
 */
export function canOrderBePaid(order: S119Order): boolean {
  return getEffectivePaymentStatus(order) === 'Pending';
}

/**
 * Statuses for which a downloadable certificate PDF is expected to exist.
 * Pending Payment / Pending Issue / Voided certs have no attachment by design
 * — the strata partner only uploads once they're ready to issue, which is
 * exactly the transition from Pending Issue → Issued.
 */
export const ATTACHED_CERT_STATUSES: readonly CertificateStatus[] = [
  'Issued',
  'Expiring Soon',
  'Expired',
  'Archived (OC closed)',
] as const;

export function shouldHaveAttachment(status: CertificateStatus): boolean {
  return (ATTACHED_CERT_STATUSES as readonly CertificateStatus[]).includes(status);
}

/**
 * Apply an uploaded-attachment override on top of a derived certificate.
 * The strata partner uploading the PDF is the act that transitions a cert
 * from "Pending Issue" → "Issued" (with the upload timestamp becoming the
 * issue date, and expiry computed +5 years). Pure function — caller passes
 * the attachment timestamp resolved from whichever store holds uploads.
 */
export function applyAttachmentToCertificate(
  cert: Certificate,
  uploadedAt: string | null | undefined,
  now: Date = new Date(),
): Certificate {
  if (!uploadedAt) return cert;
  if (cert.status !== 'Pending Issue') return cert;
  const expiryDate = computeS119Expiry(uploadedAt);
  const exp = parseS119Date(expiryDate ?? undefined);
  let status: CertificateStatus = 'Issued';
  let daysRemaining: number | null = null;
  if (exp) {
    const ms = exp.getTime() - now.getTime();
    daysRemaining = Math.round(ms / (1000 * 60 * 60 * 24));
    if (ms < 0) status = 'Expired';
    else if (daysRemaining <= EXPIRING_SOON_DAYS) status = 'Expiring Soon';
  }
  return { ...cert, status, issueDate: uploadedAt, expiryDate, daysRemaining };
}
