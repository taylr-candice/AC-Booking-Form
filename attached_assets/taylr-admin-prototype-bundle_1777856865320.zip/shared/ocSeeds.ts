import type { Contact, TenancyState, TenancyStatus, S119Service, OwnershipCard } from "./schema";
import { defaultContacts, defaultTenancy, defaultS119Rental, defaultOwnershipCard } from "./seed";
import { ocListData } from "./ocListSeed";

interface OCSeed {
  contacts: Contact[];
  tenancy: TenancyState;
  s119Rental: S119Service;
  ownershipCard: OwnershipCard;
}

const seedMap: Record<string, OCSeed> = {};

const validTenancyStatuses: TenancyStatus[] = ['Active', 'Unknown', 'Missing Tenancy', 'Expired', 'Ended', 'Not Applicable'];

function mapTenancyStatus(status: string): TenancyStatus {
  if (validTenancyStatuses.includes(status as TenancyStatus)) return status as TenancyStatus;
  if (status === 'Owner Occupied') return 'Not Applicable';
  return 'Unknown';
}

function generateSeedFromListData(ocId: string): OCSeed | null {
  const listItem = ocListData.find(oc => oc.id === ocId);
  if (!listItem) return null;

  const contacts: Contact[] = (listItem.detail.contacts || []).map((c, i) => ({
    id: `${ocId}-c${i + 1}`,
    name: c.name,
    role: c.role,
    email: c.email || '',
    phone: c.phone || '',
    authorised: c.authorised !== undefined ? c.authorised : true,
    access: c.access || 'Not Started',
    sources: [c.source || 'Strata'],
    isArchived: false,
    hasConflict: false,
    onboarded: c.verified === true,
    verified: c.verified === true,
    history: [],
    emails: [],
  }));

  const tenancy: TenancyState = {
    status: mapTenancyStatus(listItem.tenancyStatus),
    version: 1,
    history: [],
    tenantIds: [],
  };

  const s119Rental: S119Service = {
    status: listItem.s119Status === 'N/A' ? 'Unknown' : (listItem.s119Status || 'Unknown'),
    isLocked: false,
    history: [],
    emailLog: [],
    ...(listItem.detail.s119 ? {
      issueDate: listItem.detail.s119.issueDate || undefined,
      expiryDate: listItem.detail.s119.expiryDate || undefined,
    } : {}),
  };

  const ownershipCard: OwnershipCard = {
    settlementDate: listItem.settlementDate,
    purchasePrice: listItem.detail.purchasePrice,
    namePerTitle: listItem.ownerNames.join(' & '),
    taylrId: listItem.taylrId,
    originKey: `PIQ-${listItem.taylrId}-AUTO`,
    originFingerprint: `PIQ_OC_FPR:${listItem.upNumber}:auto_${ocId}`,
  };

  return { contacts, tenancy, s119Rental, ownershipCard };
}

export function getOCSeedOrDefault(ocId: string): OCSeed {
  if (seedMap[ocId]) return seedMap[ocId];

  const generated = generateSeedFromListData(ocId);
  if (generated) return generated;

  return {
    contacts: defaultContacts,
    tenancy: defaultTenancy,
    s119Rental: defaultS119Rental,
    ownershipCard: defaultOwnershipCard,
  };
}
