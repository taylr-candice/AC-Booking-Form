import type { Contact } from "./schema";
import { isContactVerified } from "./logic/contacts";

export interface EnrichmentStats {
  totalContacts: number;
  totalVerified: number;
  piqImported: number;
  piqVerified: number;
  piqEnriched: number;
  taylrDiscovered: number;
  taylrDiscoveredVerified: number;
}

export function computeEnrichmentStats(contacts: Contact[]): EnrichmentStats {
  let totalContacts = 0;
  let totalVerified = 0;
  let piqImported = 0;
  let piqVerified = 0;
  let piqEnriched = 0;
  let taylrDiscovered = 0;
  let taylrDiscoveredVerified = 0;

  for (const c of contacts) {
    if (c.isArchived) continue;
    totalContacts++;
    const verified = isContactVerified(c);
    if (verified) totalVerified++;

    const isFromPIQ = c.sources.includes('Strata');
    if (isFromPIQ) {
      piqImported++;
      if (verified) piqVerified++;
      if (c.onboarded && c.originalData) piqEnriched++;
    } else {
      taylrDiscovered++;
      if (verified) taylrDiscoveredVerified++;
    }
  }

  return { totalContacts, totalVerified, piqImported, piqVerified, piqEnriched, taylrDiscovered, taylrDiscoveredVerified };
}

export function enrichmentPct(numerator: number, denominator: number): number {
  return denominator > 0 ? Math.round((numerator / denominator) * 100) : 0;
}
