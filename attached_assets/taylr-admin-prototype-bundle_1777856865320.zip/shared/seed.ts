import type { Contact, TenancyState, S119Service, OwnershipCard } from "./schema";

export const defaultContacts: Contact[] = [];

export const defaultTenancy: TenancyState = {
  status: 'Unknown',
  version: 1,
  history: [],
  tenantIds: []
};

export const defaultS119Rental: S119Service = {
  status: 'Not Applicable',
  isLocked: false,
  history: [],
  emailLog: [],
};

export const defaultOwnershipCard: OwnershipCard = {
  settlementDate: '',
  purchasePrice: '',
  saleDate: '',
  salePrice: '',
  namePerTitle: '',
  taylrId: '',
  originKey: '',
  originFingerprint: ''
};
