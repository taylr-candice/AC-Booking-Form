export interface FlowStepRoleContent {
  role: string;
  subject: string;
  summary: string;
}

export interface OnboardingFlowStep {
  stepNumber: number;
  emailType: string;
  label: string;
  delayLabel: string;
  roleContent: FlowStepRoleContent[];
}

export interface StrataOnboardingFlow {
  strataCompany: string;
  description: string;
  totalSteps: number;
  estimatedDuration: string;
  steps: OnboardingFlowStep[];
}

const vantageStrataFlow: StrataOnboardingFlow = {
  strataCompany: 'Vantage Strata',
  description: 'Full onboarding sequence with Resvu portal sync and building-specific compliance emails.',
  totalSteps: 6,
  estimatedDuration: '14 days',
  steps: [
    {
      stepNumber: 1,
      emailType: 'Strata Welcome',
      label: 'Vantage Welcome',
      delayLabel: 'Immediate',
      roleContent: [
        { role: 'Owner', subject: 'Welcome to The Pier — Your Ownership Card is Ready', summary: 'Introduces the owner to the building, confirms their lot details, strata levy schedule, and provides the Vantage Strata contact for their building manager. Includes a link to confirm their role (Owner Occupier or Offsite Investor).' },
        { role: 'Owner Occupier', subject: 'Welcome Home to The Pier — Your Owner Occupier Dashboard', summary: 'Welcomes the owner occupier, confirms unit and lot details, strata levy information, building rules summary, and Vantage Strata building manager contact. Links to community noticeboard.' },
        { role: 'Offsite Investor', subject: 'Welcome to The Pier — Your Investment Property Dashboard', summary: 'Confirms investment property details, strata levy schedule, and links to appoint or update their managing agent. Includes Vantage Strata contact details.' },
        { role: 'Tenant', subject: 'Welcome to The Pier — Important Information for Your Tenancy', summary: 'Welcome message with building rules, move-in procedures, parking and storage information, waste collection schedule, and emergency contacts for the building manager.' },
        { role: 'Household Member', subject: 'Welcome to The Pier — Building Access & Information', summary: 'Simplified welcome with building access info, emergency contacts, waste schedule, and community noticeboard link. Does not include financial or ownership details.' },
        { role: 'Managing Agent', subject: 'Vantage Strata — Agent Registration Confirmed for The Pier', summary: 'Confirms agent registration for the specific unit, provides strata manager contact, levy payment details, and links to the agent portal for managing tenancy records.' },
      ],
    },
    {
      stepNumber: 2,
      emailType: 'Taylr Intro',
      label: 'Taylr Intro',
      delayLabel: 'Day 1',
      roleContent: [
        { role: 'Owner', subject: 'Your Taylr Dashboard — Manage Your Property in One Place', summary: 'Introduces the Taylr platform, explains the ownership card concept, and prompts the owner to complete onboarding by confirming their relationship with the unit (Owner Occupier or Offsite Investor). Links to set up their Taylr account.' },
        { role: 'Owner Occupier', subject: 'Your Taylr Dashboard — Everything About Your Home', summary: 'Shows how to use Taylr for S119 Rental Certificates, building notices, maintenance requests, and accessing strata documents. Includes a prompt to set up their profile.' },
        { role: 'Offsite Investor', subject: 'Your Taylr Dashboard — Track Your Investment Property', summary: 'Highlights agent management, S119 tracking, tenancy overview, and document access. Prompts to confirm managing agent details or appoint a new agent.' },
        { role: 'Tenant', subject: 'Your Taylr Account — Access Building Information & Services', summary: 'Explains the tenant dashboard, how to access building documents, submit maintenance requests, and view community notices. Links to complete profile setup.' },
        { role: 'Household Member', subject: 'Your Taylr Account — Building Access & Community', summary: 'Simplified intro to Taylr for household members — community noticeboard, building contacts, and maintenance request submission.' },
        { role: 'Managing Agent', subject: 'Taylr Agent Portal — Manage Your Properties', summary: 'Full overview of agent portal features: tenancy management, lease uploads, tenant onboarding, S119 ordering, and communication tools. Links to set up API integration.' },
      ],
    },
    {
      stepNumber: 3,
      emailType: 'Resvu Sync',
      label: 'Resvu Sync',
      delayLabel: 'Day 1',
      roleContent: [
        { role: 'Owner', subject: 'Resvu Portal — Your Strata Documents Are Ready', summary: 'Explains the Resvu portal sync, confirms their MxU (owner portal) account has been provisioned, and provides login instructions. Includes a link to access strata meeting minutes, financials, and maintenance schedules.' },
        { role: 'Owner Occupier', subject: 'Resvu Portal — Access Your Strata Records', summary: 'MxU portal access confirmed. Links to strata financials, meeting agendas, maintenance logs, and building insurance certificate.' },
        { role: 'Offsite Investor', subject: 'Resvu Portal — Your Investment Property Strata Records', summary: 'MxU portal access confirmed with focus on financial reports, levy statements, and building insurance. Includes notification preferences for investment-relevant updates.' },
        { role: 'Tenant', subject: 'Resvu Portal — Access Your Building Documents', summary: 'Confirms tenant portal (Resvu) access for viewing building rules, community notices, and submitting maintenance requests through the strata system.' },
        { role: 'Managing Agent', subject: 'Resvu Agent Sync — Strata Records Connected', summary: 'Confirms agent portal is synced with Resvu. Access to levy status, meeting minutes, building maintenance schedules, and insurance certificates for managed properties.' },
      ],
    },
    {
      stepNumber: 4,
      emailType: 'Resvu Intro',
      label: 'Resvu Intro',
      delayLabel: 'Day 2',
      roleContent: [
        { role: 'Owner', subject: 'Getting Started with Resvu — A Quick Guide', summary: 'Step-by-step guide to navigating the Resvu owner portal: viewing levy statements, accessing meeting documents, reviewing insurance certificates, and setting notification preferences.' },
        { role: 'Owner Occupier', subject: 'Getting Started with Resvu — Your Owner Guide', summary: 'Walkthrough of Resvu features relevant to owner occupiers: maintenance requests, community forums, AGM voting, and document library.' },
        { role: 'Offsite Investor', subject: 'Getting Started with Resvu — Investor Quick Start', summary: 'Focused guide for offsite investors: financial dashboards, levy payment tracking, building maintenance reports, and delegation to managing agents.' },
        { role: 'Tenant', subject: 'Getting Started with Resvu — Your Tenant Guide', summary: 'Guide to using the tenant view: community updates, maintenance request tracking, building rules reference, and emergency contact information.' },
        { role: 'Managing Agent', subject: 'Getting Started with Resvu — Agent Portal Guide', summary: 'Full agent guide: managing multiple properties, accessing strata records, coordinating with building managers, and using the API for automated syncing.' },
      ],
    },
    {
      stepNumber: 5,
      emailType: 'Waste Management',
      label: 'Waste Management',
      delayLabel: 'Day 5',
      roleContent: [
        { role: 'Owner Occupier', subject: 'The Pier — Waste & Recycling Guide', summary: 'Building-specific waste collection schedule, bin room locations, recycling instructions, and bulk waste booking process. Includes the Vantage Strata sustainability initiative details.' },
        { role: 'Tenant', subject: 'The Pier — Your Waste & Recycling Guide', summary: 'Waste collection days, bin room access instructions, recycling guidelines, and how to book bulk waste collection through building management. Includes move-out waste procedures.' },
        { role: 'Household Member', subject: 'The Pier — Waste & Recycling Quick Reference', summary: 'Simplified waste and recycling guide with collection days, bin room location, and basic sorting instructions.' },
        { role: 'Offsite Investor', subject: 'The Pier — Building Waste Management Summary', summary: 'Overview of waste management arrangements for the building, included in strata levies. Useful for communicating to tenants or agents.' },
        { role: 'Managing Agent', subject: 'The Pier — Waste Management Procedures for Agents', summary: 'Waste management schedule and procedures to share with tenants during onboarding. Includes bulk waste booking process and building manager contacts for waste-related issues.' },
      ],
    },
    {
      stepNumber: 6,
      emailType: 'Insurance',
      label: 'Insurance',
      delayLabel: 'Day 7',
      roleContent: [
        { role: 'Owner', subject: 'The Pier — Building Insurance & Your Obligations', summary: 'Explains the building\'s strata insurance coverage, what is and isn\'t covered, and the owner\'s responsibility for contents and landlord insurance. Includes the current certificate of currency and renewal date.' },
        { role: 'Owner Occupier', subject: 'The Pier — Your Home Insurance Guide', summary: 'Strata insurance coverage summary, what\'s included vs what the owner needs separately (contents insurance), how to make a claim, and the current policy renewal date.' },
        { role: 'Offsite Investor', subject: 'The Pier — Insurance for Your Investment Property', summary: 'Building insurance overview, landlord insurance recommendations, liability coverage details, and how insurance costs are reflected in strata levies. Current certificate of currency attached.' },
        { role: 'Tenant', subject: 'The Pier — Building Insurance & Contents Cover', summary: 'Explains what the building insurance covers (structure), what the tenant should arrange (contents insurance), and how to report damage or make a claim through building management.' },
        { role: 'Managing Agent', subject: 'The Pier — Insurance Documentation for Agents', summary: 'Building insurance certificate of currency, coverage summary, excess amounts, and claims process. Useful for tenancy applications and property management compliance.' },
      ],
    },
  ],
};

const strataCommunityManagementFlow: StrataOnboardingFlow = {
  strataCompany: 'Strata Community Management',
  description: 'Streamlined onboarding with Resvu integration and compliance-focused follow-ups.',
  totalSteps: 5,
  estimatedDuration: '10 days',
  steps: [
    {
      stepNumber: 1,
      emailType: 'Strata Welcome',
      label: 'SCM Welcome',
      delayLabel: 'Immediate',
      roleContent: [
        { role: 'Owner', subject: 'Welcome — Your Strata Community Management Portal', summary: 'Introduces the owner to their building under SCM management, confirms lot details and levy schedule, and provides their designated strata manager contact.' },
        { role: 'Tenant', subject: 'Welcome — Important Building Information', summary: 'Building rules, move-in procedures, emergency contacts, and parking/storage details for the building under SCM management.' },
        { role: 'Managing Agent', subject: 'SCM Agent Registration — Building Access Confirmed', summary: 'Confirms agent registration, provides strata manager contact, and links to the agent portal for managing tenancy records.' },
      ],
    },
    {
      stepNumber: 2,
      emailType: 'Taylr Intro',
      label: 'Taylr Intro',
      delayLabel: 'Day 1',
      roleContent: [
        { role: 'Owner', subject: 'Your Taylr Dashboard — Property Management Made Simple', summary: 'Introduces the Taylr platform for owners under SCM-managed buildings. Covers ownership card, S119 tracking, and agent management.' },
        { role: 'Tenant', subject: 'Your Taylr Account — Building Services & Information', summary: 'Explains the tenant dashboard for accessing building documents, maintenance requests, and community notices.' },
        { role: 'Managing Agent', subject: 'Taylr Agent Portal — SCM Buildings', summary: 'Agent portal overview for SCM-managed properties: tenancy management, lease uploads, and S119 ordering.' },
      ],
    },
    {
      stepNumber: 3,
      emailType: 'Resvu Sync',
      label: 'Resvu Sync',
      delayLabel: 'Day 1',
      roleContent: [
        { role: 'Owner', subject: 'Resvu Portal — Your Strata Documents Are Ready', summary: 'MxU portal access confirmed. Links to strata financials, meeting agendas, and building insurance.' },
        { role: 'Managing Agent', subject: 'Resvu Agent Sync — SCM Records Connected', summary: 'Agent portal synced with Resvu for SCM buildings. Access to levy status and maintenance schedules.' },
      ],
    },
    {
      stepNumber: 4,
      emailType: 'Resvu Intro',
      label: 'Resvu Intro',
      delayLabel: 'Day 2',
      roleContent: [
        { role: 'Owner', subject: 'Getting Started with Resvu — SCM Owner Guide', summary: 'Step-by-step guide to the Resvu portal for SCM-managed buildings.' },
        { role: 'Managing Agent', subject: 'Getting Started with Resvu — Agent Quick Start', summary: 'Agent-focused Resvu guide for SCM properties.' },
      ],
    },
    {
      stepNumber: 5,
      emailType: 'Insurance',
      label: 'Insurance',
      delayLabel: 'Day 5',
      roleContent: [
        { role: 'Owner', subject: 'Building Insurance — Coverage & Obligations', summary: 'Building insurance summary, owner responsibilities, and current certificate of currency for the SCM-managed building.' },
        { role: 'Tenant', subject: 'Building Insurance — What You Need to Know', summary: 'Building insurance overview and recommendation to arrange contents insurance.' },
        { role: 'Managing Agent', subject: 'Insurance Documentation — SCM Buildings', summary: 'Certificate of currency and coverage details for compliance purposes.' },
      ],
    },
  ],
};

const capitalStrataFlow: StrataOnboardingFlow = {
  strataCompany: 'Capital Strata',
  description: 'Compact onboarding flow for Civic Quarter and Northbourne Ave properties.',
  totalSteps: 4,
  estimatedDuration: '7 days',
  steps: [
    {
      stepNumber: 1,
      emailType: 'Strata Welcome',
      label: 'Capital Strata Welcome',
      delayLabel: 'Immediate',
      roleContent: [
        { role: 'Owner', subject: 'Welcome to Capital Strata — Your Property Dashboard', summary: 'Introduces the owner to their Capital Strata-managed building, confirms lot details, levy schedule, and provides their strata manager contact.' },
        { role: 'Tenant', subject: 'Welcome — Building Information & Access', summary: 'Building rules, access procedures, emergency contacts, and key building services for Capital Strata properties.' },
        { role: 'Managing Agent', subject: 'Capital Strata — Agent Portal Access', summary: 'Agent registration confirmed with strata manager contacts and portal access details.' },
      ],
    },
    {
      stepNumber: 2,
      emailType: 'Taylr Intro',
      label: 'Taylr Intro',
      delayLabel: 'Day 1',
      roleContent: [
        { role: 'Owner', subject: 'Taylr — Manage Your Capital Strata Property', summary: 'Taylr platform introduction for Capital Strata owners. Ownership card, S119 management, and document access.' },
        { role: 'Tenant', subject: 'Taylr — Your Building Services Portal', summary: 'Tenant dashboard overview for Capital Strata properties.' },
        { role: 'Managing Agent', subject: 'Taylr Agent Portal — Capital Strata Properties', summary: 'Agent portal features for Capital Strata buildings.' },
      ],
    },
    {
      stepNumber: 3,
      emailType: 'Resvu Sync',
      label: 'Resvu Sync',
      delayLabel: 'Day 1',
      roleContent: [
        { role: 'Owner', subject: 'Resvu — Your Strata Records Are Synced', summary: 'MxU access confirmed for Capital Strata buildings.' },
        { role: 'Managing Agent', subject: 'Resvu Agent Sync — Capital Strata', summary: 'Agent Resvu access synced for Capital Strata properties.' },
      ],
    },
    {
      stepNumber: 4,
      emailType: 'Resvu Intro',
      label: 'Resvu Intro',
      delayLabel: 'Day 3',
      roleContent: [
        { role: 'Owner', subject: 'Getting Started with Resvu', summary: 'Quick start guide for the Resvu owner portal.' },
        { role: 'Managing Agent', subject: 'Resvu Agent Guide', summary: 'Agent-focused Resvu overview.' },
      ],
    },
  ],
};

const flowMap: Record<string, StrataOnboardingFlow> = {
  'Vantage Strata': vantageStrataFlow,
  'Strata Community Management': strataCommunityManagementFlow,
  'Capital Strata': capitalStrataFlow,
};

export function getOnboardingFlow(strataCompany: string): StrataOnboardingFlow | undefined {
  return flowMap[strataCompany];
}
