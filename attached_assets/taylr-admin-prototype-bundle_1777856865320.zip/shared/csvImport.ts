/**
 * CSV import helpers for the OC import simulation (Vantage PIQ daily feed).
 *
 * Real PIQ export header (column letters → meaning we use):
 *   A  S/Plan         → strata plan number, matches Building.upNumber (digits-only)
 *   B  Building Name  → ignored (we use the linked Building.name)
 *   C  Street No      → ignored for resolution; used as fallback display
 *   D  Street Name    → ignored for resolution; used as fallback display
 *   E  Lot#           → required, matches Unit.lot for the resolved building
 *   F  Unit#          → ignored (Unit.name comes from the units module)
 *   G  Agent Id       → ignored
 *   H  Index          → ignored
 *   I  Name           → required, "name per title" (used to infer structure + names)
 *   J–O Phone fields  → ignored (collected at member onboarding)
 *   P  Email          → primary contact email(s), ";" separated
 *   Q–BK Address etc. → ignored
 *   BL Notice Email   → optional extra contact email(s); only added if not in P
 *
 * Structure inference (from the title-name string):
 *   • Split owners by "&"
 *   • Each segment classified as individual / entity / government via keywords
 *   • Single segment → "Individual (Single)" | "Entity (Single)" | "Government"
 *   • Multiple individuals → "Individual (Joint)"
 *   • Multiple entities → "Entity (Joint)"
 *   • Any government segment → "Government"
 *   • Mixed individual + entity → "Mixed (Individual + Entity)"
 *
 * Classification (matches the existing decision logic in pendingImportsSeed):
 *   1. No matching active OC for the unit  → auto-create   (no review)
 *   2. Matching OC, names + structure same → skip-no-change (no review)
 *   3. Matching OC, names or structure differ → pending-review
 */

import type { OCListItem } from './ocListSeed';

export interface ImportBuildingLookup {
  id: string;
  name: string;
  upNumber: string;
}
export interface ImportUnitLookup {
  id: string;
  buildingId: string;
  lot: string;
  name: string;
  floor?: number;
  streetNumber?: number;
  streetName?: string;
}
export interface ImportLookups {
  buildings: ImportBuildingLookup[];
  units: ImportUnitLookup[];
}

export interface OCImportRow {
  // Display fields (resolved against the buildings/units module where possible)
  unitName: string;
  building: string;
  upNumber: string;
  ownerNames: string[];
  structure: string;
  /** Lot number from the CSV (column E) */
  lot: string;
  /** Email addresses harvested from columns P + BL (deduped, P first) */
  contactEmails: string[];
  // Resolution metadata (filled when buildings/units lookups succeed)
  resolvedBuildingId?: string;
  resolvedUnitId?: string;
  resolvedFloor?: number;
  resolvedStreetAddress?: string;
  // Original line number (1-indexed, header excluded) for error display
  lineNumber: number;
  // Per-row parse error (if any)
  parseError?: string;
}

export type RowClassification = 'auto-create' | 'pending-review' | 'skip-no-change' | 'unmatched';

export interface ClassifiedRow {
  row: OCImportRow;
  classification: RowClassification;
  matchedOc?: OCListItem;
  diff?: { field: string; from: string; to: string }[];
  skipReason?: string;
}

export interface ParseResult {
  rows: OCImportRow[];
  headerError?: string;
}

// ─── Header detection ──────────────────────────────────────────────────────
// Required PIQ headers we actually consume.
const PIQ_REQUIRED = ['S/Plan', 'Lot#', 'Name'];

// ─── Structure inference keywords ─────────────────────────────────────────
const ENTITY_KEYWORDS = [
  'pty ltd', 'pty. ltd', 'pty', 'ltd', 'limited', 'llc', 'inc', 'incorporated',
  'corporation', 'corp', 'holdings', 'foundation', 'association', 'smsf',
  'super fund', 'superannuation', 'trust', 'trustee', ' atf ', 'gmbh',
];
const GOVERNMENT_KEYWORDS = [
  'commonwealth of', 'state of', 'department of', 'dept of', 'ministry of',
  'australian government', 'act government', 'nsw government', 'vic government',
  'qld government', 'sa government', 'wa government', 'tas government',
  'nt government', 'federal government', 'housing act', 'housing nsw',
  'housing victoria', 'housing queensland', 'public housing', 'community housing',
  'the crown', ' council', 'shire of', 'city of',
];

type SegmentKind = 'individual' | 'entity' | 'government';
function classifySegment(seg: string): SegmentKind {
  const s = ' ' + seg.toLowerCase() + ' ';
  if (GOVERNMENT_KEYWORDS.some((k) => s.includes(k))) return 'government';
  if (ENTITY_KEYWORDS.some((k) => s.includes(k))) return 'entity';
  return 'individual';
}

export function inferStructureFromName(rawName: string): { ownerNames: string[]; structure: string } {
  const segments = rawName
    .split(/\s*&\s*/)
    .map((s) => s.replace(/\s+/g, ' ').trim())
    .filter(Boolean);
  if (segments.length === 0) return { ownerNames: [], structure: '' };

  const kinds = segments.map(classifySegment);
  const hasGov = kinds.some((k) => k === 'government');
  const allEntity = kinds.every((k) => k === 'entity');
  const allIndividual = kinds.every((k) => k === 'individual');

  let structure: string;
  if (hasGov) structure = 'Government';
  else if (allEntity) structure = segments.length === 1 ? 'Entity (Single)' : 'Entity (Joint)';
  else if (allIndividual) structure = segments.length === 1 ? 'Individual (Single)' : 'Individual (Joint)';
  else structure = 'Mixed (Individual + Entity)';

  return { ownerNames: segments, structure };
}

// ─── Email extraction ─────────────────────────────────────────────────────
function splitEmails(raw: string): string[] {
  return raw
    .split(/[;,]/)
    .map((e) => e.trim())
    .filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e));
}

// ─── UP digits for permissive matching ────────────────────────────────────
const digitsOnly = (s: string) => (s.match(/\d+/g) || []).join('');

// ─── Parse ────────────────────────────────────────────────────────────────
export function parseCsv(text: string, lookups: ImportLookups): ParseResult {
  const lines = text
    .split(/\r?\n/)
    .filter((l) => l.trim().length > 0 && !l.trim().startsWith('#'));

  if (lines.length === 0) return { rows: [], headerError: 'CSV is empty' };

  const header = splitCsvLine(lines[0]).map((h) => h.trim());
  const missing = PIQ_REQUIRED.filter((h) => !header.includes(h));
  if (missing.length > 0) {
    return {
      rows: [],
      headerError: `Missing required PIQ column(s): ${missing.join(', ')}. Expected Vantage PIQ export with at minimum S/Plan, Lot# and Name columns.`,
    };
  }

  const idx = (col: string) => header.indexOf(col);
  const iSPlan = idx('S/Plan');
  const iLot = idx('Lot#');
  const iName = idx('Name');
  const iEmail = idx('Email');
  const iNoticeEmail = idx('Notice Email');
  const iStreetNo = idx('Street No');
  const iStreetName = idx('Street Name');

  // Build resolution maps
  const buildingByDigits = new Map<string, ImportBuildingLookup>();
  for (const b of lookups.buildings) {
    const d = digitsOnly(b.upNumber);
    if (d) buildingByDigits.set(d, b);
  }
  const unitsByBuilding = new Map<string, ImportUnitLookup[]>();
  for (const u of lookups.units) {
    if (!unitsByBuilding.has(u.buildingId)) unitsByBuilding.set(u.buildingId, []);
    unitsByBuilding.get(u.buildingId)!.push(u);
  }

  const rows: OCImportRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = splitCsvLine(lines[i]);
    const get = (n: number) => (n >= 0 ? (cols[n] ?? '').trim() : '');

    const sPlan = get(iSPlan);
    const lot = get(iLot);
    const rawName = get(iName);
    const primaryEmails = splitEmails(get(iEmail));
    const noticeEmails = splitEmails(get(iNoticeEmail));
    const seen = new Set(primaryEmails.map((e) => e.toLowerCase()));
    const extraEmails = noticeEmails.filter((e) => !seen.has(e.toLowerCase()));
    const contactEmails = [...primaryEmails, ...extraEmails];

    const { ownerNames, structure } = inferStructureFromName(rawName);

    // Resolve building by S/Plan digits
    const planDigits = digitsOnly(sPlan);
    const matchedBuilding = planDigits ? buildingByDigits.get(planDigits) : undefined;

    // Resolve unit by (building, lot)
    let matchedUnit: ImportUnitLookup | undefined;
    if (matchedBuilding) {
      const candidates = unitsByBuilding.get(matchedBuilding.id) || [];
      matchedUnit = candidates.find((u) => u.lot.replace(/^lot\s*/i, '').trim() === lot.trim());
    }

    const fallbackStreet = `${get(iStreetNo)} ${get(iStreetName)}`.trim();

    const row: OCImportRow = {
      unitName: matchedUnit?.name || (fallbackStreet ? `Lot ${lot} · ${fallbackStreet}` : ''),
      building: matchedBuilding?.name || '',
      upNumber: matchedBuilding?.upNumber || (planDigits ? `UP${planDigits}` : sPlan),
      ownerNames,
      structure,
      lot,
      contactEmails,
      resolvedBuildingId: matchedBuilding?.id,
      resolvedUnitId: matchedUnit?.id,
      resolvedFloor: matchedUnit?.floor,
      resolvedStreetAddress: fallbackStreet || undefined,
      lineNumber: i,
    };

    const errs: string[] = [];
    if (!sPlan) errs.push('S/Plan is required');
    if (!lot) errs.push('Lot# is required');
    if (!rawName) errs.push('Name is required');
    if (sPlan && !matchedBuilding) errs.push(`UP/${sPlan} is not in the buildings module`);
    if (matchedBuilding && lot && !matchedUnit) {
      errs.push(`Lot ${lot} is not in ${matchedBuilding.name} (${matchedBuilding.upNumber})`);
    }
    if (rawName && ownerNames.length === 0) errs.push('Could not infer owner names');
    if (errs.length > 0) row.parseError = errs.join('; ');

    rows.push(row);
  }
  return { rows };
}

/** Split a single CSV line; supports double-quoted fields with embedded commas. */
function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQ) {
      if (ch === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; }
        else inQ = false;
      } else cur += ch;
    } else {
      if (ch === ',') { out.push(cur); cur = ''; }
      else if (ch === '"') inQ = true;
      else cur += ch;
    }
  }
  out.push(cur);
  return out;
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');

/** Classify each parsed row against the current effective OC list. */
export function classifyRows(
  rows: OCImportRow[],
  effectiveOcs: OCListItem[],
): ClassifiedRow[] {
  const activeByKey = new Map<string, OCListItem>();
  for (const oc of effectiveOcs) {
    if (oc.isArchived) continue;
    activeByKey.set(`${norm(oc.unitName)}|${norm(oc.building)}`, oc);
  }

  const seenInBatch = new Set<string>();

  return rows.map<ClassifiedRow>((row) => {
    // Unmatched portfolio data is a hard blocker — surface it distinctly so
    // the admin can fix the buildings/units module before re-importing,
    // rather than burying it as a generic "skip".
    const missingBuilding = !row.resolvedBuildingId;
    const missingUnit = !!row.resolvedBuildingId && !row.resolvedUnitId;
    if (missingBuilding || missingUnit) {
      const reason = missingBuilding
        ? `Building UP/${row.upNumber || '—'} is not in the buildings module`
        : `Lot ${row.lot || '—'} is not registered under ${row.building || `UP/${row.upNumber}`} in the units module`;
      return { row, classification: 'unmatched', skipReason: reason };
    }
    if (row.parseError) {
      return { row, classification: 'skip-no-change', skipReason: row.parseError };
    }
    const key = `${norm(row.unitName)}|${norm(row.building)}`;
    if (seenInBatch.has(key)) {
      return {
        row,
        classification: 'skip-no-change',
        skipReason: 'Duplicate row in this CSV — first occurrence kept',
      };
    }
    seenInBatch.add(key);
    const matched = activeByKey.get(key);
    if (!matched) {
      return { row, classification: 'auto-create' };
    }
    const namesEqual =
      matched.ownerNames.length === row.ownerNames.length &&
      matched.ownerNames.every((n, i) => norm(n) === norm(row.ownerNames[i] || ''));
    const structureEqual = norm(matched.structure) === norm(row.structure);
    if (namesEqual && structureEqual) {
      return {
        row,
        classification: 'skip-no-change',
        matchedOc: matched,
        skipReason: 'Names and structure match current OC',
      };
    }
    const diff: { field: string; from: string; to: string }[] = [];
    if (!namesEqual) {
      diff.push({
        field: 'Names on title',
        from: matched.ownerNames.join(', '),
        to: row.ownerNames.join(', '),
      });
    }
    if (!structureEqual) {
      diff.push({ field: 'Structure', from: matched.structure, to: row.structure });
    }
    return { row, classification: 'pending-review', matchedOc: matched, diff };
  });
}

/** Sample CSV in the real PIQ shape, sized down to the columns we consume.
 *  S/Plan values match seeded UP numbers (digits-only). */
export const SAMPLE_CSV = `S/Plan,Building Name,Street No,Street Name,Lot#,Unit#,Agent Id,Index,Name,Salutation,Contact,Phone 1,Phone 2,Fax,Mobile,Email,Notice Email
15853,The Parks - Stage 2,2,Lady Nelson Place,1,1,,,Hannah Williams,,,,,,,hannah.williams@example.com,
15853,The Parks - Stage 2,2,Lady Nelson Place,3,3,,,Trent Family Trust,,,,,,,trustee@trentfamily.com.au,accounts@trentfamily.com.au
15853,The Parks - Stage 2,2,Lady Nelson Place,12,12,,,Helena Brooks & Daniel Brooks,,,,,,,helena.brooks@example.com;daniel.brooks@example.com,
15853,The Parks - Stage 2,9,Made-up Street,99,99,,,New Owner Pty Ltd,,,,,,,owner@newowner.com.au,
15853,The Parks - Stage 2,2,Lady Nelson Place,2,2,,,Housing ACT,,,,,,,tenancies@act.gov.au,`;
