import { z } from "zod";
import { pgTable, serial, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const contactSourceSchema = z.enum([
  'Strata', 'Self', 'Admin', 'Taylr', 'Agent', 'Owner', 'Offsite Owner',
  'Lawyer', 'Accountant', 'Property Manager', 'Sales Agent',
  'Company Secretary', 'POA'
]);

export const accessLevelSchema = z.enum([
  'Active (Full portal)', 'Active', 'Limited portal',
  'Pending approval',
  'Pending onboarding', 'Not applicable',
  'Suspended (tenancy expired)', 'Suspended (tenancy ended)', 'None'
]);

export const emailStatusSchema = z.enum(['Not Sent', 'Pending', 'Sent', 'Failed', 'N/A']);

export const emailTypeSchema = z.enum(['Strata Welcome', 'Taylr Intro', 'Resvu Sync', 'Resvu Intro', 'Waste Management', 'Insurance', 'HH Member Welcome', 'Tenant Lease Query']);

export const emailFlowSchema = z.object({
  id: z.string(),
  type: emailTypeSchema,
  status: emailStatusSchema,
  sentAt: z.coerce.date().optional(),
});

export const contactSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string(),
  phone: z.string(),
  role: z.string(),
  authorised: z.boolean(),
  access: accessLevelSchema,
  sources: z.array(contactSourceSchema),
  isArchived: z.boolean(),
  hasConflict: z.boolean(),
  history: z.array(z.string()),
  emails: z.array(emailFlowSchema),
  onboarded: z.boolean(),
  verified: z.boolean(),
  verifiedAt: z.string().optional(),
  notOnLease: z.boolean().optional(),
  taylrId: z.string().optional(),
  originKey: z.string().optional(),
  originFingerprint: z.string().optional(),
  associatedWith: z.object({
    name: z.string(),
    role: z.string(),
  }).optional(),
  originalData: z.object({
    name: z.string().optional(),
    email: z.string().optional(),
    phone: z.string().optional(),
    role: z.string().optional(),
  }).optional(),
});

export const tenancyStatusSchema = z.enum([
  'Active', 'Unknown', 'Missing Tenancy', 'Expired', 'Ended', 'Not Applicable'
]);

export const tenancyStateSchema = z.object({
  status: tenancyStatusSchema,
  leaseStart: z.string().optional(),
  leaseEnd: z.string().optional(),
  managingAgent: z.string().optional(),
  version: z.number(),
  history: z.array(z.string()),
  lastVerifiedBy: z.string().optional(),
  lastVerifiedAt: z.string().optional(),
  tenantIds: z.array(z.string()).optional(),
});

export const s119HistoryEntrySchema = z.object({
  date: z.string(),
  title: z.string(),
  user: z.string(),
  isSystem: z.boolean().optional(),
});

export const s119StatusSchema = z.enum(['Not Applicable', 'Unknown', 'Not Set', 'Pending Payment', 'Pending Issue', 'Issued', 'Expired']);

export const s119EmailLogEntrySchema = z.object({
  id: z.string(),
  date: z.string(),
  type: z.enum(['Order Confirmation', 'Invoice Issued', 'Payment Reminder', 'Payment Received', 'Invoice Reminder', 'Invoice Expiry Warning', 'Order Cancelled', 'Certificate Issued', 'Certificate Amended', 'Certificate Available', 'Certificate Expired']),
  recipientName: z.string(),
  recipientRole: z.enum(['Owner', 'Agent', 'Tenant']),
  recipientEmail: z.string(),
  trigger: z.enum(['automatic', 'manual']),
  status: z.enum(['Sent', 'Pending', 'Failed']),
  subject: z.string().optional(),
});

export const s119ServiceSchema = z.object({
  status: s119StatusSchema,
  issueDate: z.string().optional(),
  expiryDate: z.string().optional(),
  isLocked: z.boolean(),
  lockDetails: z.object({
    user: z.string(),
    time: z.string(),
  }).optional(),
  orderedBy: z.string().optional(),
  orderedByRole: z.enum(['Owner', 'Agent']).optional(),
  orderDate: z.string().optional(),
  orderValue: z.number().optional(),
  invoiceExpiryDate: z.string().optional(),
  history: z.array(s119HistoryEntrySchema),
  emailLog: z.array(s119EmailLogEntrySchema).optional(),
});

export const ownershipCardSchema = z.object({
  settlementDate: z.string(),
  purchasePrice: z.string(),
  saleDate: z.string().optional(),
  salePrice: z.string().optional(),
  namePerTitle: z.string().optional(),
  taylrId: z.string().optional(),
  originKey: z.string().optional(),
  originFingerprint: z.string().optional(),
});

export const renewalActivityTypeSchema = z.enum(['Call', 'Email', 'Meeting', 'Note', 'Reminder']);

export const renewalEntrySchema = z.object({
  id: z.string(),
  buildingId: z.string(),
  date: z.string().min(1),
  type: renewalActivityTypeSchema,
  author: z.string().min(1),
  content: z.string().min(1),
});

export const insertRenewalEntrySchema = renewalEntrySchema.omit({ id: true, buildingId: true });

export const updateRenewalEntrySchema = z.object({
  date: z.string().min(1),
  type: renewalActivityTypeSchema,
  author: z.string().min(1),
  content: z.string().min(1),
}).partial();

export const renewalActivityRows = pgTable("renewal_activity_rows", {
  id: serial("id").primaryKey(),
  buildingId: text("building_id").notNull(),
  entryId: text("entry_id").notNull(),
  kind: text("kind").notNull(),
  date: text("date"),
  type: text("type"),
  author: text("author"),
  content: text("content"),
});

export const insertRenewalActivityRowSchema = createInsertSchema(renewalActivityRows).omit({ id: true });
export type InsertRenewalActivityRow = z.infer<typeof insertRenewalActivityRowSchema>;
export type RenewalActivityRow = typeof renewalActivityRows.$inferSelect;

export const renewalActivityDeltaSchema = z.object({
  added: z.array(renewalEntrySchema),
  edits: z.record(z.string(), z.object({
    date: z.string().optional(),
    type: renewalActivityTypeSchema.optional(),
    author: z.string().optional(),
    content: z.string().optional(),
  })),
  deletedIds: z.array(z.string()),
});

export const userRoleSchema = z.enum(['Admin', 'Agent', 'Strata', 'Owner']);

export const healthStatusSchema = z.enum(['Healthy', 'Warning', 'Critical']);

export const appStateSchema = z.object({
  contacts: z.array(contactSchema),
  tenancy: tenancyStateSchema,
  s119Rental: s119ServiceSchema,
  ownershipCard: ownershipCardSchema,
  currentUserRole: userRoleSchema,
  healthStatus: healthStatusSchema,
});

export type ContactSource = z.infer<typeof contactSourceSchema>;
export type AccessLevel = z.infer<typeof accessLevelSchema>;
export type EmailStatus = z.infer<typeof emailStatusSchema>;
export type EmailFlow = z.infer<typeof emailFlowSchema>;
export type Contact = z.infer<typeof contactSchema>;
export type TenancyStatus = z.infer<typeof tenancyStatusSchema>;
export type TenancyState = z.infer<typeof tenancyStateSchema>;
export type S119HistoryEntry = z.infer<typeof s119HistoryEntrySchema>;
export type S119EmailLogEntry = z.infer<typeof s119EmailLogEntrySchema>;
export type S119Service = z.infer<typeof s119ServiceSchema>;
export type OwnershipCard = z.infer<typeof ownershipCardSchema>;
export type UserRole = z.infer<typeof userRoleSchema>;
export type HealthStatus = z.infer<typeof healthStatusSchema>;
export type AppState = z.infer<typeof appStateSchema>;
export type RenewalActivityType = z.infer<typeof renewalActivityTypeSchema>;
export type RenewalEntry = z.infer<typeof renewalEntrySchema>;
export type InsertRenewalEntry = z.infer<typeof insertRenewalEntrySchema>;
export type UpdateRenewalEntry = z.infer<typeof updateRenewalEntrySchema>;
export type RenewalActivityDelta = z.infer<typeof renewalActivityDeltaSchema>;
