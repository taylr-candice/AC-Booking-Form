/**
 * Pending OC import queue — auto-imports from Vantage that need an admin
 * decision before they're applied to the live OC list.
 *
 * Decision logic (confirmed by product, Apr 2026):
 *   1. Greenfield (unit has no active OC)              → auto-create OC      (no review)
 *   2. Active OC, name matches PIQ                     → skip (no-op)        (no review)
 *   3. Active OC, name differs from PIQ                → queue here          (review needed)
 *
 * Only scenario 3 reaches this queue. Each item carries the matched current
 * OC and the incoming proposed name(s) so the admin can decide:
 *   • Rename existing — apply incoming names to current OC, no archive
 *   • Replace with new OC — archive current, create new sequenced forward
 *   • Reject — incoming data is wrong (eg. wrong unit), drop it
 *
 * NOTE: This is a prototype slice. Decisions update item status + log intent
 * only; the full mutation pipeline against ocListData lands when the storage
 * layer is in place.
 */

export type PendingImportSource = 'vantage-auto' | 'manual';

export type PendingImportStatus =
  | 'pending'
  | 'applied-rename'
  | 'applied-replace'
  | 'rejected';

export interface DiffField {
  field: string;
  from: string;
  to: string;
}

export interface PendingOCImport {
  id: string;
  receivedAt: string;            // ISO
  source: PendingImportSource;
  matchedOcId: string;           // existing active OC for this unit
  matchedUnitName: string;
  matchedBuilding: string;
  matchedUpNumber: string;
  currentNamesOnTitle: string[];
  currentStructure: string;
  incoming: {
    namesOnTitle: string[];
    structure?: string;
  };
  diff: DiffField[];
  status: PendingImportStatus;
  decidedAt?: string;
  decidedBy?: string;
  decisionNote?: string;
  edited?: boolean;
  editedAt?: string;
}

export const STRUCTURE_OPTIONS: string[] = [
  'Individual (Single)',
  'Individual (Joint)',
  'Entity (Single)',
  'Entity (Joint)',
  'Government',
  'Mixed (Individual + Entity)',
];

/**
 * Lightweight log of the silent paths (greenfield auto-creates and exact-match
 * skips) so admins can sanity-check that the auto-import is firing as expected
 * without having to dig through server logs.
 */
export type ImportLogKind = 'auto-created' | 'skipped-no-change';

export interface ImportLogEntry {
  id: string;
  receivedAt: string;            // ISO
  kind: ImportLogKind;
  unitName: string;
  building: string;
  detail: string;                // human-readable one-liner
}

export const pendingImportsSeed: PendingOCImport[] = [
  {
    id: 'pi-001',
    receivedAt: '2026-04-22T07:14:00.000Z',
    source: 'vantage-auto',
    matchedOcId: 'oc-002',
    matchedUnitName: '2 / 2 Lady Nelson Place',
    matchedBuilding: 'The Parks - Stage 2',
    matchedUpNumber: 'UP15853',
    currentNamesOnTitle: ['Mark D Patel', 'Joanne K Patel'],
    currentStructure: 'Individual (Joint)',
    incoming: {
      namesOnTitle: ['Patel Family Trust'],
      structure: 'Entity (Single)',
    },
    diff: [
      { field: 'Names on title', from: 'Mark D Patel, Joanne K Patel', to: 'Patel Family Trust' },
      { field: 'Structure',      from: 'Individual (Joint)',              to: 'Entity (Single)' },
    ],
    status: 'pending',
  },
  {
    id: 'pi-002',
    receivedAt: '2026-04-22T06:42:00.000Z',
    source: 'vantage-auto',
    matchedOcId: 'oc-016',
    matchedUnitName: '7 / 4 Lady Nelson Place',
    matchedBuilding: 'The Parks - Stage 2',
    matchedUpNumber: 'UP15853',
    currentNamesOnTitle: ['Vivian Marsh'],
    currentStructure: 'Individual (Single)',
    incoming: {
      namesOnTitle: ['Vivian Marsh-Holland'],
      structure: 'Individual (Single)',
    },
    diff: [
      { field: 'Names on title', from: 'Vivian Marsh', to: 'Vivian Marsh-Holland' },
    ],
    status: 'pending',
  },
  {
    id: 'pi-003',
    receivedAt: '2026-04-21T22:08:00.000Z',
    source: 'vantage-auto',
    matchedOcId: 'oc-007',
    matchedUnitName: '7 / 2 Lady Nelson Place',
    matchedBuilding: 'The Parks - Stage 2',
    matchedUpNumber: 'UP15853',
    currentNamesOnTitle: ['Margaret Hollis'],
    currentStructure: 'Individual (Single)',
    incoming: {
      namesOnTitle: ['Marcus Webb', 'Elena Webb'],
      structure: 'Individual (Joint)',
    },
    diff: [
      { field: 'Names on title', from: 'Margaret Hollis',     to: 'Marcus Webb, Elena Webb' },
      { field: 'Structure',      from: 'Individual (Single)',  to: 'Individual (Joint)' },
    ],
    status: 'pending',
  },
];

export const importLogSeed: ImportLogEntry[] = [
  {
    id: 'il-001',
    receivedAt: '2026-04-22T07:14:00.000Z',
    kind: 'auto-created',
    unitName: '12 / 2 Lady Nelson Place',
    building: 'The Parks - Stage 2',
    detail: 'No active OC existed — auto-created OC-069',
  },
  {
    id: 'il-002',
    receivedAt: '2026-04-22T07:14:00.000Z',
    kind: 'skipped-no-change',
    unitName: '1 / 2 Lady Nelson Place',
    building: 'The Parks - Stage 2',
    detail: 'Names on title match current OC — no action',
  },
  {
    id: 'il-003',
    receivedAt: '2026-04-22T07:14:00.000Z',
    kind: 'skipped-no-change',
    unitName: '3 / 2 Lady Nelson Place',
    building: 'The Parks - Stage 2',
    detail: 'Names on title match current OC — no action',
  },
  {
    id: 'il-004',
    receivedAt: '2026-04-22T07:14:00.000Z',
    kind: 'skipped-no-change',
    unitName: '4 / 2 Lady Nelson Place',
    building: 'The Parks - Stage 2',
    detail: 'Names on title match current OC — no action',
  },
];
