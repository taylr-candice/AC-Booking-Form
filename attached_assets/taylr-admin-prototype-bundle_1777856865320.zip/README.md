# Taylr Admin Simulator — Prototype Bundle

Snapshot of the Taylr Admin Simulator prototype, packaged for handover into
another project. **This is reference material, not a runnable project** — it
intentionally omits `node_modules`, `dist`, lockfiles, and the bulk of
`attached_assets/`.

## What's in here

- **`docs/admin-overview.md`** — start here. Architecture, module map, file
  layout, conventions, glossary, and a "where to look for…" lookup table.
- **`docs/design-system.md`** — brand tokens, HSL light+dark palettes,
  typography, shadcn config, exact dependency versions, and a vanilla-shadcn →
  admin migration checklist.
- **`replit.md`** — the in-repo project overview.

## Configuration snapshot

- `package.json`, `tsconfig.json` — dependency versions, path aliases.
- `components.json` — shadcn/ui config (style: `new-york`, baseColor:
  `neutral`, cssVariables on, lucide icons).
- `vite.config.ts`, `postcss.config.js` — bundler config.
- `drizzle.config.ts` — reserved for future DB use; not wired today.

> Note: Tailwind v4 has no `tailwind.config.{ts,js}`. The theme lives in
> `client/src/index.css` via `@theme inline { … }`.

## Code snapshot

- **`client/index.html`** — Google Fonts `<link>` setup.
- **`client/src/index.css`** — the brand token CSS (light + dark, font
  aliases, radius scale). The single source of truth for visual tokens.
- **`client/src/main.tsx`** — app entry point.
- **`client/src/App.tsx`** — the wouter route table; start here when adding a
  new page.
- **`client/src/pages/modules/BuildingDetail.tsx`** — one representative
  detail-page module showing the prototype's pattern (routed full-page detail
  view, not a drawer).

## Domain model — `shared/`

The full `shared/` folder is included verbatim. This is the single source of
truth for the domain — Zod schemas, inferred types, static seed data, pricing
model, CSV import schema, and pure business-logic functions (`shared/logic/`).

If you want to align another project's domain types with the prototype, this
is the folder to diff against.

## What's deliberately NOT in this bundle

- `node_modules/`, `dist/`, `package-lock.json` — install fresh in the target
  project.
- `.git/` — this is a snapshot, not a clone. The full git history lives in
  the prototype Replit and in the `Replit_Prototypes/Admin` GitHub branch.
- The full `client/src/pages/modules/*` set (only one example included). To
  port a specific module, ask for it by name.
- `attached_assets/` (except the two design-system markdown docs above) —
  it's full of historical chat exports and screenshots that aren't useful
  outside the original Replit.
- `server/` — the prototype's Express server is just a thin static-data
  shim; the target admin will have its own real backend.
