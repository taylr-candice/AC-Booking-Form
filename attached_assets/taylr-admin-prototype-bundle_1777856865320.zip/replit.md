# Taylr Admin Simulator

## Overview

Taylr Admin Simulator is an interactive prototype of a strata property management admin panel, designed for demonstration purposes. It simulates the backend management of ownership cards, contacts, tenancy lifecycles, and email workflows. The project is a full-stack TypeScript monorepo with a React SPA, an Express server for static seed data via REST API, and a shared module for domain schemas and business logic. All data is static JSON, with no database persistence. The application includes password protection and an interactive guided walkthrough.

The vision for Taylr is to become a comprehensive property management platform, managing properties through their entire lifecycle (DEVELOPMENT, PRE_SETTLEMENT, REGISTERED, LIVE_OPERATION). A core ambition is to manage the complex interplay between physical property structures (buildings, units, ownership cards) and identity/relationship structures (persons, member profiles, Member x Unit relationships), ensuring accurate identity management and service entitlement across all phases.

## User Preferences

Preferred communication style: Simple, everyday language.
No database — static JSON types only.

## System Architecture

The project is a full-stack TypeScript monorepo consisting of a React frontend, an Express backend, and a shared module for core logic.

### UI/UX Decisions

The frontend utilizes `shadcn/ui` (New York style) built on `Radix UI` primitives and `Tailwind CSS v4` for styling. Animations are managed with `Framer Motion`. The UI prioritizes interactivity with slide-in drawers and panels for detailed views. All section headings and table headers are in sentence case, and operational status pills are simplified by removing icons.

### Technical Implementations

-   **Frontend**: Built with React 19, TypeScript, and Vite. `wouter` handles routing, and `Zustand` manages state. Data is sourced from static seed files. Features include an S119 Bulk Update workflow and display of floor/level information.
-   **Backend**: An Express 5 server (TypeScript via `tsx`) provides a lightweight API to serve static seed data, explicitly lacking write operations or persistence.
-   **Shared Module**: Contains all `Zod` schemas, TypeScript types for domain entities, static `seed data`, and pure business logic functions (`shared/logic/`). This ensures reusability and testability across the monorepo. Business logic covers health calculation, contact management, email generation, tenancy lifecycle, S119 certificate management, and ownership card updates.
-   **S119 Compliance Logic**: Implements a derived status system for S119 rental certificates, distinguishing between compliant and non-compliant states based on issue, expiry, and payment statuses.
-   **Core Object Hierarchy**: Models both `Physical/Property Structure` (Developer, Strata Organisation, Building, Unit, Ownership Card) and `Identity/Relationship Structure` (Person, Member Profile, Member x Unit), with `Member x Unit (MxU)` linking them.
-   **Building Lifecycle**: Supports `DEVELOPMENT`, `PRE_SETTLEMENT`, `REGISTERED`, and `LIVE_OPERATION` states with adaptive architectural rules.
-   **Identity & Account Rules**: Enforces "One Person, One Persistent Member Account" with services tied to `MxU/unit`.
-   **Role/State Model**: Differentiates `Building Lifecycle State`, `Relationship Role`, and `Relationship State`.
-   **Modules**:
    -   **Members**: Manages contacts with Taylr dashboard app access.
    -   **Units**: Manages unit details and links to ownership cards.
    -   **Ownership Cards**: Manages 68 ownership cards, one per unit/lot, supporting various ownership structures.
    -   **Leads**: Manages pre-agreement pursuit pipelines, distinguishing between Partner-Sourced and Taylr-Direct leads, with detail pages, conversion pipelines, and activity logs. Includes a "View as strata" picker.
    -   **Buildings**: Scoped to buildings with current or prior agreements, each with a detail page covering Overview, Services, Utilities, S119 Terms, Files, and Settings.
    -   **Add Ownership Card Modal**: A 3-step wizard for adding new ownership cards.
    -   **Services**: Master catalogue of Taylr services, including relationship types, status, categories, and logistics flags.
    -   **Sales Orders**: Module for service-related sales orders, initially S119 Rental Certificates, tracking payment and certificate statuses.
    -   **Finance**: Covers payments, pricing, and remittance tracking.
    -   **Pricing & Vendor Model (`shared/pricing.ts`)**: Defines `Service`, `Vendor`, `ServiceAssignment`, `UnitPricingOverride`, `OrderLine`, and `Coupon`. Includes a resolver `resolvePricing` for effective pricing.
    -   **Pricing Adapter (`client/src/lib/pricingAdapter.ts`)**: Bridges the new pricing model to existing UI components.
    -   **PaymentOrder forward-compat**: Extends `PaymentOrder` with `lines?: OrderLine[]` and `refundStatus?` for future compatibility.
    -   **Pricing Editing Surfaces (Stage 4)**: Enables runtime mutability of `shared/pricing.ts` data via `client/src/store/pricingStore.ts`, with dedicated actions for managing services, vendors, assignments, and coupons.
    -   **Refund Approval Lifecycle (Stage 3)**: Implements a refund workflow (Request → Approve → Mark Stripe complete) with corresponding ledger updates and status tracking.
    -   **OC Card S119 Status**: Tracks S119 issue and expiry dates for ownership cards.
    -   **S119 Pricing — zero-margin model**: Configures S119 base SKU for a zero-margin model for Taylr.
    -   **Strata-portal S119 Handover**: Provides functionality for handing over S119 certificates for lost buildings, including emailing owners, generating PDF handover reports, and emailing new strata companies.
    -   **Vendors**: Registry for external service providers.
    -   **Agents**: Manages managing agents with portal access.
    -   **Strata**: Manages strata companies, their services, contacts, and buildings.

## External Dependencies

### UI & Component Libraries

-   **shadcn/ui**: Component library.
-   **Radix UI**: Headless accessible primitives.
-   **Tailwind CSS v4**: Utility-first CSS.
-   **Framer Motion**: Animations.
-   **Lucide React**: Icon library.
-   **date-fns**: Date formatting.

### State & Data

-   **Zustand**: Client-side state management.
-   **TanStack React Query v5**: Data fetching.
-   **React Hook Form + @hookform/resolvers**: Form handling.
-   **Zod**: Schema validation.

### Server

-   **Express 5**: HTTP server.
-   **tsx**: TypeScript execution for dev server.

### Build & Dev Tools

-   **Vite 7**: Client bundler.
-   **vite-plugin-singlefile**: Bundles client into a single HTML file.
-   **esbuild**: Server bundler.

### Fonts

-   Google Fonts (DM Sans, Plus Jakarta Sans, Architects Daughter, Fira Code, Geist Mono).